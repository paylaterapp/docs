<?php
namespace Opencart\Admin\Controller\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Controller {

    public function index(): void {
        $this->load->language('extension/paylater/payment/paylater');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token']),
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment'),
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/paylater/payment/paylater', 'user_token=' . $this->session->data['user_token']),
        ];

        $data['save'] = $this->url->link('extension/paylater/payment/paylater.save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

        // Webhook URL the merchant will share with PayLater (storefront-side, no admin token)
        $catalog_url = defined('HTTPS_CATALOG') ? HTTPS_CATALOG : (defined('HTTP_CATALOG') ? HTTP_CATALOG : '');
        $data['webhook_url'] = rtrim($catalog_url, '/') . '/index.php?route=extension/paylater/payment/paylater.webhook';

        $fields = [
            'payment_paylater_status'             => '0',
            'payment_paylater_mode'               => 'uat',
            'payment_paylater_client_id'          => '',
            'payment_paylater_client_secret'      => '',
            'payment_paylater_outlet_id'          => '',
            'payment_paylater_webhook_secret'     => '',
            'payment_paylater_uat_url'            => 'https://connect.uat.paylaterapp.com/',
            'payment_paylater_production_url'     => 'https://connect.paylaterapp.com/',
            'payment_paylater_sort_order'         => '0',
            'payment_paylater_payment_title'      => 'PayLater — Buy Now, Pay Later',
            'payment_paylater_widget_enabled'     => '1',
            'payment_paylater_widget_plp'         => '1',
            'payment_paylater_widget_pdp'         => '1',
            'payment_paylater_widget_min_amount'  => '300',
            'payment_paylater_widget_title'       => 'Pay in {installments} interest-free installments',
            'payment_paylater_widget_footer'      => 'No interest. No hidden fees. Split your purchase into {installments} equal payments.',
        ];

        foreach ($fields as $key => $default) {
            $data[$key] = $this->config->get($key) ?? $default;
        }

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/paylater/payment/paylater', $data));
    }

    public function save(): void {
        $this->load->language('extension/paylater/payment/paylater');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/paylater/payment/paylater')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (empty($this->request->post['payment_paylater_client_id'])) {
            $json['error'] = $this->language->get('error_client_id');
        }

        if (empty($this->request->post['payment_paylater_client_secret'])) {
            $json['error'] = $this->language->get('error_client_secret');
        }

        if (empty($this->request->post['payment_paylater_outlet_id'])) {
            $json['error'] = $this->language->get('error_outlet_id');
        }

        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('payment_paylater', $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('extension/paylater/payment/paylater');
        $this->model_extension_paylater_payment_paylater->install();

        // Register widget events
        $this->load->model('setting/event');

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_pdp',
            'description' => 'PayLater BNPL widget on product detail page',
            'trigger'     => 'catalog/view/product/product/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectPdp',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_plp_css',
            'description' => 'PayLater BNPL widget CSS for product listing',
            'trigger'     => 'catalog/view/product/category/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectPlp',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_plp_search',
            'description' => 'PayLater BNPL widget CSS for search results',
            'trigger'     => 'catalog/view/product/search/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectPlp',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_thumb',
            'description' => 'PayLater BNPL widget on product thumb cards',
            'trigger'     => 'catalog/view/product/thumb/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectThumb',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        // Register order info hook (refund tab on the admin order page)
        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_order_info',
            'description' => 'PayLater refund tab on admin order info page',
            'trigger'     => 'admin/view/sale/order_info/before',
            'action'      => 'extension/paylater/payment/paylater.order_info_before',
            'status'      => 1,
            'sort_order'  => 1,
        ]);
    }

    public function uninstall(): void {
        $this->load->model('extension/paylater/payment/paylater');
        $this->model_extension_paylater_payment_paylater->uninstall();

        // Remove widget events
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('payment_paylater_pdp');
        $this->model_setting_event->deleteEventByCode('payment_paylater_plp_css');
        $this->model_setting_event->deleteEventByCode('payment_paylater_plp_search');
        $this->model_setting_event->deleteEventByCode('payment_paylater_thumb');
        $this->model_setting_event->deleteEventByCode('payment_paylater_order_info');
    }

    // ── Event handler: inject PayLater refund tab into admin order info page ──
    public function order_info_before(string &$route, array &$data): void {
        if (!$this->config->get('payment_paylater_status')) {
            return;
        }

        if (empty($this->request->get['order_id'])) {
            return;
        }

        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('extension/paylater/payment/paylater');

        $order_id = (int)$this->request->get['order_id'];
        $tx = $this->model_extension_paylater_payment_paylater->getTransaction($order_id);

        if (!$tx) {
            return; // Not a PayLater order — don't inject the tab
        }

        $tab_data = [
            'order_id'          => $order_id,
            'merchant_order_id' => $tx['merchant_order_id'] ?? '',
            'pay_later_id'      => $tx['payment_id'] ?? '',
            'status'            => $tx['status'] ?? '',
            'amount'            => (float)($tx['amount'] ?? 0),
            'refunded_amount'   => (float)($tx['refunded_amount'] ?? 0),
            'currency'          => $tx['currency'] ?? '',
            'date_added'        => $tx['date_added'] ?? '',
            'refund_full_url'    => str_replace('&amp;', '&', $this->url->link('extension/paylater/payment/paylater.refund', 'user_token=' . $this->session->data['user_token'])),
            'refund_partial_url' => str_replace('&amp;', '&', $this->url->link('extension/paylater/payment/paylater.refundPartial', 'user_token=' . $this->session->data['user_token'])),
        ];

        $content = $this->load->view('extension/paylater/payment/paylater_order', $tab_data);

        if (!isset($data['tabs']) || !is_array($data['tabs'])) {
            $data['tabs'] = [];
        }

        $data['tabs'][] = [
            'code'    => 'paylater',
            'title'   => 'PayLater',
            'content' => $content,
        ];
    }

    // ── Lookup transaction by order ID (for refund panel) ─────────────────
    public function lookup(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('extension/paylater/payment/paylater');

        $json = [];

        if (!$this->user->hasPermission('access', 'extension/paylater/payment/paylater')) {
            $json['error'] = $this->language->get('error_permission');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;

        if (!$order_id) {
            $json['error'] = 'Order ID is required';
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $tx = $this->model_extension_paylater_payment_paylater->getTransaction($order_id);

        if (!$tx) {
            $json['error'] = 'No PayLater transaction found for order #' . $order_id;
        } else {
            $json['transaction'] = [
                'order_id'          => (int)$tx['order_id'],
                'merchant_order_id' => $tx['merchant_order_id'],
                'pay_later_id'      => $tx['payment_id'],
                'status'            => $tx['status'],
                'amount'            => (float)$tx['amount'],
                'refunded_amount'   => (float)$tx['refunded_amount'],
                'currency'          => $tx['currency'],
                'date_added'        => $tx['date_added'],
            ];
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    // ── Full refund ───────────────────────────────────────────────────────
    public function refund(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('extension/paylater/payment/paylater');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/paylater/payment/paylater')) {
            $json['error'] = $this->language->get('error_permission');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $order_id = isset($this->request->post['order_id']) ? (int)$this->request->post['order_id'] : 0;

        if (!$order_id) {
            $json['error'] = 'Order ID is required';
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $result = $this->model_extension_paylater_payment_paylater->refundFull($order_id);

        if ($result['success']) {
            // Move order to Refunded (status 11) and add a clear comment
            $this->model_extension_paylater_payment_paylater->addOrderHistory(
                $order_id,
                11,
                'PayLater: full refund requested via admin. ' . $result['message'],
                false
            );
            $json['success'] = $result['message'];
        } else {
            $json['error'] = $result['error'];
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    // ── Partial refund ────────────────────────────────────────────────────
    public function refundPartial(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('extension/paylater/payment/paylater');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/paylater/payment/paylater')) {
            $json['error'] = $this->language->get('error_permission');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $order_id = isset($this->request->post['order_id']) ? (int)$this->request->post['order_id'] : 0;
        $amount   = isset($this->request->post['amount']) ? (float)$this->request->post['amount'] : 0.0;

        if (!$order_id || $amount <= 0) {
            $json['error'] = 'Order ID and amount are required';
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $result = $this->model_extension_paylater_payment_paylater->refundPartial($order_id, $amount);

        if ($result['success']) {
            // Add a comment but keep the order status as-is — partial refunds shouldn't
            // necessarily flip the order out of Processing. Use a raw history INSERT
            // (not addOrderHistory) so we don't change order_status_id.
            $this->model_extension_paylater_payment_paylater->addOrderComment(
                $order_id,
                'PayLater: partial refund of ' . number_format($amount, 2) . ' requested. ' . $result['message']
            );
            $json['success'] = $result['message'];
        } else {
            $json['error'] = $result['error'];
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}
