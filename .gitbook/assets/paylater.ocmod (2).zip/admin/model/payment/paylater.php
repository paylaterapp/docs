<?php
namespace Opencart\Admin\Model\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Model {

    public function install(): void {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "paylater_transaction` (
                `paylater_transaction_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id`            INT(11) NOT NULL,
                `merchant_order_id`   VARCHAR(255) NOT NULL DEFAULT '',
                `payment_id`          VARCHAR(255) NOT NULL DEFAULT '',
                `payment_link`        TEXT,
                `status`              VARCHAR(64) NOT NULL DEFAULT 'pending',
                `amount`              DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `refunded_amount`     DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `currency`            VARCHAR(8) NOT NULL DEFAULT '',
                `date_added`          DATETIME NOT NULL,
                `date_modified`       DATETIME NOT NULL,
                PRIMARY KEY (`paylater_transaction_id`),
                UNIQUE KEY `order_id` (`order_id`),
                KEY `merchant_order_id` (`merchant_order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "paylater_log` (
                `paylater_log_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id`        INT(11) NOT NULL,
                `type`            VARCHAR(64) NOT NULL DEFAULT '',
                `raw_request`     TEXT,
                `raw_response`    TEXT,
                `date_added`      DATETIME NOT NULL,
                PRIMARY KEY (`paylater_log_id`),
                KEY `order_id` (`order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");
    }

    public function uninstall(): void {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "paylater_transaction`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "paylater_log`");
    }

    // ── Transaction lookup ────────────────────────────────────────────────
    public function getTransaction(int $order_id): array {
        $query = $this->db->query("
            SELECT * FROM `" . DB_PREFIX . "paylater_transaction`
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
        return $query->row ?: [];
    }

    // ── Full refund ───────────────────────────────────────────────────────
    // POST {base}/api/paylater/merchant-portal/v2/web-checkout/refund
    //     Body: { "order_id": "<merchant_order_id>" }
    public function refundFull(int $order_id): array {
        $tx = $this->getTransaction($order_id);

        if (!$tx) {
            return ['success' => false, 'error' => 'No PayLater transaction found for this order.'];
        }

        if (empty($tx['merchant_order_id'])) {
            return ['success' => false, 'error' => 'Merchant order reference is missing — refund not possible.'];
        }

        if ((float)$tx['refunded_amount'] > 0) {
            return ['success' => false, 'error' => 'Order has already been refunded (full or partial).'];
        }

        $headers = $this->authHeaders(true);
        if (isset($headers['__error'])) {
            $this->logTransaction($order_id, 'refund_full_auth_fail', '', $headers['__error']);
            return ['success' => false, 'error' => $headers['__error']];
        }

        $url  = $this->getBaseUrl() . '/api/paylater/merchant-portal/v2/web-checkout/refund';
        $body = json_encode(['order_id' => $tx['merchant_order_id']]);

        $response = $this->curlPost($url, $body, $headers);
        $this->logTransaction($order_id, 'refund_full', $url . ' :: ' . $body, $response['raw']);

        $data = json_decode($response['raw'], true) ?: [];

        if ($response['http_code'] === 200 && !empty($data['message']) && empty($data['error'])) {
            $this->markRefunded($order_id, (float)$tx['amount']);
            return [
                'success' => true,
                'message' => $data['message'],
                'amount'  => (float)$tx['amount'],
            ];
        }

        $error = $data['error'] ?? ('HTTP ' . $response['http_code']);
        if (!empty($data['message'])) {
            $error .= ': ' . $data['message'];
        }
        return ['success' => false, 'error' => $error];
    }

    // ── Partial refund ────────────────────────────────────────────────────
    // POST {base}/api/paylater/merchant-portal/v2/web-checkout/refund
    //     Body: { "order_id": "<merchant_order_id>", "amount": "<partial>" }
    public function refundPartial(int $order_id, float $amount): array {
        $tx = $this->getTransaction($order_id);

        if (!$tx) {
            return ['success' => false, 'error' => 'No PayLater transaction found for this order.'];
        }

        if (empty($tx['merchant_order_id'])) {
            return ['success' => false, 'error' => 'Merchant order reference is missing — partial refund not possible.'];
        }

        if ($amount <= 0) {
            return ['success' => false, 'error' => 'Refund amount must be greater than zero.'];
        }

        $remaining = (float)$tx['amount'] - (float)$tx['refunded_amount'];
        if ($amount >= (float)$tx['amount']) {
            return ['success' => false, 'error' => 'Partial refund must be less than total order value. Use full refund instead.'];
        }
        if ($amount > $remaining) {
            return ['success' => false, 'error' => 'Refund amount exceeds remaining refundable amount (' . number_format($remaining, 2) . ').'];
        }

        $headers = $this->authHeaders(true);
        if (isset($headers['__error'])) {
            $this->logTransaction($order_id, 'refund_partial_auth_fail', '', $headers['__error']);
            return ['success' => false, 'error' => $headers['__error']];
        }

        $url  = $this->getBaseUrl() . '/api/paylater/merchant-portal/v2/web-checkout/refund';
        $body = json_encode([
            'order_id' => $tx['merchant_order_id'],
            'amount'   => (string)$amount,
        ]);

        $response = $this->curlPost($url, $body, $headers);
        $this->logTransaction($order_id, 'refund_partial', $url . ' :: ' . $body, $response['raw']);

        $data = json_decode($response['raw'], true) ?: [];

        if ($response['http_code'] === 200 && !empty($data['message']) && empty($data['error'])) {
            $this->incrementRefunded($order_id, $amount);
            return [
                'success' => true,
                'message' => $data['message'],
                'amount'  => $amount,
            ];
        }

        $error = $data['error'] ?? ('HTTP ' . $response['http_code']);
        if (!empty($data['message'])) {
            $error .= ': ' . $data['message'];
        }
        return ['success' => false, 'error' => $error];
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private function markRefunded(int $order_id, float $amount): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `refunded_amount` = '" . (float)$amount . "',
                `status`          = 'refunded',
                `date_modified`   = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    private function incrementRefunded(int $order_id, float $amount): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `refunded_amount` = `refunded_amount` + '" . (float)$amount . "',
                `status`          = 'partial_refund',
                `date_modified`   = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    // Add an order history entry AND update oc_order.order_status_id.
    // OC4 admin's model_sale_order doesn't expose addHistory, so we write directly.
    public function addOrderHistory(int $order_id, int $order_status_id, string $comment = '', bool $notify = false): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "order_history`
                SET `order_id`        = '" . (int)$order_id . "',
                    `order_status_id` = '" . (int)$order_status_id . "',
                    `notify`          = '" . (int)$notify . "',
                    `comment`         = '" . $this->db->escape($comment) . "',
                    `date_added`      = NOW()
        ");

        $this->db->query("
            UPDATE `" . DB_PREFIX . "order`
            SET `order_status_id` = '" . (int)$order_status_id . "',
                `date_modified`   = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    // Add a comment-only history row WITHOUT changing oc_order.order_status_id.
    // The history row carries the order's current status so the timeline stays consistent.
    public function addOrderComment(int $order_id, string $comment, bool $notify = false): void {
        $row = $this->db->query("
            SELECT `order_status_id` FROM `" . DB_PREFIX . "order`
            WHERE `order_id` = '" . (int)$order_id . "'
        ")->row;
        $current_status_id = (int)($row['order_status_id'] ?? 0);

        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "order_history`
                SET `order_id`        = '" . (int)$order_id . "',
                    `order_status_id` = '" . $current_status_id . "',
                    `notify`          = '" . (int)$notify . "',
                    `comment`         = '" . $this->db->escape($comment) . "',
                    `date_added`      = NOW()
        ");
    }

    private function logTransaction(int $order_id, string $type, string $request, string $response): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "paylater_log`
                SET `order_id`     = '" . (int)$order_id . "',
                    `type`         = '" . $this->db->escape($type) . "',
                    `raw_request`  = '" . $this->db->escape($request) . "',
                    `raw_response` = '" . $this->db->escape($response) . "',
                    `date_added`   = NOW()
        ");
    }

    private function getBaseUrl(): string {
        $mode = $this->config->get('payment_paylater_mode') ?: 'uat';
        return $mode === 'production'
            ? rtrim($this->config->get('payment_paylater_production_url'), '/')
            : rtrim($this->config->get('payment_paylater_uat_url'), '/');
    }

    private function getClientId(): string {
        return $this->config->get('payment_paylater_client_id') ?: '';
    }

    private function getClientSecret(): string {
        return $this->config->get('payment_paylater_client_secret') ?: '';
    }

    // ── OAuth2 token lifecycle ─────────────────────────────────────────────
    // Strategy: cached access_token → refresh_token grant → client_credentials.
    // Cache is shared per (base_url + client_id) with the catalog model.
    private function tokenCachePath(): string {
        return DIR_STORAGE . 'cache/paylater_token_' . md5($this->getBaseUrl() . '|' . $this->getClientId()) . '.json';
    }

    private function readTokenCache(): ?array {
        $path = $this->tokenCachePath();
        if (!file_exists($path)) {
            return null;
        }
        $cached = json_decode((string)file_get_contents($path), true);
        return is_array($cached) ? $cached : null;
    }

    private function writeTokenCache(array $token_data): void {
        $now = time();
        $payload = [
            'access_token'              => $token_data['access_token'] ?? '',
            'access_token_expires_at'   => $now + (int)($token_data['expires_in'] ?? 3599),
            'refresh_token'             => $token_data['refresh_token'] ?? '',
            'refresh_token_expires_at'  => !empty($token_data['refresh_token']) && (int)($token_data['refresh_expires_in'] ?? 0) > 0
                                            ? $now + (int)$token_data['refresh_expires_in']
                                            : 0,
        ];
        @file_put_contents($this->tokenCachePath(), json_encode($payload));
    }

    private function getAccessToken(): array {
        $cached = $this->readTokenCache();
        $now    = time();

        if ($cached && !empty($cached['access_token']) && (int)($cached['access_token_expires_at'] ?? 0) > $now + 60) {
            return ['success' => true, 'token' => $cached['access_token']];
        }

        if ($cached && !empty($cached['refresh_token']) && (int)($cached['refresh_token_expires_at'] ?? 0) > $now + 60) {
            $result = $this->tokenRequest([
                'grant_type'    => 'refresh_token',
                'refresh_token' => $cached['refresh_token'],
                'client_id'     => $this->getClientId(),
                'client_secret' => $this->getClientSecret(),
            ], 'refresh_token');
            if ($result['success']) {
                return $result;
            }
        }

        return $this->tokenRequest([
            'grant_type'    => 'client_credentials',
            'client_id'     => $this->getClientId(),
            'client_secret' => $this->getClientSecret(),
        ], 'client_credentials');
    }

    private function tokenRequest(array $form, string $grant_label): array {
        $url      = $this->getBaseUrl() . '/auth/realms/api/protocol/openid-connect/token';
        $body     = http_build_query($form);
        $response = $this->curlPostForm($url, $body);

        $this->logTransaction(0, 'auth_' . $grant_label, $url . ' (client_id=' . $this->getClientId() . ')', $response['raw']);

        $data = json_decode($response['raw'], true);

        if ($response['http_code'] === 200 && !empty($data['access_token'])) {
            $this->writeTokenCache($data);
            return ['success' => true, 'token' => $data['access_token']];
        }

        $error = $data['error_description'] ?? $data['error'] ?? ('HTTP ' . $response['http_code']);
        return ['success' => false, 'error' => 'Auth failed (' . $grant_label . '): ' . $error];
    }

    private function authHeaders(bool $with_json = true): array {
        $auth = $this->getAccessToken();
        if (!$auth['success']) {
            return ['__error' => $auth['error']];
        }
        $headers = ['Authorization: Bearer ' . $auth['token'], 'Accept: application/json'];
        if ($with_json) {
            $headers[] = 'Content-Type: application/json';
        }
        return $headers;
    }

    private function curlPostForm(string $url, string $body): array {
        return $this->curlPost($url, $body, [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
        ]);
    }

    private function curlGet(string $url, array $headers): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPGET         => true,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }

    private function curlPost(string $url, string $body, array $headers): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POSTFIELDS      => $body,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }
}
