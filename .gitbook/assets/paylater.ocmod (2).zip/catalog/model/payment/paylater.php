<?php
namespace Opencart\Catalog\Model\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Model {

    const STATUS_PENDING = 1;
    const STATUS_SUCCESS = 2;
    const STATUS_FAILED  = 3;

    public function getMethods(array $address = []): array {
        $this->load->language('extension/paylater/payment/paylater');

        $status = true;

        if ($this->cart->hasSubscription()) {
            $status = false;
        }

        $method_data = [];

        if ($status) {
            $title = $this->config->get('payment_paylater_payment_title') ?: $this->language->get('heading_title');

            $option_data['paylater'] = [
                'code'  => 'paylater.paylater',
                'name'  => $title,
                'image' => 'extension/paylater/logo.png',
            ];

            $method_data = [
                'code'       => 'paylater',
                'name'       => $title,
                'image'      => 'extension/paylater/logo.png',
                'option'     => $option_data,
                'sort_order' => $this->config->get('payment_paylater_sort_order'),
            ];
        }

        return $method_data;
    }

    private function getBaseUrl(): string {
        $mode = $this->config->get('payment_paylater_mode') ?: 'uat';
        return $mode === 'production'
            ? rtrim($this->config->get('payment_paylater_production_url'), '/')
            : rtrim($this->config->get('payment_paylater_uat_url'), '/');
    }

    private function getClientId(): string {
        return $this->config->get('payment_paylater_client_id') ?: '';
    }

    private function getClientSecret(): string {
        return $this->config->get('payment_paylater_client_secret') ?: '';
    }

    private function getOutletId(): int {
        return (int)($this->config->get('payment_paylater_outlet_id') ?: 0);
    }

    // ── OAuth2 token lifecycle ─────────────────────────────────────────────
    // Strategy (per PayLater integration guide):
    //   1. Use cached access_token if not within 60s of expiry
    //   2. Else if refresh_token still valid → grant_type=refresh_token
    //   3. Else → grant_type=client_credentials (full re-auth)
    // Cache is shared per (base_url + client_id), so token can be reused
    // across requests, outlets, and admin/catalog contexts.
    private function tokenCachePath(): string {
        return DIR_STORAGE . 'cache/paylater_token_' . md5($this->getBaseUrl() . '|' . $this->getClientId()) . '.json';
    }

    private function readTokenCache(): ?array {
        $path = $this->tokenCachePath();
        if (!file_exists($path)) {
            return null;
        }
        $cached = json_decode((string)file_get_contents($path), true);
        return is_array($cached) ? $cached : null;
    }

    private function writeTokenCache(array $token_data): void {
        $now = time();
        $payload = [
            'access_token'              => $token_data['access_token'] ?? '',
            'access_token_expires_at'   => $now + (int)($token_data['expires_in'] ?? 3599),
            'refresh_token'             => $token_data['refresh_token'] ?? '',
            'refresh_token_expires_at'  => !empty($token_data['refresh_token']) && (int)($token_data['refresh_expires_in'] ?? 0) > 0
                                            ? $now + (int)$token_data['refresh_expires_in']
                                            : 0,
        ];
        @file_put_contents($this->tokenCachePath(), json_encode($payload));
    }

    private function getAccessToken(): array {
        $cached = $this->readTokenCache();
        $now    = time();

        // 1. Cached access token still valid?
        if ($cached && !empty($cached['access_token']) && (int)($cached['access_token_expires_at'] ?? 0) > $now + 60) {
            return ['success' => true, 'token' => $cached['access_token']];
        }

        // 2. Refresh token grant — use only if we actually have a refresh_token with a real expiry
        if ($cached && !empty($cached['refresh_token']) && (int)($cached['refresh_token_expires_at'] ?? 0) > $now + 60) {
            $result = $this->tokenRequest([
                'grant_type'    => 'refresh_token',
                'refresh_token' => $cached['refresh_token'],
                'client_id'     => $this->getClientId(),
                'client_secret' => $this->getClientSecret(),
            ], 'refresh_token');
            if ($result['success']) {
                return $result;
            }
            // Refresh failed (revoked, expired, etc.) — fall through to client_credentials
        }

        // 3. Full re-auth
        return $this->tokenRequest([
            'grant_type'    => 'client_credentials',
            'client_id'     => $this->getClientId(),
            'client_secret' => $this->getClientSecret(),
        ], 'client_credentials');
    }

    private function tokenRequest(array $form, string $grant_label): array {
        $url      = $this->getBaseUrl() . '/auth/realms/api/protocol/openid-connect/token';
        $body     = http_build_query($form);
        $response = $this->curlPostForm($url, $body);

        $this->logTransaction(0, 'auth_' . $grant_label, $url . ' (client_id=' . $this->getClientId() . ')', $response['raw']);

        $data = json_decode($response['raw'], true);

        if ($response['http_code'] === 200 && !empty($data['access_token'])) {
            $this->writeTokenCache($data);
            return ['success' => true, 'token' => $data['access_token']];
        }

        $error = $data['error_description'] ?? $data['error'] ?? ('HTTP ' . $response['http_code']);
        return ['success' => false, 'error' => 'Auth failed (' . $grant_label . '): ' . $error];
    }

    private function authHeaders(bool $with_json = true): array {
        $auth = $this->getAccessToken();
        if (!$auth['success']) {
            return ['__error' => $auth['error']];
        }
        $headers = ['Authorization: Bearer ' . $auth['token'], 'Accept: application/json'];
        if ($with_json) {
            $headers[] = 'Content-Type: application/json';
        }
        return $headers;
    }

    public function generatePaymentLink(array $payload): array {
        $headers = $this->authHeaders(true);
        if (isset($headers['__error'])) {
            $this->logTransaction((int)$payload['order_id'], 'generate_link_auth_fail', '', $headers['__error']);
            return ['success' => false, 'error' => $headers['__error']];
        }

        $url = $this->getBaseUrl() . '/api/paylater/merchant-portal/v2/web-checkout';

        $merchant_order_id = 'OC-' . $payload['order_id'] . '-' . time();

        $body = json_encode([
            'outlet_id'            => $this->getOutletId(),
            'currency'             => $payload['currency'],
            'amount'               => (float)$payload['amount'],
            'order_id'             => $merchant_order_id,
            'success_redirect_url' => $payload['return_url'],
            'fail_redirect_url'    => $payload['cancel_url'],
            'expiry_duration'      => 10,
        ]);

        $response = $this->curlPost($url, $body, $headers);

        $this->logTransaction((int)$payload['order_id'], 'generate_link', $body, $response['raw']);

        $data = json_decode($response['raw'], true);

        // v2 may return payment_link_url (snake) or paymentLinkUrl (camel) — accept both
        $payment_url = $data['payment_link_url'] ?? $data['paymentLinkUrl'] ?? '';

        if (($response['http_code'] === 200 || $response['http_code'] === 201) && $payment_url) {
            $this->saveTransaction(
                (int)$payload['order_id'],
                $merchant_order_id,
                '',
                $payment_url,
                'pending',
                (float)$payload['amount'],
                $payload['currency']
            );
            return [
                'success'           => true,
                'payment_url'       => $payment_url,
                'merchant_order_id' => $merchant_order_id,
            ];
        }

        $error_msg = $data['message'] ?? $data['error'] ?? ('HTTP ' . $response['http_code']);
        return ['success' => false, 'error' => $error_msg];
    }

    public function getTransactionStatus(int $order_id): array {
        $row = $this->db->query("
            SELECT `merchant_order_id` FROM `" . DB_PREFIX . "paylater_transaction`
            WHERE `order_id` = '" . (int)$order_id . "'
        ")->row;
        $merchant_order_id = $row['merchant_order_id'] ?? '';

        if (!$merchant_order_id) {
            return ['success' => false, 'paid' => false, 'status' => 'error', 'error' => 'No merchant order ref found for order ' . $order_id];
        }

        $headers = $this->authHeaders(false);
        if (isset($headers['__error'])) {
            return ['success' => false, 'paid' => false, 'status' => 'error', 'error' => $headers['__error']];
        }

        $url = $this->getBaseUrl()
             . '/api/paylater/merchant-portal/v2/web-checkout/status'
             . '?order_id=' . urlencode($merchant_order_id);

        $response = $this->curlGet($url, $headers);

        $this->logTransaction($order_id, 'get_status', $url, $response['raw']);

        $data = json_decode($response['raw'], true);

        if ($response['http_code'] === 200 && isset($data['status'])) {
            $gateway_status = (int)$data['status'];
            $message        = $data['message'] ?? '';
            $pay_later_id   = $data['pay_later_order_id'] ?? $data['payLaterOrderId'] ?? '';
            $merchant_ref   = $data['merchant_reference']  ?? $data['merchantReference']  ?? '';

            $this->updateTransactionStatus($order_id, $message, $pay_later_id);

            return [
                'success'      => true,
                'paid'         => $gateway_status === self::STATUS_SUCCESS,
                'pending'      => $gateway_status === self::STATUS_PENDING,
                'failed'       => $gateway_status === self::STATUS_FAILED,
                'status_code'  => $gateway_status,
                'status'       => $message,
                'pay_later_id' => $pay_later_id,
                'merchant_ref' => $merchant_ref,
            ];
        }

        $error_msg = $data['message'] ?? $data['error'] ?? ('HTTP ' . $response['http_code']);
        return ['success' => false, 'paid' => false, 'status' => 'error', 'error' => $error_msg];
    }

    // Validate PayLater webhook signature.
    // Algorithm:
    //   dataString = UPPERCASE(merchantId + orderId + status + timestamp + comments)
    //   txHash     = md5(dataString)
    //   signature  = hash_hmac('sha256', txHash, merchantWebhookSecret)
    public function validateWebhookSignature(array $payload): bool {
        $secret = $this->config->get('payment_paylater_webhook_secret') ?: '';
        if (!$secret || empty($payload['signature'])) {
            return false;
        }

        $dataString = strtoupper(
            ($payload['merchantId'] ?? '') .
            ($payload['orderId']    ?? '') .
            ($payload['status']     ?? '') .
            ($payload['timestamp']  ?? '') .
            ($payload['comments']   ?? '')
        );
        $computedTxHash    = md5($dataString);
        $computedSignature = hash_hmac('sha256', $computedTxHash, $secret);

        return hash_equals($computedSignature, (string)$payload['signature']);
    }

    // Resolve our internal order_id from the merchant_order_id (e.g. "OC-123-1713100000")
    public function getOrderIdByMerchantRef(string $merchant_order_id): int {
        if (!$merchant_order_id) {
            return 0;
        }
        $row = $this->db->query("
            SELECT `order_id` FROM `" . DB_PREFIX . "paylater_transaction`
            WHERE `merchant_order_id` = '" . $this->db->escape($merchant_order_id) . "'
            LIMIT 1
        ")->row;
        return (int)($row['order_id'] ?? 0);
    }

    public function logWebhook(int $order_id, string $type, string $request, string $response): void {
        $this->logTransaction($order_id, $type, $request, $response);
    }

    public function updateTransactionFromWebhook(int $order_id, string $status, string $pay_later_id): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `status`        = '" . $this->db->escape($status) . "',
                `payment_id`    = IF('" . $this->db->escape($pay_later_id) . "' != '', '" . $this->db->escape($pay_later_id) . "', `payment_id`),
                `date_modified` = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    private function saveTransaction(int $order_id, string $merchant_order_id, string $pay_later_id, string $link, string $status, float $amount, string $currency): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "paylater_transaction`
                SET `order_id`          = '" . (int)$order_id . "',
                    `merchant_order_id` = '" . $this->db->escape($merchant_order_id) . "',
                    `payment_id`        = '" . $this->db->escape($pay_later_id) . "',
                    `payment_link`      = '" . $this->db->escape($link) . "',
                    `status`            = '" . $this->db->escape($status) . "',
                    `amount`            = '" . (float)$amount . "',
                    `currency`          = '" . $this->db->escape($currency) . "',
                    `date_added`        = NOW(),
                    `date_modified`     = NOW()
            ON DUPLICATE KEY UPDATE
                    `merchant_order_id` = VALUES(`merchant_order_id`),
                    `payment_id`        = VALUES(`payment_id`),
                    `payment_link`      = VALUES(`payment_link`),
                    `status`            = VALUES(`status`),
                    `date_modified`     = NOW()
        ");
    }

    private function updateTransactionStatus(int $order_id, string $status, string $pay_later_id = ''): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `status`        = '" . $this->db->escape($status) . "',
                `payment_id`    = IF('" . $this->db->escape($pay_later_id) . "' != '', '" . $this->db->escape($pay_later_id) . "', `payment_id`),
                `date_modified` = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    private function logTransaction(int $order_id, string $type, string $request, string $response): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "paylater_log`
                SET `order_id`      = '" . (int)$order_id . "',
                    `type`          = '" . $this->db->escape($type) . "',
                    `raw_request`   = '" . $this->db->escape($request) . "',
                    `raw_response`  = '" . $this->db->escape($response) . "',
                    `date_added`    = NOW()
        ");
    }

    private function curlPost(string $url, string $body, array $headers): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POSTFIELDS      => $body,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_ENCODING        => '',
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }

    private function curlGet(string $url, array $headers): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPGET         => true,
            CURLOPT_HTTPHEADER      => $headers,
            CURLOPT_ENCODING        => '',
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }

    // application/x-www-form-urlencoded — for the OAuth token endpoint
    private function curlPostForm(string $url, string $body): array {
        return $this->curlPost($url, $body, [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
        ]);
    }
}
