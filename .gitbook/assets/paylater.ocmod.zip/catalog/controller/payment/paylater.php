<?php
namespace Opencart\Catalog\Controller\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Controller {

    public function index(): string {
        $this->load->language('extension/paylater/payment/paylater');

        $data['language'] = $this->config->get('config_language');

        return $this->load->view('extension/paylater/payment/paylater', $data);
    }

    public function confirm(): void {
        $this->load->language('extension/paylater/payment/paylater');

        $json = [];

        if (!isset($this->session->data['order_id'])) {
            $json['error'] = $this->language->get('error_order');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $this->load->model('checkout/order');

        $order_id   = (int)$this->session->data['order_id'];
        $order_info = $this->model_checkout_order->getOrder($order_id);

        if (!$order_info) {
            $json['error'] = $this->language->get('error_order');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        if (!isset($this->session->data['payment_method']) || !str_starts_with($this->session->data['payment_method']['code'], 'paylater')) {
            $json['error'] = $this->language->get('error_payment_method');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $this->load->model('extension/paylater/payment/paylater');

        $lang = $this->config->get('config_language');

        // Separate success and fail URLs — gateway redirects to the appropriate one
        $success_url = $this->url->link('extension/paylater/payment/paylater.success', 'order_id=' . $order_id . '&language=' . $lang, true);
        $fail_url    = $this->url->link('extension/paylater/payment/paylater.fail', 'order_id=' . $order_id . '&language=' . $lang, true);

        // PayLater API requires QAR currency
        $amount = round((float)$order_info['total'], 2);

        $result = $this->model_extension_paylater_payment_paylater->generatePaymentLink([
            'order_id'   => $order_id,
            'amount'     => $amount,
            'currency'   => 'QAR',
            'customer'   => [
                'name'  => $order_info['firstname'] . ' ' . $order_info['lastname'],
                'email' => $order_info['email'],
                'phone' => $order_info['telephone'],
            ],
            'return_url' => $success_url,
            'cancel_url' => $fail_url,
        ]);

        if ($result['success'] && !empty($result['payment_url'])) {
            $this->model_checkout_order->addHistory($order_id, $this->config->get('config_order_status_id'), 'PayLater: redirecting to payment gateway', false);
            $json['redirect'] = $result['payment_url'];
        } else {
            $json['error'] = $this->language->get('error_payment_link') . (!empty($result['error']) ? ' (' . $result['error'] . ')' : '');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    // ── Customer returns on SUCCESS from gateway ──────────────────────────
    public function success(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('checkout/order');
        $this->load->model('extension/paylater/payment/paylater');

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;
        $lang = $this->config->get('config_language');

        if (!$order_id) {
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $lang));
            return;
        }

        // Gateway redirected to successRedirectUrl — mark order as paid immediately
        $this->model_checkout_order->addHistory(
            $order_id,
            $this->config->get('payment_paylater_success_status_id') ?: 2,
            'PayLater: payment successful (gateway redirect)',
            true
        );

        // Verify with status API after 30s delay in background
        $this->verifyPaymentAsync($order_id);

        unset($this->session->data['order_id']);
        $this->response->redirect($this->url->link('checkout/success', 'language=' . $lang));
    }

    // ── Customer returns on FAIL from gateway ─────────────────────────────
    public function fail(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('checkout/order');

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;
        $lang = $this->config->get('config_language');

        if (!$order_id) {
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $lang));
            return;
        }

        // Gateway redirected to failRedirectUrl — mark as failed
        $this->model_checkout_order->addHistory(
            $order_id,
            $this->config->get('payment_paylater_failed_status_id') ?: 10,
            'PayLater: payment failed (gateway redirect)',
            false
        );

        $this->session->data['error'] = $this->language->get('error_payment_failed');
        $this->response->redirect($this->url->link('checkout/checkout', 'language=' . $lang));
    }

    // ── Called via cron/ajax to verify payment after 30s delay ─────────────
    public function verify(): void {
        $this->load->model('checkout/order');
        $this->load->model('extension/paylater/payment/paylater');

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;

        if (!$order_id) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing order_id']);
            exit;
        }

        $status_result = $this->model_extension_paylater_payment_paylater->getTransactionStatus($order_id);

        if ($status_result['success']) {
            if ($status_result['paid']) {
                $this->model_checkout_order->addHistory(
                    $order_id,
                    $this->config->get('payment_paylater_success_status_id') ?: 2,
                    'PayLater: payment verified via API. PayLater ID: ' . $status_result['pay_later_id'] . ' | Ref: ' . $status_result['merchant_ref'],
                    true
                );
            } elseif ($status_result['failed']) {
                $this->model_checkout_order->addHistory(
                    $order_id,
                    $this->config->get('payment_paylater_failed_status_id') ?: 10,
                    'PayLater: payment failed (verified via API). PayLater ID: ' . $status_result['pay_later_id'],
                    false
                );
            }
        }

        http_response_code(200);
        echo json_encode(['verified' => true, 'status' => $status_result['status'] ?? 'unknown']);
        exit;
    }

    // ── Fire a non-blocking background request to verify after 30s ────────
    private function verifyPaymentAsync(int $order_id): void {
        $verify_url = $this->url->link('extension/paylater/payment/paylater.verify', 'order_id=' . $order_id, true);

        // Use a non-blocking curl call with 30s delay via connection timeout trick
        // The request will be picked up by the server after the customer is already redirected
        $ch = curl_init($verify_url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_TIMEOUT         => 1,
            CURLOPT_NOSIGNAL        => true,
            CURLOPT_FRESH_CONNECT   => true,
            CURLOPT_HTTPHEADER      => ['X-Paylater-Delay: 30'],
        ]);
        curl_exec($ch);
        curl_close($ch);
    }

    // ── Server-to-server webhook from gateway ─────────────────────────────
    public function webhook(): void {
        $this->load->model('checkout/order');
        $this->load->model('extension/paylater/payment/paylater');

        $raw     = file_get_contents('php://input');
        $payload = json_decode($raw, true);

        $signature = $this->request->server['HTTP_X_PAYLATER_SIGNATURE'] ?? '';
        if (!$this->model_extension_paylater_payment_paylater->validateWebhookSignature($raw, $signature)) {
            http_response_code(401);
            exit('Unauthorized');
        }

        $order_id = (int)($payload['order_id'] ?? 0);
        $status   = $payload['status'] ?? '';

        if ($order_id && $status) {
            $oc_status = match($status) {
                'paid'     => $this->config->get('payment_paylater_success_status_id') ?: 2,
                'failed'   => $this->config->get('payment_paylater_failed_status_id') ?: 10,
                'refunded' => 11,
                default    => 1,
            };
            $this->model_checkout_order->addHistory($order_id, $oc_status, 'PayLater webhook: ' . $status, $status === 'paid');
        }

        http_response_code(200);
        echo json_encode(['received' => true]);
        exit;
    }
}
