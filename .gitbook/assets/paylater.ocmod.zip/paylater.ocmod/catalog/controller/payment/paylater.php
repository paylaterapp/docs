<?php
namespace Opencart\Catalog\Controller\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Controller {

    public function index(): string {
        $this->load->language('extension/paylater/payment/paylater');

        $data['language'] = $this->config->get('config_language');

        return $this->load->view('extension/paylater/payment/paylater', $data);
    }

    public function confirm(): void {
        $this->load->language('extension/paylater/payment/paylater');

        $json = [];

        if (!isset($this->session->data['order_id'])) {
            $json['error'] = $this->language->get('error_order');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $this->load->model('checkout/order');

        $order_id   = (int)$this->session->data['order_id'];
        $order_info = $this->model_checkout_order->getOrder($order_id);

        if (!$order_info) {
            $json['error'] = $this->language->get('error_order');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        if (!isset($this->session->data['payment_method']) || !str_starts_with($this->session->data['payment_method']['code'], 'paylater')) {
            $json['error'] = $this->language->get('error_payment_method');
            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($json));
            return;
        }

        $this->load->model('extension/paylater/payment/paylater');

        $lang = $this->config->get('config_language');

        $success_url = $this->url->link('extension/paylater/payment/paylater.success', 'order_id=' . $order_id . '&language=' . $lang, true);
        $fail_url    = $this->url->link('extension/paylater/payment/paylater.fail', 'order_id=' . $order_id . '&language=' . $lang, true);

        $amount = round((float)$order_info['total'], 2);

        $result = $this->model_extension_paylater_payment_paylater->generatePaymentLink([
            'order_id'   => $order_id,
            'amount'     => $amount,
            'currency'   => 'QAR',
            'customer'   => [
                'name'  => $order_info['firstname'] . ' ' . $order_info['lastname'],
                'email' => $order_info['email'],
                'phone' => $order_info['telephone'],
            ],
            'return_url' => $success_url,
            'cancel_url' => $fail_url,
        ]);

        if ($result['success'] && !empty($result['payment_url'])) {
            $this->model_checkout_order->addHistory($order_id, $this->config->get('config_order_status_id'), 'PayLater: redirecting to payment gateway', false);
            $json['redirect'] = $result['payment_url'];
        } else {
            $json['error'] = $this->language->get('error_payment_link') . (!empty($result['error']) ? ' (' . $result['error'] . ')' : '');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    // ── Customer returns on SUCCESS from gateway ──────────────────────────
    public function success(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('checkout/order');
        $this->load->model('extension/paylater/payment/paylater');

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;
        $lang = $this->config->get('config_language');

        if (!$order_id) {
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $lang));
            return;
        }

        $order_info = $this->model_checkout_order->getOrder($order_id);
        $current_status_id = (int)($order_info['order_status_id'] ?? 0);

        if (in_array($current_status_id, [0, 1], true)) {
            $status_result = $this->model_extension_paylater_payment_paylater->getTransactionStatus($order_id);

            if (!empty($status_result['success']) && !empty($status_result['paid'])) {
                $success_status = (int)($this->config->get('payment_paylater_success_status_id') ?: 2);
                $this->model_checkout_order->addHistory(
                    $order_id,
                    $success_status,
                    'PayLater: payment verified via status API on customer return. PayLater Ref: ' . ($status_result['pay_later_id'] ?? '') . ' (webhook may have failed to deliver).',
                    true
                );
            }
        }

        unset($this->session->data['order_id']);
        $this->response->redirect($this->url->link('checkout/success', 'language=' . $lang));
    }

    // ── Customer returns on FAIL from gateway ─────────────────────────────
    public function fail(): void {
        $this->load->language('extension/paylater/payment/paylater');
        $this->load->model('checkout/order');

        $order_id = isset($this->request->get['order_id']) ? (int)$this->request->get['order_id'] : 0;
        $lang = $this->config->get('config_language');

        if (!$order_id) {
            $this->response->redirect($this->url->link('checkout/cart', 'language=' . $lang));
            return;
        }

        // Gateway redirected to failRedirectUrl — mark as failed
        $this->model_checkout_order->addHistory(
            $order_id,
            $this->config->get('payment_paylater_failed_status_id') ?: 10,
            'PayLater: payment failed (gateway redirect)',
            false
        );

        $this->session->data['error'] = $this->language->get('error_payment_failed');
        $this->response->redirect($this->url->link('checkout/checkout', 'language=' . $lang));
    }

    // ── Server-to-server webhook from PayLater gateway ────────────────────
    public function webhook(): void {
        $this->load->model('checkout/order');
        $this->load->model('extension/paylater/payment/paylater');

        $raw     = file_get_contents('php://input');
        $payload = json_decode($raw, true);

        if (!is_array($payload)) {
            $this->model_extension_paylater_payment_paylater->logWebhook(0, 'webhook_invalid_json', $raw, 'JSON decode failed');
            http_response_code(400);
            echo json_encode(['message' => 'Invalid JSON']);
            exit;
        }

        if (!$this->model_extension_paylater_payment_paylater->validateWebhookSignature($payload)) {
            $this->model_extension_paylater_payment_paylater->logWebhook(0, 'webhook_invalid_signature', $raw, 'Signature mismatch');
            http_response_code(403);
            echo json_encode(['message' => 'Invalid signature']);
            exit;
        }

        $merchant_order_id = (string)($payload['orderId'] ?? '');
        $status            = strtolower((string)($payload['status'] ?? ''));
        $paylater_ref      = (string)($payload['paylaterRef'] ?? '');
        $comments          = (string)($payload['comments'] ?? '');

        $order_id = $this->model_extension_paylater_payment_paylater->getOrderIdByMerchantRef($merchant_order_id);

        $this->model_extension_paylater_payment_paylater->logWebhook(
            $order_id,
            'webhook_' . $status,
            $raw,
            json_encode(['resolved_order_id' => $order_id, 'merchant_order_id' => $merchant_order_id])
        );

        if (!$order_id) {
            http_response_code(404);
            echo json_encode(['message' => 'Order not found for ' . $merchant_order_id]);
            exit;
        }

        if (!$status) {
            http_response_code(400);
            echo json_encode(['message' => 'Missing status']);
            exit;
        }

        // Map PayLater status to OpenCart order status
        $oc_status = match($status) {
            'success', 'paid', 'completed' => $this->config->get('payment_paylater_success_status_id') ?: 2,
            'failed', 'declined', 'error'  => $this->config->get('payment_paylater_failed_status_id') ?: 10,
            'refunded'                     => 11,
            default                        => 1,
        };

        $notify = in_array($status, ['success', 'paid', 'completed']);

        $comment = 'PayLater webhook: ' . $status;
        if ($paylater_ref) {
            $comment .= ' | PayLater Ref: ' . $paylater_ref;
        }
        if ($comments !== '') {
            $comment .= ' | ' . $comments;
        }

        $this->model_checkout_order->addHistory($order_id, $oc_status, $comment, $notify);
        $this->model_extension_paylater_payment_paylater->updateTransactionFromWebhook($order_id, $status, $paylater_ref);

        http_response_code(200);
        echo json_encode(['message' => 'Webhook received successfully']);
        exit;
    }
}
