<?php
namespace Opencart\Catalog\Controller\Extension\Paylater\Payment;

class PaylaterWidget extends \Opencart\System\Engine\Controller {

    private function getWidgetTitle(int $installments): string {
        $text = $this->config->get('payment_paylater_widget_title') ?: 'Pay in {installments} interest-free installments';
        return str_replace('{installments}', (string)$installments, $text);
    }

    private function getWidgetFooter(int $installments): string {
        $text = $this->config->get('payment_paylater_widget_footer') ?: 'No interest. No hidden fees. Split your purchase into {installments} equal payments.';
        return str_replace('{installments}', (string)$installments, $text);
    }

    // Event handler: inject widget into PDP (product detail page)
    public function injectPdp(string &$route, array &$args, mixed &$output): void {
        if (!$this->config->get('payment_paylater_status') || !$this->config->get('payment_paylater_widget_enabled') || !$this->config->get('payment_paylater_widget_pdp')) {
            return;
        }

        $product_id = (int)($this->request->get['product_id'] ?? 0);
        if (!$product_id) {
            return;
        }

        $this->load->model('catalog/product');
        $product_info = $this->model_catalog_product->getProduct($product_id);

        if (!$product_info) {
            return;
        }

        $price = (float)($product_info['special'] ?: $product_info['price']);

        $min = (float)($this->config->get('payment_paylater_widget_min_amount') ?: 300);

        if ($price < $min) {
            return;
        }

        $installments = (int)($this->config->get('payment_paylater_installments') ?: 4);
        $monthly = round($price / $installments, 2);

        $dates = [];
        for ($i = 0; $i < $installments; $i++) {
            $dates[] = [
                'label' => $i === 0 ? 'Now' : date('M', strtotime("+{$i} month")),
                'date'  => date('d-M', strtotime("+{$i} month")),
            ];
        }

        $data = [
            'monthly'       => number_format($monthly, 2),
            'installments'  => $installments,
            'dates'         => $dates,
            'currency'      => 'QAR',
            'widget_title'  => $this->getWidgetTitle($installments),
            'widget_footer' => $this->getWidgetFooter($installments),
        ];

        $widget_html = $this->load->view('extension/paylater/payment/paylater_widget_pdp', $data);

        $marker = '</ul>';
        $pos = strpos($output, 'price-new');
        if ($pos !== false) {
            $pos = strpos($output, $marker, $pos);
            if ($pos !== false) {
                $output = substr_replace($output, $marker . $widget_html, $pos, strlen($marker));
            }
        }
    }

    // Event handler
    public function injectPlp(string &$route, array &$args, mixed &$output): void {
        if (!$this->config->get('payment_paylater_status') || !$this->config->get('payment_paylater_widget_enabled') || !$this->config->get('payment_paylater_widget_plp')) {
            return;
        }

        $min = (float)($this->config->get('payment_paylater_widget_min_amount') ?: 300);
        $installments = (int)($this->config->get('payment_paylater_installments') ?: 4);

        $data = [
            'installments' => $installments,
            'min_amount'   => $min,
            'currency'     => 'QAR',
        ];

        $widget_script = $this->load->view('extension/paylater/payment/paylater_widget_plp', $data);

        $output .= $widget_script;
    }

    // Event handler
    public function injectThumb(string &$route, array &$args, mixed &$output): void {
        if (!$this->config->get('payment_paylater_status') || !$this->config->get('payment_paylater_widget_enabled') || !$this->config->get('payment_paylater_widget_plp')) {
            return;
        }

        $min = (float)($this->config->get('payment_paylater_widget_min_amount') ?: 300);
        $installments = (int)($this->config->get('payment_paylater_installments') ?: 4);
        $widget_title = $this->getWidgetTitle($installments);

        if (preg_match('/class="price-new">([^<]+)</', $output, $matches)) {
            $price_text = $matches[1];
            $price = (float)preg_replace('/[^0-9.]/', '', $price_text);

            if ($price >= $min) {
                $monthly = number_format(round($price / $installments, 2), 2);
                $widget_html = '<div class="paylater-plp-widget" style="background-color:#eeecf8;border:1px solid rgba(75,50,147,0.15);border-radius:10px;padding:8px 12px;margin-top:8px;display:flex;align-items:center;gap:8px;">'
                    . '<img src="extension/paylater/logo.png" style="width:24px;height:24px;border-radius:6px;" alt="PayLater">'
                    . '<div style="flex:1;">'
                    . '<div style="font-size:12px;font-weight:600;color:#4b3293;">' . htmlspecialchars($widget_title, ENT_QUOTES, 'UTF-8') . '</div>'
                    . '<div style="font-size:14px;font-weight:700;color:#4b3293;">QAR ' . $monthly . '/mo</div>'
                    . '</div>'
                    . '</div>';

                $price_end = '</div>';
                $pos = strpos($output, 'class="price"');
                if ($pos !== false) {
                    $pos = strpos($output, $price_end, $pos);
                    if ($pos !== false) {
                        $output = substr_replace($output, $widget_html . $price_end, $pos, strlen($price_end));
                    }
                }
            }
        }
    }
}
