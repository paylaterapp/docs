<?php
namespace Opencart\Admin\Model\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Model {

    public function install(): void {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "paylater_transaction` (
                `paylater_transaction_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id`            INT(11) NOT NULL,
                `payment_id`          VARCHAR(255) NOT NULL DEFAULT '',
                `payment_link`        TEXT,
                `status`              VARCHAR(64) NOT NULL DEFAULT 'pending',
                `amount`              DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `currency`            VARCHAR(8) NOT NULL DEFAULT '',
                `date_added`          DATETIME NOT NULL,
                `date_modified`       DATETIME NOT NULL,
                PRIMARY KEY (`paylater_transaction_id`),
                UNIQUE KEY `order_id` (`order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "paylater_log` (
                `paylater_log_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id`        INT(11) NOT NULL,
                `type`            VARCHAR(64) NOT NULL DEFAULT '',
                `raw_request`     TEXT,
                `raw_response`    TEXT,
                `date_added`      DATETIME NOT NULL,
                PRIMARY KEY (`paylater_log_id`),
                KEY `order_id` (`order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");
    }

    public function uninstall(): void {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "paylater_transaction`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "paylater_log`");
    }
}
