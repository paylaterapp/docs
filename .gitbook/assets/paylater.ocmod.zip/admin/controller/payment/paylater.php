<?php
namespace Opencart\Admin\Controller\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Controller {

    public function index(): void {
        $this->load->language('extension/paylater/payment/paylater');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token']),
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment'),
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/paylater/payment/paylater', 'user_token=' . $this->session->data['user_token']),
        ];

        $data['save'] = $this->url->link('extension/paylater/payment/paylater.save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

        $fields = [
            'payment_paylater_status'             => '0',
            'payment_paylater_mode'               => 'uat',
            'payment_paylater_api_key'            => '',
            'payment_paylater_outlet_id'          => '',
            'payment_paylater_merchant_id'        => '',
            'payment_paylater_uat_url'            => 'https://connect.uat.paylaterapp.com/',
            'payment_paylater_production_url'     => 'https://connect.paylaterapp.com/',
            'payment_paylater_sort_order'         => '0',
            'payment_paylater_payment_title'      => 'PayLater — Buy Now, Pay Later',
            'payment_paylater_widget_enabled'     => '1',
            'payment_paylater_widget_plp'         => '1',
            'payment_paylater_widget_pdp'         => '1',
            'payment_paylater_widget_min_amount'  => '300',
            'payment_paylater_widget_title'       => 'Pay in {installments} interest-free installments',
            'payment_paylater_widget_footer'      => 'No interest. No hidden fees. Split your purchase into {installments} equal payments.',
        ];

        foreach ($fields as $key => $default) {
            $data[$key] = $this->config->get($key) ?? $default;
        }

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/paylater/payment/paylater', $data));
    }

    public function save(): void {
        $this->load->language('extension/paylater/payment/paylater');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/paylater/payment/paylater')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (empty($this->request->post['payment_paylater_api_key'])) {
            $json['error'] = $this->language->get('error_api_key');
        }

        if (empty($this->request->post['payment_paylater_merchant_id'])) {
            $json['error'] = $this->language->get('error_merchant_id');
        }

        if (empty($this->request->post['payment_paylater_outlet_id'])) {
            $json['error'] = $this->language->get('error_outlet_id');
        }

        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('payment_paylater', $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void {
        $this->load->model('extension/paylater/payment/paylater');
        $this->model_extension_paylater_payment_paylater->install();

        // Register widget events
        $this->load->model('setting/event');

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_pdp',
            'description' => 'PayLater BNPL widget on product detail page',
            'trigger'     => 'catalog/view/product/product/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectPdp',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_plp_css',
            'description' => 'PayLater BNPL widget CSS for product listing',
            'trigger'     => 'catalog/view/product/category/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectPlp',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_plp_search',
            'description' => 'PayLater BNPL widget CSS for search results',
            'trigger'     => 'catalog/view/product/search/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectPlp',
            'status'      => 1,
            'sort_order'  => 0,
        ]);

        $this->model_setting_event->addEvent([
            'code'        => 'payment_paylater_thumb',
            'description' => 'PayLater BNPL widget on product thumb cards',
            'trigger'     => 'catalog/view/product/thumb/after',
            'action'      => 'extension/paylater/payment/paylater_widget.injectThumb',
            'status'      => 1,
            'sort_order'  => 0,
        ]);
    }

    public function uninstall(): void {
        $this->load->model('extension/paylater/payment/paylater');
        $this->model_extension_paylater_payment_paylater->uninstall();

        // Remove widget events
        $this->load->model('setting/event');

        $this->model_setting_event->deleteEventByCode('payment_paylater_pdp');
        $this->model_setting_event->deleteEventByCode('payment_paylater_plp_css');
        $this->model_setting_event->deleteEventByCode('payment_paylater_plp_search');
        $this->model_setting_event->deleteEventByCode('payment_paylater_thumb');
    }
}
