<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class WC_Paylater_Gateway_Blocks_Support extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'paylater_shop_now_pay_later';

    public function initialize() {
        $this->settings = get_option( 'woocommerce_paylater_shop_now_pay_later_settings', [] );
        $this->gateway = new WC_Paylater_Gateway_Shop_Now_Pay_Later();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {
        wp_register_script(
            'paylater_shop_now_pay_later-blocks-integration',
            plugins_url( '../assets/js/paylater-checkout.js', __FILE__ ),
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );

        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'paylater_shop_now_pay_later-blocks-integration');

        }
        return [ 'paylater_shop_now_pay_later-blocks-integration' ];
    }

    public function get_payment_method_data() {
        return [
            'title' => $this->gateway->title ?? 'PayLater',
            'description' => $this->gateway->description ?? 'Split in 4 Payments.',
            'supports' => [
                'products',
                'refunds'
            ],
            'icons' => [
                'id' => 'paylater',
                'src' => plugins_url('../assets/img/paylater.jpeg', __FILE__),
                'alt' => 'Paylater'
            ]
        ];
    }
}

?>