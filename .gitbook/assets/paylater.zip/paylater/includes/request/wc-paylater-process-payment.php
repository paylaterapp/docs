<?php
/*
* Process payments: magic begins here
*/

function processPaylaterPayment($order_id, $th, $type = null, $addon){
    $order = new WC_Order($order_id);
    $currency = $order->get_currency();
    $total = $order->get_total();
    $min = $th->order_min;

    try {
        // Log order information
        error_log('PayLater Debug - Order Info:');
        error_log('Order ID: ' . $order_id);
        error_log('Order Status: ' . $order->get_status());
        error_log('Order Total: ' . $total);
        error_log('Order Currency: ' . $currency);

        // Generate a unique order ID for PayLater API
        $unique_order_id = $order_id . '_' . time() . '_' . uniqid();
        error_log('Unique Order ID for PayLater: ' . $unique_order_id);

        // Store the original order ID and unique order ID relationship for reference
        update_post_meta($order_id, '_paylater_unique_order_id', $unique_order_id);
        error_log('Stored relationship between Order ID: ' . $order_id . ' and Unique Order ID: ' . $unique_order_id);

        // If order is already completed or processing, create a new order
        if (in_array($order->get_status(), array('completed', 'processing'))) {
            error_log('Order already completed/processing, creating new order');
            $order = wc_create_order();
            $order_id = $order->get_id();
            error_log('New Order ID: ' . $order_id);
        }

        // Log API key information (masked for security)
        error_log('PayLater Debug - API Key Info:');
        error_log('Test Mode: ' . ($th->testMode ? 'Yes' : 'No'));
        error_log('API Key: ' . $th->apiKey);
        error_log('Merchant ID: ' . $th->merchantId);
        error_log('Outlet ID: ' . $th->outletId);

        // Check minimum order amount
        if ($total < $min) {
            $error_message = sprintf(
                __('Minimum order amount for PayLater is %s %s', 'paylater'),
                $min,
                $currency
            );
            wc_add_notice($error_message, 'error');
            return array(
                'result' => 'failure',
                'messages' => $error_message
            );
        }

        // Prepare the request payload
        $payload = array(
            'merchantId' => $th->merchantId,
            'outletId' => $th->outletId,
            'currency' => $currency,
            'amount' => $total,
            'orderId' => $unique_order_id,
            //'successRedirectUrl' => $order->get_checkout_order_received_url(),
            'successRedirectUrl' => home_url('?wc-api=' . $addon . '&o=' . $order_id . '&s=s&orderId=' . $unique_order_id),
            'failRedirectUrl' => home_url('?wc-api=' . $addon . '&o=' . $order_id . '&s=f&orderId=' . $unique_order_id)
        );

        // Store the unique order ID in order meta for reference
        $order->update_meta_data('_paylater_unique_order_id', $unique_order_id);
        $order->save();

        // Log the request payload
        error_log('PayLater Payment Request: ' . print_r($payload, true));
        error_log('PayLater API URL: ' . $th->api);

        // Set up the request headers
        $headers = array(
            'x-api-key' => $th->apiKey,
            'Content-Type' => 'application/json'
        );

        // Make the API request
        $response = wp_remote_post($th->api, array(
            'headers' => $headers,
            'body' => json_encode($payload),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            error_log('PayLater API Error: ' . $response->get_error_message());
            throw new Exception($response->get_error_message());
        }

        $response_body = wp_remote_retrieve_body($response);
        $response_code = wp_remote_retrieve_response_code($response);
        
        error_log('PayLater API Response Code: ' . $response_code);
        error_log('PayLater API Response Body: ' . $response_body);

        $response_data = json_decode($response_body, true);

        if (isset($response_data['paymentLinkUrl'])) {
            // Store the payment link in order meta
            $order->update_meta_data('_paylater_payment_link', $response_data['paymentLinkUrl']);
            $order->save();

            // Update order status to pending instead of processing
            $order->update_status('pending', __('Payment initiated with PayLater. Awaiting payment completion.', 'paylater'));
            error_log('Order status updated to pending for order ID: ' . $order_id);

            // Return success with redirect URL
            return array(
                'result' => 'success',
                'redirect' => $response_data['paymentLinkUrl']
            );
        } else {
            // Handle error response
            $error_message = isset($response_data['error']) ? 
                $response_data['error'] : 
                __('Payment processing failed. Please try again.', 'paylater');
            
            error_log('PayLater Payment Error: ' . $error_message);
            
            // Update order status to failed
            $order->update_status('failed', $error_message);
            wc_add_notice($error_message, 'error');
            
            return array(
                'result' => 'failure',
                'messages' => $error_message
            );
        }
    } catch (Exception $e) {
        error_log('PayLater Exception: ' . $e->getMessage());
        wc_add_notice($e->getMessage(), 'error');
        return array(
            'result' => 'failure',
            'messages' => $e->getMessage()
        );
    }
}
