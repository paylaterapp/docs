<?php
/*
* Handle PayLater response
 */
function paylaterResponseHandler($th) {
    try {
        // Debug function to log important information
        function paylater_debug_log($message, $data = null) {
            error_log('PayLater Debug: ' . $message);
            if ($data !== null) {
                if (is_array($data) || is_object($data)) {
                    error_log('PayLater Debug Data: ' . print_r($data, true));
                } else {
                    error_log('PayLater Debug Data: ' . $data);
                }
            }
        }

        paylater_debug_log('Response handler triggered');

        // Get the order ID from the request (using 'o' parameter like in old plugin)
        $order_id = isset($_GET['o']) ? sanitize_text_field($_GET['o']) : null;
        $status = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : null;
        $paylater_order_id = isset($_GET['orderId']) ? sanitize_text_field($_GET['orderId']) : null;
        
        paylater_debug_log('Response parameters', array(
            'order_id' => $order_id,
            'status' => $status,
            'paylater_order_id' => $paylater_order_id
        ));
        
        if (!$order_id) {
            paylater_debug_log('No order ID found in request');
            throw new Exception(__('Order ID not found', 'paylater'));
        }

        // Get the order
        $order = wc_get_order($order_id);
        
        if (!$order || !is_a($order, 'WC_Order')) {
            paylater_debug_log('Order not found', $order_id);
            throw new Exception(__('Order not found', 'paylater'));
        }

        paylater_debug_log('Processing order', $order->get_id());
        paylater_debug_log('Current order status', $order->get_status());

        // Check if order is already completed or processing
        if ($order->has_status(array('completed', 'processing'))) {
            paylater_debug_log('Order already completed or processing, redirecting to thank you page');
            wp_redirect($order->get_checkout_order_received_url());
            exit;
        }

        // Check the status parameter (s=s for success, s=f for failure)
        if ($status === 's') {
            paylater_debug_log('Success status received, completing payment');
            
            // Check payment status via API to confirm
            $status_url = $th->api . 'status?orderId=' . $paylater_order_id . '&merchantId=' . $th->merchantId;
            $headers = array(
                'x-api-key' => $th->apiKey,
                'Content-Type' => 'application/json'
            );

            paylater_debug_log('Checking payment status at URL', $status_url);

            $response = wp_remote_get($status_url, array(
                'headers' => $headers,
                'timeout' => 30
            ));

            if (is_wp_error($response)) {
                paylater_debug_log('API Error', $response->get_error_message());
                // Even if API check fails, we'll complete the payment since we received success callback
                $order->add_order_note(__('Payment completed via PayLater (success callback). API verification failed: ' . $response->get_error_message(), 'paylater'));
            } else {
                $response_body = wp_remote_retrieve_body($response);
                $response_code = wp_remote_retrieve_response_code($response);
                
                paylater_debug_log('API Response Code', $response_code);
                paylater_debug_log('API Response Body', $response_body);
                
                $response_data = json_decode($response_body, true);
                paylater_debug_log('Decoded Response Data', $response_data);
                
                // Add note with API response
                $order->add_order_note(__('PayLater API Response: ' . $response_body, 'paylater'));
            }
            
            // Complete the payment
            $order->payment_complete();
            $order->update_status('processing', __('Payment completed via PayLater. Transaction ID: ' . $paylater_order_id, 'paylater'));
            $order->add_order_note(__('Payment completed via PayLater. Transaction ID: ' . $paylater_order_id, 'paylater'));
            paylater_debug_log('Payment completed for order', $order->get_id());
            
            // Clear cart
            WC()->cart->empty_cart();
            
            // Redirect to thank you page
            paylater_debug_log('Redirecting to thank you page', $order->get_checkout_order_received_url());
            wp_redirect($order->get_checkout_order_received_url());
            exit;
        } else if ($status === 'f') {
            // Payment failed
            paylater_debug_log('Failure status received, marking order as failed');
            $order->update_status('failed', __('Payment failed via PayLater. Transaction ID: ' . $paylater_order_id, 'paylater'));
            $order->add_order_note(__('Payment failed via PayLater. Transaction ID: ' . $paylater_order_id, 'paylater'));
            
            wc_add_notice(__('Payment failed. Please try again.', 'paylater'), 'error');
            wp_redirect($order->get_cancel_order_url());
            exit;
        } else {
            // Unknown status
            paylater_debug_log('Unknown status received', $status);
            $order->update_status('on-hold', __('Payment status unknown via PayLater. Transaction ID: ' . $paylater_order_id, 'paylater'));
            $order->add_order_note(__('Payment status unknown via PayLater. Transaction ID: ' . $paylater_order_id, 'paylater'));
            
            wp_redirect($order->get_checkout_order_received_url());
            exit;
        }
    } catch (Exception $e) {
        paylater_debug_log('Exception', $e->getMessage());
        wc_add_notice($e->getMessage(), 'error');
        wp_redirect(wc_get_checkout_url());
        exit;
    }
}