<?php
/*
/* PayLater Form Fields
*/
function paylater_form_fields($th){
	$th->form_fields = array(
		'enabled' => array(
			'title' => __('Enable/Disable', 'paylater'),
			'type' => 'checkbox',
			'label' => __('Enable PayLater Payment Gateway', 'paylater'),
			'default' => 'yes'
		),
		'title' => array(
			'title' => __('Title', 'paylater'),
			'type' => 'text',
			'description' => __('This controls the title which the user sees during checkout.', 'paylater'),
			'default' => __('PayLater', 'paylater'),
			'desc_tip' => true,
		),
		'description' => array(
			'title' => __('Description', 'paylater'),
			'type' => 'textarea',
			'description' => __('Payment method description that the customer will see on your checkout.', 'paylater'),
			'default' => __('Split in 4 Payments.', 'paylater'),
			'desc_tip' => true,
		),
		'testMode' => array(
			'title' => __('Test Mode', 'paylater'),
			'type' => 'checkbox',
			'label' => __('Enable Test Mode', 'paylater'),
			'default' => 'yes',
			'description' => __('Place the payment gateway in test mode using test API keys.', 'paylater'),
		),
		'testApiKey' => array(
			'title' => __('Test API Key', 'paylater'),
			'type' => 'password',
			'description' => __('Get your API keys from your PayLater account.', 'paylater'),
			'default' => '',
			'desc_tip' => true,
			'placeholder' => __('Test API Key', 'paylater')
		),
		'apiKey' => array(
			'title' => __('Live API Key', 'paylater'),
			'type' => 'password',
			'description' => __('Get your API keys from your PayLater account.', 'paylater'),
			'default' => '',
			'desc_tip' => true,
			'placeholder' => __('Live API Key', 'paylater')
		),
		'merchantId' => array(
			'title' => __('Merchant ID', 'paylater'),
			'type' => 'text',
			'description' => __('Your PayLater Merchant ID', 'paylater'),
			'default' => '',
			'desc_tip' => true,
			'placeholder' => __('Merchant ID', 'paylater')
		),
		'outletId' => array(
			'title' => __('Outlet ID', 'paylater'),
			'type' => 'text',
			'description' => __('Your PayLater Outlet ID', 'paylater'),
			'default' => '',
			'desc_tip' => true,
			'placeholder' => __('Outlet ID', 'paylater')
		),
		'order_min' => array(
			'title' => __('Minimum Order Amount', 'paylater'),
			'type' => 'text',
			'description' => __('Minimum order amount required to use PayLater.', 'paylater'),
			'default' => '200',
			'desc_tip' => true,
			'placeholder' => __('Minimum Order Amount', 'paylater')
		)
	);
}