<?php
/*
/* PayLater Gateway Parameters
*/
function gatewayPaylaterParameters($th, $title){
    $th->id = 'paylater_shop_now_pay_later';
    $th->icon = apply_filters('woocommerce_paylater_icon', plugins_url('assets/img/paylater.jpeg', dirname(dirname(__FILE__))));
    $th->has_fields = false;
    $th->method_title = $title;
    $th->method_description = __('PayLater Payment Gateway redirects customers to PayLater to enter their payment information.', 'paylater');
    $th->supports = array('products', 'refunds');

    // Load the settings
    $th->init_form_fields();
    $th->init_settings();

    // Define user set variables
    $th->enabled = $th->get_option('enabled');
    $th->title = $th->get_option('title');
    $th->description = $th->get_option('description');
    $th->testMode = $th->get_option('testMode') === 'yes';
    $th->apiKey = $th->testMode ? $th->get_option('testApiKey') : $th->get_option('apiKey');
    $th->merchantId = $th->get_option('merchantId');
    $th->outletId = $th->get_option('outletId');
    $th->order_min = $th->get_option('order_min');
    
    // API URLs
    $th->api = $th->testMode ? 
        'https://connect-sandbox.paylaterapp.com/api/paylater/merchant-portal/web-checkout/' : 
        'https://connect.paylaterapp.com/api/paylater/merchant-portal/web-checkout/';
    
    // Save settings
    add_action('woocommerce_update_options_payment_gateways_' . $th->id, array($th, 'process_admin_options'));
}