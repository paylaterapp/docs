<?php

/**
 * Plugin Name: PayLater
 * Plugin URI: https://paylaterapp.com/
 * Description: A Paylater payment platform for WooCommerce
 * Version: 0.1.1
 * Author: PayLater
 * Author URI: https://paylaterapp.com
 * Text Domain: paylater
 * Domain Path: /languages/
 * Developer: PayLater Engineering
 *
 * @package PayLater
 */
/*
 * Register our PHP class as a WooCommerce payment gateway
 */
defined( 'ABSPATH' ) || exit;

/*
 *  paylater add gateway class
 */
add_filter('woocommerce_payment_gateways', 'paylater_add_gateway_class');

function paylater_add_gateway_class($gateways){

    $gateways[] = 'WC_PayLater_Gateway_Shop_Now_Pay_Later';
    return $gateways;

}
/*
 * Load PayLater Gateway class on plugins_loaded action
 */
add_action('plugins_loaded', 'paylater_init_gateway_class');

function paylater_init_gateway_class(){

    if (class_exists('WC_PayLater_Gateway_Shop_Now_Pay_Later') || !class_exists('WC_Payment_Gateway')) return;

    define( 'WC_PAYLATER_DIR_PATH', plugin_dir_path( __FILE__ ) );
    require_once WC_PAYLATER_DIR_PATH . 'includes/settings/wc-paylater-gateway-parameters.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/settings/wc-paylater-form-fields.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/request/wc-paylater-process-payment.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/request/wc-paylater-response-handler.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/request/wc-paylater-refund.php';
	require_once WC_PAYLATER_DIR_PATH . '/includes/gateways/class-wc-shop-now-pay-later.php';
	require_once WC_PAYLATER_DIR_PATH . '/includes/wc-paylater-gateway-blocks-support.php';
}

/**
 * function to declare compatibility with cart_checkout_blocks feature 
*/
function declare_cart_checkout_paylater_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'declare_cart_checkout_paylater_blocks_compatibility');

// Hook the function to the 'woocommerce_blocks_loaded' action
add_action( 'woocommerce_blocks_loaded', 'wc_paylater_register_order_approval_payment_method_type' );

/**
 *  function to register a payment method type
 */
function wc_paylater_register_order_approval_payment_method_type() {
    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new WC_Paylater_Gateway_Blocks_Support );
        }
    );
}
?>