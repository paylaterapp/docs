# PayLater BNPL — OpenCart 4.x Payment Plugin

Buy Now, Pay Later payment gateway integration for OpenCart 4.x, with installment widgets on product detail and product listing pages.

---

## Directory Structure

```
paylater/
├── install.json
├── README.md
├── logo.png
├── admin/
│   ├── controller/payment/paylater.php       ← Settings page controller
│   ├── model/payment/paylater.php            ← Install/uninstall DB tables
│   ├── language/en-gb/payment/paylater.php   ← Admin language strings
│   └── view/template/payment/paylater.twig   ← Admin settings UI
└── catalog/
    ├── controller/payment/
    │   ├── paylater.php              ← Checkout flow (confirm + success/fail + webhook)
    │   └── paylater_widget.php       ← BNPL widget event hooks (PDP/PLP/thumb)
    ├── model/payment/paylater.php    ← API calls (generate link, get status)
    ├── language/en-gb/payment/paylater.php
    ├── view/template/payment/
    │   ├── paylater.twig             ← Checkout payment option
    │   ├── paylater_widget_pdp.twig  ← Expandable installment widget on PDP
    │   └── paylater_widget_plp.twig  ← Widget CSS for PLP
    └── view/javascript/paylater_widget.js
```

---

## Installation

1. Go to **Admin → Extensions → Installer** and upload `paylater.ocmod.zip`.
2. Go to **Admin → Extensions → Extensions → Payments**, find **PayLater BNPL**, click **Install**.
3. Click **Edit** to configure credentials.

---

## Admin Settings

| Field                | Description                                              |
|----------------------|----------------------------------------------------------|
| Status               | Enable/disable the payment method                        |
| Mode                 | `uat` for testing, `production` for live                 |
| Payment Method Title | Display name shown to customers at checkout              |
| Merchant ID          | Your PayLater merchant identifier                        |
| API Key              | Merchant API key                                         |
| Outlet ID            | PayLater outlet identifier                               |
| UAT Base URL         | Base URL for UAT/staging API calls                       |
| Production Base URL  | Base URL for production API calls                        |
| Widget Enabled       | Master switch for BNPL widgets                           |
| Widget on PLP        | Show widget on product listing pages                     |
| Widget on PDP        | Show expandable widget on product detail pages           |
| Widget Min Amount    | Minimum product price (QAR) to show the widget           |
| Widget Title Text    | Widget headline (supports `{installments}` placeholder)  |
| Widget Footer Text   | Widget footer (supports `{installments}` placeholder)    |
| Sort Order           | Position in payment method list at checkout              |

---

## Payment Flow

```
Customer at Checkout
       │
       ▼
[confirm()] — POST /api/paylater/merchant-portal/web-checkout/
  Receives: { paymentLinkUrl }
       │
       ▼
Redirect → PayLater Gateway Payment Page
       │
       ▼ (customer completes/cancels payment)
  ┌────┴────────────┐
success          failed
  │                  │
[success()]      [fail()]
Verify via       Mark failed
status API       Back to checkout
  │
  ▼
checkout/success

PayLater Gateway
       │ (server-to-server, async)
       ▼
[webhook()] — validates HMAC signature, updates order + logs event
```

---

## Webhook

For server-to-server confirmation, configure your PayLater dashboard webhook to point to:

```
https://yourstore.com/index.php?route=extension/paylater/payment/paylater.webhook
```

The webhook validates `X-Paylater-Signature` using HMAC-SHA256 with your API Key.

---

## Database

Two tables are created on install:

**`oc_paylater_transaction`** — stores one record per order
- `order_id`, `payment_id`, `payment_link`, `status`, `amount`, `currency`
- `date_added`, `date_modified`

**`oc_paylater_log`** — stores API request/response logs for debugging
- `order_id`, `type`, `raw_request`, `raw_response`, `date_added`

---

## BNPL Widget

The widget appears automatically on:
- **Product Detail Page (PDP)** — expandable card below the price with full installment breakdown
- **Product Listing Page (PLP)** — compact badge on each product card (via event hooks)

Both widgets only show when the product price ≥ configured minimum amount.

### Customising Widget Text

The widget title and footer are fully configurable in admin. Use `{installments}` as a placeholder:

- **Title example:** `Pay in {installments} interest-free installments`
- **Footer example:** `No interest. No hidden fees.`

---

## Currency

The PayLater API requires **QAR** currency. The extension hardcodes this for all API calls regardless of the store's display currency.

---

## Support

- Website: [paylaterapp.com](https://paylaterapp.com)
- UAT API: `https://connect.uat.paylaterapp.com/`
- Production API: `https://connect.paylaterapp.com/`
