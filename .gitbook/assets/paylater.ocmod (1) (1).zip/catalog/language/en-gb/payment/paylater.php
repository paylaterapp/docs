<?php
// Heading
$_['heading_title']          = 'PayLater — Buy Now, Pay Later';

// Text
$_['text_title']             = 'PayLater — Buy Now, Pay Later';
$_['button_confirm']         = 'Pay with PayLater';
$_['text_loading']           = 'Redirecting to payment page...';

// Error
$_['error_order']            = 'Error: No order found. Please try again.';
$_['error_payment_method']   = 'Error: Payment method is not valid.';
$_['error_payment_link']     = 'Error: Could not generate payment link. Please try again or choose another payment method.';
$_['error_payment_failed']   = 'Payment was not completed. Please try again.';
$_['error_payment_pending']  = 'Your payment is still being processed. You will receive a confirmation shortly.';
