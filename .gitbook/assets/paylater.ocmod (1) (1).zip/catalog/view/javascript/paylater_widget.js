/**
 * PayLater BNPL Widget — storefront injection script
 * Automatically appends the installment widget beneath product prices
 * on Product Detail Pages (PDP) and Product Listing Pages (PLP).
 *
 * Include this file via your theme's header or via the event hook.
 */
(function () {
  'use strict';

  const cfg = window.PayLaterWidget;
  if (!cfg || !cfg.widgetUrl) return;

  // ── Helpers ───────────────────────────────────────────────────────────────

  /**
   * Fetch rendered widget HTML for a given price from the OpenCart controller.
   */
  async function fetchWidget(price) {
    if (!price || price <= 0) return null;
    try {
      const url = cfg.widgetUrl + '&price=' + encodeURIComponent(price);
      const res = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (!res.ok) return null;
      return await res.text();
    } catch (e) {
      return null;
    }
  }

  /**
   * Parse a price string like "QAR 1,299.00" or "1299.00" → float
   */
  function parsePrice(text) {
    if (!text) return 0;
    const num = text.replace(/[^0-9.,]/g, '').replace(/,/g, '');
    return parseFloat(num) || 0;
  }

  /**
   * Insert widget HTML after the target element (only once).
   */
  function injectAfter(el, html) {
    if (!el || !html || el.dataset.paylaterInjected) return;
    el.dataset.paylaterInjected = '1';
    const wrapper = document.createElement('div');
    wrapper.innerHTML = html;
    el.insertAdjacentElement('afterend', wrapper.firstElementChild);
  }

  // ── PDP (Product Detail Page) ─────────────────────────────────────────────
  async function injectPDP() {
    // Common selectors across OpenCart themes; extend as needed
    const priceEl = document.querySelector(
      '.price-new, #price-new, .product-price .price, [itemprop="price"]'
    );
    if (!priceEl) return;

    const price = parsePrice(priceEl.textContent || priceEl.getAttribute('content') || '');
    const html = await fetchWidget(price);
    injectAfter(priceEl, html);
  }

  // ── PLP (Product Listing Page) ────────────────────────────────────────────
  async function injectPLP() {
    // Each product card usually has a .price element
    const cards = document.querySelectorAll('.product-thumb, .product-card, [data-product-id]');
    for (const card of cards) {
      const priceEl = card.querySelector('.price-new, .price, .product-price');
      if (!priceEl || priceEl.dataset.paylaterInjected) continue;
      const price = parsePrice(priceEl.textContent || '');
      const html = await fetchWidget(price);
      injectAfter(priceEl, html);
    }
  }

  // ── Auto-detect page type and run ─────────────────────────────────────────
  function init() {
    const path = window.location.href;

    // PDP detection: OpenCart uses route=product/product
    if (path.includes('product/product') || document.querySelector('.product-info, #product')) {
      injectPDP();
    }

    // PLP detection: category, search, special, manufacturer
    if (
      path.includes('product/category') ||
      path.includes('product/search') ||
      path.includes('product/special') ||
      path.includes('product/manufacturer') ||
      document.querySelector('.products-list, .product-layout')
    ) {
      injectPLP();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Re-run on AJAX-loaded content (e.g. infinite scroll, filter plugins)
  const observer = new MutationObserver(function (mutations) {
    for (const m of mutations) {
      if (m.addedNodes.length) {
        injectPLP();
        break;
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

})();
