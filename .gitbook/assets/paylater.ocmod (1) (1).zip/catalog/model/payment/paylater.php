<?php
namespace Opencart\Catalog\Model\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Model {

    const STATUS_PENDING = 1;
    const STATUS_SUCCESS = 2;
    const STATUS_FAILED  = 3;

    public function getMethods(array $address = []): array {
        $this->load->language('extension/paylater/payment/paylater');

        $status = true;

        if ($this->cart->hasSubscription()) {
            $status = false;
        }

        $method_data = [];

        if ($status) {
            $title = $this->config->get('payment_paylater_payment_title') ?: $this->language->get('heading_title');

            $option_data['paylater'] = [
                'code'  => 'paylater.paylater',
                'name'  => $title,
                'image' => 'extension/paylater/logo.png',
            ];

            $method_data = [
                'code'       => 'paylater',
                'name'       => $title,
                'image'      => 'extension/paylater/logo.png',
                'option'     => $option_data,
                'sort_order' => $this->config->get('payment_paylater_sort_order'),
            ];
        }

        return $method_data;
    }

    private function getBaseUrl(): string {
        $mode = $this->config->get('payment_paylater_mode') ?: 'uat';
        return $mode === 'production'
            ? rtrim($this->config->get('payment_paylater_production_url'), '/')
            : rtrim($this->config->get('payment_paylater_uat_url'), '/');
    }

    private function getApiKey(): string {
        return $this->config->get('payment_paylater_api_key') ?: '';
    }

    private function getMerchantId(): string {
        return $this->config->get('payment_paylater_merchant_id') ?: '';
    }

    private function getOutletId(): int {
        return (int)($this->config->get('payment_paylater_outlet_id') ?: 0);
    }

    private function postHeaders(): array {
        return [
            'Content-Type: application/json',
            'Accept: application/json',
            'x-api-key: ' . $this->getApiKey(),
        ];
    }

    private function getHeaders(): array {
        return [
            'Accept: application/json',
            'x-api-key: ' . $this->getApiKey(),
        ];
    }

    public function generatePaymentLink(array $payload): array {
        $url = $this->getBaseUrl() . '/api/paylater/merchant-portal/web-checkout/';

        $merchant_order_id = 'OC-' . $payload['order_id'] . '-' . time();

        $body = json_encode([
            'merchantId'         => $this->getMerchantId(),
            'outletId'           => $this->getOutletId(),
            'currency'           => $payload['currency'],
            'amount'             => (float)$payload['amount'],
            'orderId'            => $merchant_order_id,
            'successRedirectUrl' => $payload['return_url'],
            'failRedirectUrl'    => $payload['cancel_url'],
        ]);

        $response = $this->curlPost($url, $body);

        $this->logTransaction((int)$payload['order_id'], 'generate_link', $body, $response['raw']);

        $data = json_decode($response['raw'], true);

        if (($response['http_code'] === 200 || $response['http_code'] === 201) && !empty($data['paymentLinkUrl'])) {
            $this->saveTransaction(
                (int)$payload['order_id'],
                $merchant_order_id,
                '',
                $data['paymentLinkUrl'],
                'pending',
                (float)$payload['amount'],
                $payload['currency']
            );
            return [
                'success'           => true,
                'payment_url'       => $data['paymentLinkUrl'],
                'merchant_order_id' => $merchant_order_id,
            ];
        }

        $error_msg = $data['error'] ?? ('HTTP ' . $response['http_code']);
        return ['success' => false, 'error' => $error_msg];
    }

    public function getTransactionStatus(int $order_id): array {
        // Look up the merchant order id (e.g. "OC-123-1713100000") that was sent to PayLater
        $row = $this->db->query("
            SELECT `merchant_order_id` FROM `" . DB_PREFIX . "paylater_transaction`
            WHERE `order_id` = '" . (int)$order_id . "'
        ")->row;
        $merchant_order_id = $row['merchant_order_id'] ?? '';

        if (!$merchant_order_id) {
            return ['success' => false, 'paid' => false, 'status' => 'error', 'error' => 'No merchant order ref found for order ' . $order_id];
        }

        $url = $this->getBaseUrl()
             . '/api/paylater/merchant-portal/web-checkout/status'
             . '?orderId='    . urlencode($merchant_order_id)
             . '&merchantId=' . urlencode($this->getMerchantId());

        $response = $this->curlGet($url);

        $this->logTransaction($order_id, 'get_status', $url, $response['raw']);

        $data = json_decode($response['raw'], true);

        if ($response['http_code'] === 200 && isset($data['status'])) {
            $gateway_status = (int)$data['status'];
            $message        = $data['message'] ?? '';
            $pay_later_id   = $data['payLaterOrderId'] ?? '';
            $merchant_ref   = $data['merchantReference'] ?? '';

            $this->updateTransactionStatus($order_id, $message, $pay_later_id);

            return [
                'success'      => true,
                'paid'         => $gateway_status === self::STATUS_SUCCESS,
                'pending'      => $gateway_status === self::STATUS_PENDING,
                'failed'       => $gateway_status === self::STATUS_FAILED,
                'status_code'  => $gateway_status,
                'status'       => $message,
                'pay_later_id' => $pay_later_id,
                'merchant_ref' => $merchant_ref,
            ];
        }

        $error_msg = $data['error'] ?? ('HTTP ' . $response['http_code']);
        return ['success' => false, 'paid' => false, 'status' => 'error', 'error' => $error_msg];
    }

    // Validate PayLater webhook signature.
    // Algorithm:
    //   dataString = UPPERCASE(merchantId + orderId + status + timestamp + comments)
    //   txHash     = md5(dataString)
    //   signature  = hash_hmac('sha256', txHash, merchantWebhookSecret)
    public function validateWebhookSignature(array $payload): bool {
        $secret = $this->config->get('payment_paylater_webhook_secret') ?: '';
        if (!$secret || empty($payload['signature'])) {
            return false;
        }

        $dataString = strtoupper(
            ($payload['merchantId'] ?? '') .
            ($payload['orderId']    ?? '') .
            ($payload['status']     ?? '') .
            ($payload['timestamp']  ?? '') .
            ($payload['comments']   ?? '')
        );
        $computedTxHash    = md5($dataString);
        $computedSignature = hash_hmac('sha256', $computedTxHash, $secret);

        return hash_equals($computedSignature, (string)$payload['signature']);
    }

    // Resolve our internal order_id from the merchant_order_id (e.g. "OC-123-1713100000")
    public function getOrderIdByMerchantRef(string $merchant_order_id): int {
        if (!$merchant_order_id) {
            return 0;
        }
        $row = $this->db->query("
            SELECT `order_id` FROM `" . DB_PREFIX . "paylater_transaction`
            WHERE `merchant_order_id` = '" . $this->db->escape($merchant_order_id) . "'
            LIMIT 1
        ")->row;
        return (int)($row['order_id'] ?? 0);
    }

    public function logWebhook(int $order_id, string $type, string $request, string $response): void {
        $this->logTransaction($order_id, $type, $request, $response);
    }

    public function updateTransactionFromWebhook(int $order_id, string $status, string $pay_later_id): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `status`        = '" . $this->db->escape($status) . "',
                `payment_id`    = IF('" . $this->db->escape($pay_later_id) . "' != '', '" . $this->db->escape($pay_later_id) . "', `payment_id`),
                `date_modified` = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    private function saveTransaction(int $order_id, string $merchant_order_id, string $pay_later_id, string $link, string $status, float $amount, string $currency): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "paylater_transaction`
                SET `order_id`          = '" . (int)$order_id . "',
                    `merchant_order_id` = '" . $this->db->escape($merchant_order_id) . "',
                    `payment_id`        = '" . $this->db->escape($pay_later_id) . "',
                    `payment_link`      = '" . $this->db->escape($link) . "',
                    `status`            = '" . $this->db->escape($status) . "',
                    `amount`            = '" . (float)$amount . "',
                    `currency`          = '" . $this->db->escape($currency) . "',
                    `date_added`        = NOW(),
                    `date_modified`     = NOW()
            ON DUPLICATE KEY UPDATE
                    `merchant_order_id` = VALUES(`merchant_order_id`),
                    `payment_id`        = VALUES(`payment_id`),
                    `payment_link`      = VALUES(`payment_link`),
                    `status`            = VALUES(`status`),
                    `date_modified`     = NOW()
        ");
    }

    private function updateTransactionStatus(int $order_id, string $status, string $pay_later_id = ''): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `status`        = '" . $this->db->escape($status) . "',
                `payment_id`    = IF('" . $this->db->escape($pay_later_id) . "' != '', '" . $this->db->escape($pay_later_id) . "', `payment_id`),
                `date_modified` = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    private function logTransaction(int $order_id, string $type, string $request, string $response): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "paylater_log`
                SET `order_id`      = '" . (int)$order_id . "',
                    `type`          = '" . $this->db->escape($type) . "',
                    `raw_request`   = '" . $this->db->escape($request) . "',
                    `raw_response`  = '" . $this->db->escape($response) . "',
                    `date_added`    = NOW()
        ");
    }

    private function curlPost(string $url, string $body): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POSTFIELDS      => $body,
            CURLOPT_HTTPHEADER      => $this->postHeaders(),
            CURLOPT_ENCODING        => '',
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }

    private function curlGet(string $url): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPGET         => true,
            CURLOPT_HTTPHEADER      => $this->getHeaders(),
            CURLOPT_ENCODING        => '',
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }
}
