<?php
namespace Opencart\Admin\Model\Extension\Paylater\Payment;

class Paylater extends \Opencart\System\Engine\Model {

    public function install(): void {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "paylater_transaction` (
                `paylater_transaction_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id`            INT(11) NOT NULL,
                `merchant_order_id`   VARCHAR(255) NOT NULL DEFAULT '',
                `payment_id`          VARCHAR(255) NOT NULL DEFAULT '',
                `payment_link`        TEXT,
                `status`              VARCHAR(64) NOT NULL DEFAULT 'pending',
                `amount`              DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `refunded_amount`     DECIMAL(15,4) NOT NULL DEFAULT 0.0000,
                `currency`            VARCHAR(8) NOT NULL DEFAULT '',
                `date_added`          DATETIME NOT NULL,
                `date_modified`       DATETIME NOT NULL,
                PRIMARY KEY (`paylater_transaction_id`),
                UNIQUE KEY `order_id` (`order_id`),
                KEY `merchant_order_id` (`merchant_order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");

        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "paylater_log` (
                `paylater_log_id` INT(11) NOT NULL AUTO_INCREMENT,
                `order_id`        INT(11) NOT NULL,
                `type`            VARCHAR(64) NOT NULL DEFAULT '',
                `raw_request`     TEXT,
                `raw_response`    TEXT,
                `date_added`      DATETIME NOT NULL,
                PRIMARY KEY (`paylater_log_id`),
                KEY `order_id` (`order_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ");
    }

    public function uninstall(): void {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "paylater_transaction`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "paylater_log`");
    }

    // ── Transaction lookup ────────────────────────────────────────────────
    public function getTransaction(int $order_id): array {
        $query = $this->db->query("
            SELECT * FROM `" . DB_PREFIX . "paylater_transaction`
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
        return $query->row ?: [];
    }

    // ── Full refund ───────────────────────────────────────────────────────
    // GET {base}/api/paylater/merchant-portal/web-checkout/refund
    //     ?merchantId=...&transactionReference={merchant_order_id}&transactionType=DOWN_PAYMENT
    public function refundFull(int $order_id): array {
        $tx = $this->getTransaction($order_id);

        if (!$tx) {
            return ['success' => false, 'error' => 'No PayLater transaction found for this order.'];
        }

        if (empty($tx['merchant_order_id'])) {
            return ['success' => false, 'error' => 'Merchant order reference is missing — refund not possible.'];
        }

        if ((float)$tx['refunded_amount'] > 0) {
            return ['success' => false, 'error' => 'Order has already been refunded (full or partial).'];
        }

        $url = $this->getBaseUrl()
             . '/api/paylater/merchant-portal/web-checkout/refund'
             . '?merchantId='           . urlencode($this->getMerchantId())
             . '&transactionReference=' . urlencode($tx['merchant_order_id'])
             . '&transactionType=DOWN_PAYMENT';

        $response = $this->curlGet($url);
        $this->logTransaction($order_id, 'refund_full', $url, $response['raw']);

        $data = json_decode($response['raw'], true) ?: [];

        if ($response['http_code'] === 200 && !empty($data['message']) && empty($data['error'])) {
            $this->markRefunded($order_id, (float)$tx['amount']);
            return [
                'success' => true,
                'message' => $data['message'],
                'amount'  => (float)$tx['amount'],
            ];
        }

        $error = $data['error'] ?? ('HTTP ' . $response['http_code']);
        if (!empty($data['message'])) {
            $error .= ': ' . $data['message'];
        }
        return ['success' => false, 'error' => $error];
    }

    // ── Partial refund ────────────────────────────────────────────────────
    // POST {base}/api/paylater/merchant-portal/web-checkout/refund/partial
    //     ?merchantId=...&transactionReference={merchant_order_id}
    //     Body: { "amount": <less than total> }
    //
    // Note: PayLater's documentation labels transactionReference as "PayLater Order ID"
    // but the live API rejects the PL... format. It accepts the merchant order id
    // (e.g. "OC-10-1777978383") same as the full refund endpoint.
    public function refundPartial(int $order_id, float $amount): array {
        $tx = $this->getTransaction($order_id);

        if (!$tx) {
            return ['success' => false, 'error' => 'No PayLater transaction found for this order.'];
        }

        if (empty($tx['merchant_order_id'])) {
            return ['success' => false, 'error' => 'Merchant order reference is missing — partial refund not possible.'];
        }

        if ($amount <= 0) {
            return ['success' => false, 'error' => 'Refund amount must be greater than zero.'];
        }

        $remaining = (float)$tx['amount'] - (float)$tx['refunded_amount'];
        if ($amount >= (float)$tx['amount']) {
            return ['success' => false, 'error' => 'Partial refund must be less than total order value. Use full refund instead.'];
        }
        if ($amount > $remaining) {
            return ['success' => false, 'error' => 'Refund amount exceeds remaining refundable amount (' . number_format($remaining, 2) . ').'];
        }

        $url = $this->getBaseUrl()
             . '/api/paylater/merchant-portal/web-checkout/refund/partial'
             . '?merchantId='           . urlencode($this->getMerchantId())
             . '&transactionReference=' . urlencode($tx['merchant_order_id']);

        $body = json_encode(['amount' => $amount]);

        $response = $this->curlPost($url, $body);
        $this->logTransaction($order_id, 'refund_partial', $url . ' :: ' . $body, $response['raw']);

        $data = json_decode($response['raw'], true) ?: [];

        if ($response['http_code'] === 200 && !empty($data['message']) && empty($data['error'])) {
            $this->incrementRefunded($order_id, $amount);
            return [
                'success' => true,
                'message' => $data['message'],
                'amount'  => $amount,
            ];
        }

        $error = $data['error'] ?? ('HTTP ' . $response['http_code']);
        if (!empty($data['message'])) {
            $error .= ': ' . $data['message'];
        }
        return ['success' => false, 'error' => $error];
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private function markRefunded(int $order_id, float $amount): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `refunded_amount` = '" . (float)$amount . "',
                `status`          = 'refunded',
                `date_modified`   = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    private function incrementRefunded(int $order_id, float $amount): void {
        $this->db->query("
            UPDATE `" . DB_PREFIX . "paylater_transaction`
            SET `refunded_amount` = `refunded_amount` + '" . (float)$amount . "',
                `status`          = 'partial_refund',
                `date_modified`   = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    // Add an order history entry AND update oc_order.order_status_id.
    // OC4 admin's model_sale_order doesn't expose addHistory, so we write directly.
    public function addOrderHistory(int $order_id, int $order_status_id, string $comment = '', bool $notify = false): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "order_history`
                SET `order_id`        = '" . (int)$order_id . "',
                    `order_status_id` = '" . (int)$order_status_id . "',
                    `notify`          = '" . (int)$notify . "',
                    `comment`         = '" . $this->db->escape($comment) . "',
                    `date_added`      = NOW()
        ");

        $this->db->query("
            UPDATE `" . DB_PREFIX . "order`
            SET `order_status_id` = '" . (int)$order_status_id . "',
                `date_modified`   = NOW()
            WHERE `order_id` = '" . (int)$order_id . "'
        ");
    }

    // Add a comment-only history row WITHOUT changing oc_order.order_status_id.
    // The history row carries the order's current status so the timeline stays consistent.
    public function addOrderComment(int $order_id, string $comment, bool $notify = false): void {
        $row = $this->db->query("
            SELECT `order_status_id` FROM `" . DB_PREFIX . "order`
            WHERE `order_id` = '" . (int)$order_id . "'
        ")->row;
        $current_status_id = (int)($row['order_status_id'] ?? 0);

        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "order_history`
                SET `order_id`        = '" . (int)$order_id . "',
                    `order_status_id` = '" . $current_status_id . "',
                    `notify`          = '" . (int)$notify . "',
                    `comment`         = '" . $this->db->escape($comment) . "',
                    `date_added`      = NOW()
        ");
    }

    private function logTransaction(int $order_id, string $type, string $request, string $response): void {
        $this->db->query("
            INSERT INTO `" . DB_PREFIX . "paylater_log`
                SET `order_id`     = '" . (int)$order_id . "',
                    `type`         = '" . $this->db->escape($type) . "',
                    `raw_request`  = '" . $this->db->escape($request) . "',
                    `raw_response` = '" . $this->db->escape($response) . "',
                    `date_added`   = NOW()
        ");
    }

    private function getBaseUrl(): string {
        $mode = $this->config->get('payment_paylater_mode') ?: 'uat';
        return $mode === 'production'
            ? rtrim($this->config->get('payment_paylater_production_url'), '/')
            : rtrim($this->config->get('payment_paylater_uat_url'), '/');
    }

    private function getApiKey(): string {
        return $this->config->get('payment_paylater_api_key') ?: '';
    }

    private function getMerchantId(): string {
        return $this->config->get('payment_paylater_merchant_id') ?: '';
    }

    private function curlGet(string $url): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_HTTPGET         => true,
            CURLOPT_HTTPHEADER      => [
                'Accept: application/json',
                'x-api-key: ' . $this->getApiKey(),
            ],
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }

    private function curlPost(string $url, string $body): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POSTFIELDS      => $body,
            CURLOPT_HTTPHEADER      => [
                'Content-Type: application/json',
                'Accept: application/json',
                'x-api-key: ' . $this->getApiKey(),
            ],
            CURLOPT_TIMEOUT         => 30,
            CURLOPT_SSL_VERIFYPEER  => true,
        ]);
        $raw       = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $raw = json_encode(['curl_error' => curl_error($ch)]);
        }
        curl_close($ch);
        return ['raw' => $raw ?: '', 'http_code' => $http_code];
    }
}
