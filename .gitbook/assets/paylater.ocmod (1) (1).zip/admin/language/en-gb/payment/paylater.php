<?php
// Heading
$_['heading_title']          = 'PayLater BNPL';
$_['text_edit']              = 'Edit PayLater Settings';

// Text
$_['text_extension']         = 'Extensions';
$_['text_home']              = 'Home';
$_['text_success']           = 'Success: PayLater settings have been saved!';
$_['text_enabled']           = 'Enabled';
$_['text_disabled']          = 'Disabled';
$_['text_uat']               = 'UAT';
$_['text_production']        = 'Production';

// Entry
$_['entry_status']           = 'Status';
$_['entry_mode']             = 'Mode';
$_['entry_api_key']          = 'API Key';
$_['entry_merchant_id']      = 'Merchant ID';
$_['entry_outlet_id']        = 'Outlet ID';
$_['entry_uat_url']          = 'UAT Base URL';
$_['entry_production_url']   = 'Production Base URL';
$_['entry_sort_order']       = 'Sort Order';
$_['entry_payment_title']    = 'Payment Method Title';
$_['entry_widget_enabled']   = 'Enable BNPL Widget';
$_['entry_widget_plp']       = 'Widget on Product Listing';
$_['entry_widget_pdp']       = 'Widget on Product Detail';
$_['entry_widget_min_amount'] = 'Widget Min Amount (QAR)';
$_['entry_widget_title']     = 'Widget Title Text';
$_['entry_widget_footer']    = 'Widget Footer Text';

// Buttons
$_['button_save']            = 'Save';
$_['button_cancel']          = 'Cancel';

// Webhook
$_['text_webhook']           = 'Webhook Configuration';
$_['entry_webhook_url']      = 'Webhook URL';
$_['entry_webhook_secret']   = 'Webhook Secret';
$_['help_webhook_url']       = 'Share this URL with PayLater. They will configure it in their dashboard to send payment status notifications.';
$_['help_webhook_secret']    = 'Provided by PayLater after they configure the webhook on their side. Used to validate incoming webhook signatures (HMAC-SHA256).';
$_['button_copy']            = 'Copy';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify PayLater!';
$_['error_api_key']          = 'Warning: API Key is required!';
$_['error_merchant_id']      = 'Warning: Merchant ID is required!';
$_['error_outlet_id']        = 'Warning: Outlet ID is required!';
