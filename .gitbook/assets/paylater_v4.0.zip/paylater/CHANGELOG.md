# PayLater Pro for WooCommerce — Changelog

All notable changes to this plugin will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.4.0] — 2 June 2026

Breaking release. PayLater's gateway API has moved to OAuth2 Bearer authentication with versioned `/v2/` endpoints and snake_case payload fields. Merchants must obtain new Client ID and Client Secret credentials from PayLater Operations and re-enter them in the admin before placing any orders on 1.4.0.

### Breaking

- Authentication switched from `x-api-key` to OAuth2 Bearer. All outbound calls (create payment link, status verification, refund, partial refund) acquire an access token via the `client_credentials` grant against `…/auth/realms/api/protocol/openid-connect/token` and present it as `Authorization: Bearer <token>`. The `x-api-key` header is removed.
- Endpoints moved to `/v2/web-checkout` on both UAT (`connect.uat.paylaterapp.com`) and production (`connect.paylaterapp.com`).
- Payload field names are snake_case: `outletId → outlet_id`, `orderId → order_id`, `successRedirectUrl → success_redirect_url`, `failRedirectUrl → fail_redirect_url`. `merchantId` is no longer sent on any request because the access token identifies the merchant.
- `expiry_duration` is required on create-payment-link. Configurable in admin, defaults to 10 minutes.
- Full and partial refunds collapse onto one endpoint, `POST …/v2/web-checkout/refund`. Full refund body is `{ "order_id": "<ref>" }`. Partial refund adds `"amount": "<2dp string>"`. The previous separate `GET /refund` and `POST /refund/partial` endpoints are gone.
- Admin settings rearranged. The Test API Key, Live API Key, and Merchant ID fields are removed (the access token now identifies the merchant). New fields: Test Client ID, Test Client Secret, Live Client ID, Live Client Secret, Payment Link Expiry.

### Added

- `includes/request/wc-paylater-auth.php` OAuth2 token manager with a three-tier lifecycle:
  1. If a cached `access_token` is more than 60 seconds away from expiry, use it.
  2. Else, if a cached `refresh_token` is still valid, exchange it via the `refresh_token` grant (no client_secret round-trip in the happy path).
  3. Else, fall back to a full `client_credentials` grant.
- Token cache stores absolute expiry timestamps (`access_expires_at`, `refresh_expires_at`) per environment in independent WordPress transients (`paylater_token_test` / `paylater_token_live`), so the hot path is a single integer compare.
- Rotated refresh tokens are written back to the cache. If the server doesn't rotate, the previous refresh token is preserved.
- `refresh_expires_in: 0` (Keycloak shorthand for "no enforced expiry") is treated as a long-lived 30-day window so the refresh path is still attempted.
- Transparent 401 retry. Every outbound call uses helper wrappers (`paylater_post_with_bearer` / `paylater_get_with_bearer`) that re-enter the auth lifecycle and retry once if the gateway returns 401. Refresh is tried before falling back to client_credentials.
- Cached tokens are dropped automatically when an admin saves the gateway settings, so credential updates take effect on the next call without manual cache flush.
- Surfaces PayLater's `error_description` verbatim on auth failures, e.g. *"PayLater auth failed: Invalid client or Invalid client credentials"*.
- Payment Link Expiry admin field, configurable in minutes, default 10, minimum 1.

### Changed

- The redirect-return `/status` check now uses `?order_id=<stored_ref>` and Bearer auth. Server-side `orderId` binding via `hash_equals` against the stored merchant reference is preserved.
- `outlet_id` is cast to integer when the configured value is numeric, matching the spec example (`1000000594`).
- `amount` on partial refund is sent as a 2-decimal-place string (e.g. `"39.00"`) to match the gateway's documented example.

### Unchanged

- Webhook handler. The webhook flow is signature-based (HMAC-SHA-256 of an MD5 over the uppercased concat) and independent of the OAuth2 changes.
- Status verification still treats integer `status === 2` as success and falls back to the on-hold branch otherwise.
- Refund and partial refund still record an order note saying the request was accepted and final settlement will be confirmed via webhook.

### Removed

- `assets/js/paylater-woocommerce-checkout.js` (25 KB). Shipped in earlier builds but never enqueued by any PHP. Confirmed dead asset.
- `$type` parameter from `processPaylaterPayment()`. Passed in but never read.

### Upgrade notes

1. Obtain new credentials from PayLater Operations first. Client ID and Client Secret per environment.
2. Deactivate the previous PayLater plugin.
3. Upload `paylater-1.4.0.zip` via Plugins → Add New → Upload Plugin → Install Now.
4. Activate. Settings other than the API keys are preserved.
5. Paste the new Client ID and Client Secret for each environment under WooCommerce → Settings → Payments → PayLater → API Configuration, set the Payment Link Expiry if you want anything other than 10 minutes, and save.
6. Drain in-flight checkout traffic before swapping. Orders that started against the old API will fail their post-redirect `/status` check after upgrade and need manual reconciliation.

---

## [1.3.2] — 18 May 2026

Webhook idempotency hardening.

### Changed

- Webhook handler's success-event idempotency check now skips `processing`, `completed`, `refunded`, and `cancelled` orders. Previously only `processing` and `completed` were covered, so a late-arriving `success` event on a refunded order could trigger a misleading "payment confirmed" note. The note now includes the actual current status for traceability.

---

## [1.3.1] — 6 May 2026

Patch on top of 1.3.0. Fixes the partial-refund request so it uses the correct transaction reference field.

### Fixed

- Partial refund now uses the merchant order ID for `transactionReference`, matching the full-refund endpoint. The 1.3.0 build sent the PayLater Order ID based on the original spec wording, which would have been rejected by the gateway.

### Changed

- Partial refunds are no longer gated on plugin version. The 1.3.0 build refused partial refunds on orders paid before 1.2.0 because `_paylater_order_id` was not captured. That dependency is gone, so partial refunds now work on any PayLater order.

---

## [1.3.0] — 5 May 2026

Adds refunds (full and partial) and a webhook listener for asynchronous status confirmation from PayLater.

### Added

- Refund support. `'refunds'` is back on `$supports`, so the WooCommerce order-edit screen shows "Refund via PayLater" again.
- Full refunds via `GET /refund` with `transactionReference=<merchant_ref>` and `transactionType=DOWN_PAYMENT`.
- Partial refunds via `POST /refund/partial`.
- Webhook listener at `<your-site>/?wc-api=paylater_webhook`. Signature verification mirrors PayLater's PHP sample: `txHash = md5(strtoupper(merchantId+orderId+status+timestamp+comments))`, `signature = hmac_sha256(txHash, merchantWebhookSecret)`. Uses `hash_equals` for both comparisons.
- Webhook handler is idempotent and always returns 200 (with a JSON body) for unrecoverable states such as order-not-found, so PayLater's retry queue doesn't loop on stale events. Returns 403 only for invalid signature or txHash, 503 if no secret is configured.
- New "Webhook" section under the API Configuration tab with Test Webhook Secret and Live Webhook Secret fields. Webhook URL displayed inline for easy hand-off to PayLater Operations.

### Notes

- `process_refund` returns `true` on gateway accept and adds an order note saying "request accepted, final settlement via webhook" to be honest about the async nature.
- Errors from the gateway are surfaced verbatim so admins see the real reason rather than a generic decline.

---

## [1.2.0] — 29 April 2026

Security fix and corrects a verification bug that caused successful payments to be parked on hold. All merchants on 1.1.0 should upgrade.

### Security

- The callback `orderId` is now bound to the order's stored reference using a constant-time comparison. Previously, an attacker holding a successful PayLater transaction could complete an unrelated shopper's order by manipulating the return URL.
- Server-side `/status` lookup uses the stored reference, not the URL parameter.
- Order is rejected if it was not initiated through PayLater.
- All redirects switched to `wp_safe_redirect()` to prevent off-host redirection.
- `absint()` applied to the order ID read from the callback URL.

### Fixed

- Status verification now reads the integer status code returned by the gateway (`1` pending, `2` success, `3` failed). The previous build checked for string values such as `SUCCESS`, `PAID`, `COMPLETED`, none of which the API returns. The result was that every verified payment fell through to the on-hold branch and required manual reconciliation.
- Error field parsing aligned with the gateway contract. The handshake and verification calls now read `error` from the response body. The previous build read `message`.
- Sandbox endpoint corrected from `connect-sandbox.paylaterapp.com` to `connect.uat.paylaterapp.com`.
- Duplicate hook registration removed. `process_admin_options` is now registered once.
- Currency in PDP and PLP widgets is now dynamic via `get_woocommerce_currency()`. Previously hardcoded to `QAR`.
- Instalment dates in the PDP widget now respect the site's WordPress timezone via `wp_date()`.

### Changed

- Refund flow removed for this release. The plugin no longer registers `'refunds'` capability, no longer ships a refund handler, and no longer adds the "Refund via PayLater" button on the WooCommerce order edit screen. (Reinstated in 1.3.0.)
- Maximum order amount check removed. The plugin no longer caps cart totals at 4000 on the storefront.
- Minimum order amount is enforced at 300 both client-side (HTML `min` attribute) and server-side (`validate_order_min_field` rejects any save below 300). Default value remains 300.

---

## Known follow-ups across releases

- `expiry_duration` units assumed to be minutes based on the spec example. Confirm with PayLater Operations before going live.
- Webhook URL on PayLater's side must include a trailing slash before the query string. PayLater's Java HTTP client does not follow 301 redirects on POST.
- Webhook event types are not differentiated. PayLater's payload carries only `status: success/failed/pending` with no `eventType` field.
- Sharia and Legal sign-off still pending on the default merchant-facing widget copy and refund order-note wording.
