<?php
/**
 * PayLater Pro Gateway Parameters
 * Centralized loader for all Pro-tier configuration and API endpoints.
 */

defined( 'ABSPATH' ) || exit;

function gatewayPaylaterParameters( $th, $title ) {
    $th->id                 = 'paylater_shop_now_pay_later';
    $th->icon               = apply_filters( 'woocommerce_paylater_icon', 'https://paylaterapp.com/wp-content/uploads/2024/12/paylater-logo.svg' );
    $th->has_fields         = false;
    $th->method_title       = $title;
    $th->method_description = __( 'PayLater Payment Gateway.', 'paylater' );

    $th->supports = array( 'products', 'refunds' );

    $th->init_settings();

    // General
    $th->enabled     = $th->get_option( 'enabled' );
    $th->title       = $th->get_option( 'title' );
    $th->description = $th->get_option( 'description' );
    $th->order_min   = $th->get_option( 'order_min', '300' );

    // PDP / PLP display
    $th->show_pdp_widget  = $th->get_option( 'show_pdp_widget', 'yes' );
    $th->pdp_main_message = $th->get_option( 'pdp_main_message', __( 'Pay with PayLater', 'paylater' ) );
    $th->pdp_sub_message  = $th->get_option( 'pdp_sub_message', __( 'Interest-free', 'paylater' ) );

    $th->show_plp_widget  = $th->get_option( 'show_plp_widget', 'yes' );
    $th->plp_main_message = $th->get_option( 'plp_main_message', __( 'Pay with PayLater', 'paylater' ) );
    $th->plp_sub_message  = $th->get_option( 'plp_sub_message', __( 'Interest-free', 'paylater' ) );

    // API credentials (OAuth2 client_credentials, mode-resolved)
    $th->testMode     = $th->get_option( 'testMode' ) === 'yes';
    $th->clientId     = $th->testMode ? $th->get_option( 'testClientId' ) : $th->get_option( 'clientId' );
    $th->clientSecret = $th->testMode ? $th->get_option( 'testClientSecret' ) : $th->get_option( 'clientSecret' );
    $th->outletId     = $th->get_option( 'outletId' );

    $th->paymentExpiryMinutes = (int) $th->get_option( 'paymentExpiryMinutes', 10 );
    if ( $th->paymentExpiryMinutes < 1 ) {
        $th->paymentExpiryMinutes = 10;
    }

    // v2 web-checkout endpoints
    $th->api = $th->testMode
        ? 'https://connect.uat.paylaterapp.com/api/paylater/merchant-portal/v2/web-checkout'
        : 'https://connect.paylaterapp.com/api/paylater/merchant-portal/v2/web-checkout';
}
