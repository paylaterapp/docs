<?php
/**
 * PayLater Pro - OAuth2 Token Manager
 *
 * Lifecycle:
 *   1. If a cached access_token is present and not yet within 60s of expiry, use it.
 *   2. Else if a cached refresh_token is still valid, exchange it via the
 *      refresh_token grant (no client_secret round-trip in the happy path).
 *   3. Else fall back to a full client_credentials grant.
 *
 * Tokens for the two environments (test, live) are stored in independent
 * transients so switching Test Mode never returns the wrong token.
 */

defined( 'ABSPATH' ) || exit;

function paylater_token_endpoint( $test_mode ) {
    return $test_mode
        ? 'https://connect.uat.paylaterapp.com/auth/realms/api/protocol/openid-connect/token'
        : 'https://connect.paylaterapp.com/auth/realms/api/protocol/openid-connect/token';
}

function paylater_token_transient_key( $test_mode ) {
    return $test_mode ? 'paylater_token_test' : 'paylater_token_live';
}

/**
 * Returns a Bearer access token. Follows the cache → refresh → client_credentials
 * lifecycle described in the file header.
 *
 * @param object $th             Gateway instance (provides clientId, clientSecret, testMode).
 * @param bool   $force_refresh  Skip the cached access_token check (still tries refresh first).
 * @throws Exception when credentials are missing or both grants fail.
 */
function paylater_get_access_token( $th, $force_refresh = false ) {
    $test_mode = ! empty( $th->testMode );
    $cache_key = paylater_token_transient_key( $test_mode );
    $now       = time();

    $cached = get_transient( $cache_key );
    if ( ! is_array( $cached ) ) {
        $cached = null;
    }

    // 1. Cached access token still valid (60s safety margin).
    if ( ! $force_refresh
         && $cached
         && ! empty( $cached['access_token'] )
         && $now < ( (int) ( $cached['access_expires_at'] ?? 0 ) - 60 ) ) {
        return (string) $cached['access_token'];
    }

    // 2. Refresh token still valid → refresh_token grant.
    if ( $cached
         && ! empty( $cached['refresh_token'] )
         && $now < ( (int) ( $cached['refresh_expires_at'] ?? 0 ) - 60 ) ) {
        try {
            $token_data = paylater_fetch_token_via_refresh( $th, (string) $cached['refresh_token'] );
            paylater_store_token( $cache_key, $token_data, $now, $cached );
            return (string) $token_data['access_token'];
        } catch ( Exception $e ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( 'PayLater refresh_token grant failed, falling back to client_credentials: ' . $e->getMessage() );
            }
            // Fall through to client_credentials.
        }
    }

    // 3. Full client_credentials grant.
    $token_data = paylater_fetch_token_via_client_credentials( $th );
    paylater_store_token( $cache_key, $token_data, $now );
    return (string) $token_data['access_token'];
}

/**
 * Drop the cached token entirely. Forces a full re-auth on the next call.
 * Used when admins save new credentials.
 */
function paylater_invalidate_token( $th ) {
    $test_mode = ! empty( $th->testMode );
    delete_transient( paylater_token_transient_key( $test_mode ) );
}

/**
 * Exchanges client_id + client_secret for a fresh token pair.
 */
function paylater_fetch_token_via_client_credentials( $th ) {
    $client_id     = isset( $th->clientId ) ? trim( (string) $th->clientId ) : '';
    $client_secret = isset( $th->clientSecret ) ? trim( (string) $th->clientSecret ) : '';

    if ( $client_id === '' || $client_secret === '' ) {
        throw new Exception( __( 'PayLater client ID or client secret is not configured.', 'paylater' ) );
    }

    return paylater_request_token( $th, array(
        'grant_type'    => 'client_credentials',
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
    ) );
}

/**
 * Exchanges an existing refresh_token for a fresh access_token (and usually a rotated refresh_token).
 */
function paylater_fetch_token_via_refresh( $th, $refresh_token ) {
    $client_id     = isset( $th->clientId ) ? trim( (string) $th->clientId ) : '';
    $client_secret = isset( $th->clientSecret ) ? trim( (string) $th->clientSecret ) : '';

    if ( $client_id === '' || $client_secret === '' ) {
        throw new Exception( __( 'PayLater client ID or client secret is not configured.', 'paylater' ) );
    }

    return paylater_request_token( $th, array(
        'grant_type'    => 'refresh_token',
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
        'refresh_token' => (string) $refresh_token,
    ) );
}

/**
 * Internal: POST to the token endpoint and parse the response.
 *
 * @throws Exception on transport failure, non-200, or malformed payload.
 */
function paylater_request_token( $th, array $body ) {
    $test_mode = ! empty( $th->testMode );

    $response = wp_remote_post( paylater_token_endpoint( $test_mode ), array(
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept'       => 'application/json',
        ),
        'body'    => $body,
        'timeout' => 30,
    ) );

    if ( is_wp_error( $response ) ) {
        throw new Exception( $response->get_error_message() );
    }

    $decoded = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( ! is_array( $decoded ) || empty( $decoded['access_token'] ) ) {
        $error = '';
        if ( is_array( $decoded ) ) {
            if ( ! empty( $decoded['error_description'] ) ) {
                $error = (string) $decoded['error_description'];
            } elseif ( ! empty( $decoded['error'] ) ) {
                $error = (string) $decoded['error'];
            }
        }
        throw new Exception(
            $error !== ''
                ? sprintf( __( 'PayLater auth failed: %s', 'paylater' ), $error )
                : __( 'PayLater auth failed: no access token in response.', 'paylater' )
        );
    }

    return $decoded;
}

/**
 * Persist a token response to the transient cache. Computes absolute expiry
 * timestamps so the get_access_token() check is a simple integer compare.
 *
 * @param string     $cache_key  Transient key for the current environment.
 * @param array      $data       Decoded token endpoint response.
 * @param int        $now        Wall-clock time at the start of the grant call.
 * @param array|null $previous   Existing cache contents, used to preserve a
 *                               refresh_token if the server didn't rotate it.
 */
function paylater_store_token( $cache_key, array $data, $now, $previous = null ) {
    $access_lifetime  = isset( $data['expires_in'] ) ? (int) $data['expires_in'] : 3600;
    $refresh_lifetime = isset( $data['refresh_expires_in'] ) ? (int) $data['refresh_expires_in'] : 0;

    // refresh_expires_in == 0 is Keycloak shorthand for "no enforced expiry" on
    // some realm configurations. Treat as a long-lived value so we still try
    // refresh before falling back to client_credentials.
    if ( $refresh_lifetime <= 0 ) {
        $refresh_lifetime = 30 * DAY_IN_SECONDS;
    }

    $refresh_token = isset( $data['refresh_token'] ) ? (string) $data['refresh_token'] : '';
    if ( $refresh_token === '' && $previous && ! empty( $previous['refresh_token'] ) ) {
        // Server didn't rotate the refresh token; reuse the previous one.
        $refresh_token = (string) $previous['refresh_token'];
    }

    $cache = array(
        'access_token'       => (string) $data['access_token'],
        'access_expires_at'  => $now + max( 60, $access_lifetime ),
        'refresh_token'      => $refresh_token,
        'refresh_expires_at' => $refresh_token !== '' ? ( $now + $refresh_lifetime ) : 0,
    );

    // Transient TTL keyed to whichever credential lives longer so we don't lose
    // the refresh token before it would actually expire.
    $ttl = max( 60, $cache['refresh_expires_at'] - $now, $cache['access_expires_at'] - $now );
    set_transient( $cache_key, $cache, $ttl );
}
