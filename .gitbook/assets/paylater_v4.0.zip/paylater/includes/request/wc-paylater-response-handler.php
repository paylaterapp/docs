<?php
/**
 * PayLater Pro - Response Handler
 * Processes the return/callback from the PayLater portal with server-side verification.
 */

defined( 'ABSPATH' ) || exit;

function paylaterResponseHandler($th) {
    try {
        // 1. Sanitize and Validate Request Parameters
        $order_id          = isset($_GET['o']) ? absint($_GET['o']) : 0;
        $status            = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : null;
        $callback_order_id = isset($_GET['orderId']) ? sanitize_text_field($_GET['orderId']) : '';

        if (!$order_id) {
            throw new Exception(__('Order ID not found in response.', 'paylater'));
        }

        // 2. Load Order Object (HPOS Compatible)
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            throw new Exception(__('Invalid order received.', 'paylater'));
        }

        // 3. Confirm this order was actually started against PayLater.
        // Defends against an attacker probing arbitrary order IDs.
        if ($order->get_payment_method() !== $th->id) {
            throw new Exception(__('Order was not initiated through PayLater.', 'paylater'));
        }

        // 4. Bind the callback orderId to the reference we stored at handshake time.
        // Without this check, an attacker holding any successful PayLater orderId
        // could complete a different shopper's order by passing it in the URL.
        $stored_ref = (string) $order->get_meta('_paylater_unique_ref');

        if ($stored_ref === '' || !hash_equals($stored_ref, $callback_order_id)) {
            $order->add_order_note(__('PayLater callback rejected: orderId mismatch.', 'paylater'));
            throw new Exception(__('Order reference mismatch.', 'paylater'));
        }

        // 5. Prevent Duplicate Processing
        if ($order->has_status(array('completed', 'processing'))) {
            wp_safe_redirect($order->get_checkout_order_received_url());
            exit;
        }

        // 6. Handle Success Callback ('s') with Server-Side Verification
        if ($status === 's') {

            // Always call /status with the server-side stored ref, not the
            // user-supplied query param.
            $base_api   = rtrim($th->api, '/');
            $status_url = add_query_arg(
                array( 'order_id' => $stored_ref ),
                $base_api . '/status'
            );

            try {
                $response = paylater_get_with_bearer( $th, $status_url );
            } catch ( Exception $auth_e ) {
                $response = new WP_Error( 'paylater_auth', $auth_e->getMessage() );
            }

            $is_verified  = false;
            $api_status   = null;
            $api_message  = '';
            $payLaterId   = '';

            if (!is_wp_error($response)) {
                $response_data = json_decode(wp_remote_retrieve_body($response), true);

                if (is_array($response_data)) {
                    $api_status  = isset($response_data['status']) ? (int) $response_data['status'] : null;
                    $api_message = isset($response_data['message']) ? (string) $response_data['message'] : '';
                    $payLaterId  = isset($response_data['payLaterOrderId']) ? (string) $response_data['payLaterOrderId'] : '';

                    // Gateway contract: 1=pending, 2=success, 3=failed.
                    if ($api_status === 2) {
                        $is_verified = true;
                    }
                }
            }

            if ($is_verified) {
                // Record the gateway's own transaction id, not the merchant ref.
                $order->payment_complete($payLaterId !== '' ? $payLaterId : $stored_ref);

                if ($payLaterId !== '') {
                    $order->update_meta_data('_paylater_order_id', $payLaterId);
                    $order->save();
                }

                $order->add_order_note(sprintf(
                    __('PayLater Pro: Payment Verified. PayLater Order ID: %s', 'paylater'),
                    $payLaterId !== '' ? $payLaterId : $stored_ref
                ));

                if (WC()->cart) {
                    WC()->cart->empty_cart();
                }
                wp_safe_redirect($order->get_checkout_order_received_url());
                exit;
            } else {
                // API check failed or returned a non-success status (1=pending, 3=failed).
                $note = sprintf(
                    __('Payment callback received but API verification failed (status=%1$s, message=%2$s). Manual check required.', 'paylater'),
                    $api_status === null ? 'n/a' : (string) $api_status,
                    $api_message !== '' ? $api_message : 'n/a'
                );
                $order->update_status('on-hold', $note);
                wc_add_notice(__('Your payment is being verified. Please contact support if your order does not update shortly.', 'paylater'), 'notice');
                wp_safe_redirect($order->get_checkout_order_received_url());
                exit;
            }
        }

        // 7. Handle Failure Callback ('f')
        else if ($status === 'f') {
            $order->update_status('failed', __('User returned from PayLater with failure status.', 'paylater'));
            wc_add_notice(__('Payment was declined or cancelled. Please try another method.', 'paylater'), 'error');
            wp_safe_redirect(wc_get_checkout_url());
            exit;
        }

        // 8. Handle Unknown/Unexpected Status
        else {
            $order->add_order_note(__('Unknown payment status received from gateway callback.', 'paylater'));
            wp_safe_redirect($order->get_cancel_order_url());
            exit;
        }

    } catch (Exception $e) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PayLater Pro Response Error: ' . $e->getMessage());
        }
        wc_add_notice($e->getMessage(), 'error');
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }
}
