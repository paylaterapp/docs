/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

var isSuccess = false;
var isFail = false;
var isDeclined = false;
var failedCheckOutStatus = 'FAILED';
var submittedCheckOutStatus = 'SUBMITTED';
var successCheckOutStatus = 'SUCCESS';
var toggleFlag = true;
var jsonData;
var rejectUrl;
var confirmUrl;
var popup = true;
const root = document.getElementsByTagName('body')[0];
var hidePopup = false;
var buttonOnce = true;
//Build lightbox component
var button1 = document.createElement('button');
button1.style.display='none';
button1.id = 'closeclick';
button1.textContent = 'set overlay closeClick to false';
var bodyTag=document.getElementsByTagName('body')[0];
bodyTag.appendChild(button1);

var button2 = document.createElement('button');
button2.style.display='none';
button2.id = 'closeiframebtn';
button2.textContent = 'set overlay closeClick to false';
bodyTag.appendChild(button2);

var a1 = document.createElement('a');
a1.id = 'fancy';
a1.style.display='none';
a1.classList= 'fancy-box lightbox';
a1.textContent ='open lightbox';
a1.href='';
bodyTag.appendChild(a1);

var LoadCSS = function (filename) {
  var fileref = document.createElement("link");
  fileref.setAttribute("rel", "stylesheet");
  fileref.setAttribute("type", "text/css");
  fileref.setAttribute("href", filename);
  document.getElementsByTagName("head")[0].appendChild(fileref);
};
LoadCSS("https://widget.spotii.me/v1/javascript/iframe-lightbox.min.css");
var script = document.createElement('script');
script.type = 'text/javascript';
script.src = 'https://widget.spotii.me/v1/javascript/iframe-lightbox.min.js';
document.getElementsByTagName('body')[0].appendChild(script);
//-----------------

//Check if browser support the popup
const thirdPartySupported = root => {
  return new Promise((resolve, reject) => {
    const receiveMessage = function(evt) {
      if (evt.data === 'MM:3PCunsupported') {
        reject();
      } else if (evt.data === 'MM:3PCsupported') {
        resolve();
      }
    };
    window.addEventListener('message', receiveMessage, false);
    const frame = createElement('iframe', {
      src: 'https://mindmup.github.io/3rdpartycookiecheck/start.html',
    });
    frame.style.display = 'none';
    root.appendChild(frame);
  });
};

//Redirect to PayLater
const redirectToSpotiiCheckout = function(checkoutUrl, timeout) {
  setTimeout(function() {
    window.location = checkoutUrl;
  }, timeout); // 'milli-seconds'
};
//Check if it's a safari broswer
function isMobileSafari() {
  const ua = (window && window.navigator && window.navigator.userAgent) || '';
  const iOS = !!ua.match(/iPad/i) || !!ua.match(/iPhone/i);
  const webkit = !!ua.match(/WebKit/i);
  return iOS && webkit && !ua.match(/CriOS/i);
}

//needed functions for the loadin page
function createElement(tagName, attributes, content) {
  const el = document.createElement(tagName);

  if (attributes) {
      Object.keys(attributes).forEach(function(attr) {
          el[attr] = attributes[attr];
      });
  }

  if (content && content.nodeType === Node.ELEMENT_NODE) {
      el.appendChild(content);
  } else {
      el.innerHTML = content;
  }

  return el;
}

function Spinner() {
  const span = createElement('span');
  span.className = 'sptii-loading-icon';
  span.innerHTML =
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 1024 1024"><path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 0 0-94.3-139.9 437.71 437.71 0 0 0-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z" fill="orange" /></svg>';
  return span;
}
function Logo() {
  const span = createElement("span");
  span.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="Layer_1" data-name="Layer 1" viewBox="318.31 161.9 803.24 198.13"><defs><style>.cls-1{clip-path:url(#clippath)}.cls-2{fill:none}.cls-2,.cls-3,.cls-4,.cls-5,.cls-6,.cls-7,.cls-8,.cls-9{stroke-width:0px}.cls-3{fill:url(#radial-gradient)}.cls-4{fill:#413796}.cls-10{clip-path:url(#clippath-1)}.cls-11{clip-path:url(#clippath-2)}.cls-5{fill:#27c5d1}.cls-6{fill:url(#radial-gradient-2)}.cls-7{fill:url(#radial-gradient-3)}.cls-8{fill:url(#radial-gradient-4)}.cls-9{fill:#8369f0}</style><clipPath id="clippath"><path class="cls-2" d="M394.51,311.7c-23.92-.82-43.16-20.07-43.96-44l-3.78,26.92c-3.99,28.39,15.79,51.4,44.17,51.4h19.27c3.55,0,6.83-2.88,7.33-6.42l3.91-27.84h-25.7c-.42,0-.84-.02-1.24-.05Z"/></clipPath><radialGradient id="radial-gradient" cx="371.68" cy="284.24" fx="371.68" fy="284.24" r="53.37" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#a8e5d1"/><stop offset="1" stop-color="#27c5d1"/></radialGradient><clipPath id="clippath-1"><path class="cls-2" d="M466.41,174.69h-51.4c-28.39,0-54.63,23.01-58.62,51.4l-5.85,41.61c.8,23.93,20.04,43.18,43.96,44-8.79-.64-14.75-8.04-13.48-17.08l9.63-68.53c1.33-9.46,10.08-17.13,19.54-17.13h51.4c.39,0,.76.02,1.14.04,24.21.86,43.61,20.59,43.94,44.93l3.91-27.84c3.99-28.39-15.79-51.4-44.17-51.4Z"/></clipPath><radialGradient id="radial-gradient-2" cx="380.53" cy="306.66" fx="380.53" fy="306.66" r="53.37" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#413796"/><stop offset="1" stop-color="#8369f0"/></radialGradient><radialGradient id="radial-gradient-3" cx="476.78" cy="238.61" fx="476.78" fy="238.61" r="42.7" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#b2a2f6"/><stop offset="1" stop-color="#8369f0"/></radialGradient><clipPath id="clippath-2"><path class="cls-2" d="M462.74,209c8.84.59,14.86,8.01,13.59,17.09l-4.82,34.27c-1.33,9.46-10.08,17.13-19.54,17.13h-19.27c-3.55,0-6.83,2.88-7.33,6.42l-3.91,27.84h25.7c28.39,0,54.63-23.01,58.62-51.4l.9-6.43c-.33-24.34-19.73-44.07-43.94-44.93Z"/></clipPath><radialGradient id="radial-gradient-4" cx="483.96" cy="221.9" fx="483.96" fy="221.9" r="46.03" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#211747"/><stop offset="1" stop-color="#413796"/></radialGradient></defs><g><path class="cls-4" d="M616.21,217.98c-5.5-6.17-13.7-9.26-24.6-9.26h-38.77c-2.22,0-3.82.43-4.81,1.3-.99.87-1.64,2.41-1.95,4.63l-12.77,90.86c-.31,2.22-.09,3.76.65,4.63.75.87,2.23,1.3,4.45,1.3h11.72c2.22,0,3.82-.43,4.81-1.3.99-.87,1.64-2.41,1.95-4.63l3.86-27.49h21.12c11,0,20.08-3.06,27.26-9.19,7.18-6.12,11.53-14.59,13.05-25.39,1.52-10.8-.47-19.29-5.97-25.46ZM597.73,243.45c-.58,4.15-2.22,7.36-4.9,9.62-2.68,2.27-6.15,3.4-10.39,3.4h-18.66l3.7-26.33h18.66c4.24,0,7.38,1.18,9.41,3.54,2.03,2.36,2.76,5.62,2.17,9.77Z"/><path class="cls-4" d="M662.04,234.04c-7.72,0-14.34,1.3-19.86,3.91-5.53,2.6-9.93,6.32-13.21,11.14-.85,1.25-1.35,2.36-1.48,3.33-.26,1.83.84,3.28,3.3,4.34l7.51,3.18c1.27.58,2.29.87,3.06.87.87,0,1.63-.24,2.27-.72.65-.48,1.44-1.3,2.37-2.46,3.2-3.57,7.46-5.35,12.76-5.35,3.95,0,6.67.89,8.16,2.68,1.49,1.79,1.97,4.51,1.46,8.17l-.49,3.47c-4.3-.29-7.7-.43-10.21-.43-8.2,0-14.81.72-19.84,2.17-5.03,1.45-8.94,3.88-11.73,7.31-2.8,3.42-4.62,8.13-5.46,14.11-.76,5.4-.42,9.84,1.02,13.31,1.44,3.47,4.47,6.1,9.09,7.89,4.62,1.78,11.17,2.68,19.66,2.68,12.44,0,21.74-1.3,27.89-3.91,2.24-.87,3.8-1.86,4.68-2.97.88-1.11,1.49-2.92,1.85-5.43l5.16-36.75c1.36-9.64-.07-17.14-4.29-22.5-4.22-5.35-12.11-8.03-23.68-8.03ZM663.87,295.1c-.07.48-.45.82-1.16,1.01-2.96.48-6.81.72-11.53.72-3.76,0-6.23-.63-7.4-1.88-1.17-1.25-1.6-3.04-1.27-5.35.33-2.32,1.27-4.1,2.85-5.35,1.57-1.25,4.29-1.88,8.15-1.88,2.61,0,6.64.14,12.09.43l-1.73,12.3Z"/><path class="cls-4" d="M766.7,236.21h-11.29c-1.93,0-3.36.39-4.29,1.16-.93.77-1.53,2.17-1.82,4.2l-6.71,47.73c-3.67.68-7.23,1.01-10.71,1.01-4.15,0-7.11-.87-8.89-2.6-1.78-1.74-2.41-4.49-1.88-8.25l5.33-37.9c.28-2.03.1-3.42-.57-4.2-.66-.77-2.01-1.16-4.03-1.16h-11.14c-2.03,0-3.48.39-4.36,1.16-.88.77-1.46,2.17-1.75,4.2l-5.43,38.62c-1.36,9.65.18,17.05,4.62,22.21,4.43,5.16,11.91,7.74,22.42,7.74,5.5,0,10.03-.34,13.6-1.01l-.83,5.93c-.54,3.86-1.95,6.8-4.21,8.82-2.26,2.03-5.23,3.04-8.89,3.04-2.89,0-5.19-.46-6.9-1.37-1.7-.92-3.1-2.29-4.19-4.12-1.25-2.12-2.64-3.18-4.18-3.18-1.06,0-2.37.38-3.92,1.16l-8.84,4.19c-2.59,1.25-4.01,2.8-4.27,4.63-.18,1.25.12,2.55.9,3.91,4.42,9.07,14.1,13.6,29.05,13.6,11.38,0,20.13-2.87,26.24-8.61,6.11-5.74,9.87-13.63,11.28-23.66l10.1-71.9c.28-2.03.09-3.42-.57-4.2-.66-.77-1.96-1.16-3.89-1.16Z"/><path class="cls-4" d="M841.93,290.03h-37.33l10.59-75.38c.31-2.22.09-3.76-.65-4.63-.75-.87-2.23-1.3-4.45-1.3h-11.72c-2.22,0-3.82.43-4.81,1.3-.99.87-1.64,2.41-1.95,4.63l-12.77,90.86c-.31,2.22-.09,3.76.65,4.63.75.87,2.23,1.3,4.45,1.3h54.98c2.22,0,3.82-.43,4.81-1.3.99-.87,1.64-2.41,1.95-4.63l1.36-9.69c.31-2.22.09-3.74-.66-4.56-.75-.82-2.24-1.23-4.46-1.23Z"/><path class="cls-4" d="M897.08,234.04c-7.72,0-14.34,1.3-19.86,3.91-5.53,2.6-9.93,6.32-13.21,11.14-.85,1.25-1.35,2.36-1.48,3.33-.26,1.83.84,3.28,3.3,4.34l7.51,3.18c1.27.58,2.29.87,3.06.87.87,0,1.63-.24,2.27-.72.65-.48,1.44-1.3,2.37-2.46,3.2-3.57,7.46-5.35,12.76-5.35,3.95,0,6.67.89,8.16,2.68,1.49,1.79,1.97,4.51,1.46,8.17l-.49,3.47c-4.3-.29-7.7-.43-10.21-.43-8.2,0-14.81.72-19.84,2.17-5.03,1.45-8.94,3.88-11.73,7.31-2.8,3.42-4.62,8.13-5.46,14.11-.76,5.4-.42,9.84,1.02,13.31,1.44,3.47,4.47,6.1,9.09,7.89,4.62,1.78,11.17,2.68,19.66,2.68,12.44,0,21.74-1.3,27.89-3.91,2.24-.87,3.8-1.86,4.68-2.97.88-1.11,1.5-2.92,1.85-5.43l5.16-36.75c1.36-9.64-.07-17.14-4.29-22.5-4.22-5.35-12.11-8.03-23.68-8.03ZM898.91,295.1c-.07.48-.45.82-1.16,1.01-2.96.48-6.81.72-11.53.72-3.76,0-6.23-.63-7.4-1.88-1.17-1.25-1.6-3.04-1.27-5.35.33-2.32,1.27-4.1,2.85-5.35,1.57-1.25,4.29-1.88,8.15-1.88,2.61,0,6.64.14,12.09.43l-1.73,12.3Z"/><path class="cls-4" d="M983.5,236.21h-13.46l1.69-12.01c.28-2.03.09-3.42-.57-4.2-.66-.77-1.96-1.16-3.89-1.16h-11.28c-1.93,0-3.36.39-4.29,1.16-.93.77-1.54,2.17-1.82,4.2l-1.69,12.01h-7.67c-2.03,0-3.48.39-4.36,1.16-.88.77-1.46,2.17-1.75,4.2l-1.22,8.68c-.27,1.93-.08,3.3.58,4.12.66.82,2,1.23,4.02,1.23h7.67l-3.23,23c-1.19,8.49-.96,15.1.69,19.82,1.65,4.73,4.87,8.08,9.65,10.06,4.79,1.98,11.52,2.97,20.2,2.97,2.03,0,3.48-.41,4.37-1.23.89-.82,1.48-2.29,1.78-4.41l1.28-9.11c.3-2.12.12-3.57-.55-4.34-.66-.77-2.01-1.16-4.03-1.16-3.47,0-6.08-.34-7.82-1.01-1.74-.67-2.9-1.98-3.5-3.91-.6-1.93-.63-4.77-.1-8.54l3.11-22.14h13.46c1.93,0,3.34-.41,4.22-1.23.89-.82,1.47-2.19,1.74-4.12l1.22-8.68c.28-2.03.1-3.42-.57-4.2-.66-.77-1.96-1.16-3.89-1.16Z"/><path class="cls-4" d="M1120.87,237.37c-.66-.77-2.01-1.16-4.03-1.16h-4.63c-11,0-20.52,1.5-28.55,4.49-2.44.87-4.12,1.88-5.06,3.04-.94,1.16-1.57,2.94-1.91,5.35l-8.01,57c-.28,2.03-.07,3.42.64,4.2.71.77,2.03,1.16,3.96,1.16h11.28c1.93,0,3.33-.38,4.21-1.16.88-.77,1.46-2.17,1.75-4.2l6.79-48.32c.08-.58.42-.92,1.01-1.01,3.08-.67,6.56-1.01,10.41-1.01h5.35c2.03,0,3.48-.38,4.36-1.16.88-.77,1.46-2.12,1.73-4.05l1.26-8.97c.28-2.03.09-3.42-.57-4.2Z"/><path class="cls-4" d="M1055.09,239.95c-5.49-4-12.87-6-22.13-6-11.19,0-20.14,2.56-26.86,7.67-6.72,5.11-10.78,12.44-12.18,21.99l-2.48,16.06c-.38,3.09-.52,5.74-.45,7.96.27,7.81,2.9,14.08,7.89,18.81,4.99,4.73,12.5,7.09,22.53,7.09,16.11,0,27.43-4.39,33.98-13.17,1.29-1.64,1.91-3.18,1.86-4.63-.05-1.45-1.01-2.75-2.88-3.91l-6.5-3.76c-1.58-.96-2.85-1.45-3.81-1.45-.77,0-1.53.27-2.29.8-.75.53-1.64,1.33-2.66,2.39-3.44,3.86-8.48,5.79-15.13,5.79-7.43,0-11.24-2.84-11.44-8.54-.02-.58.04-1.54.19-2.89l.36-2.03c5.02.19,8.74.29,11.15.29,11.48,0,20.63-1.59,27.47-4.77,6.83-3.18,10.74-8.68,11.72-16.49.23-1.64.32-3.18.27-4.63-.25-7.04-3.12-12.56-8.61-16.56ZM1042.09,258.97c-.47,2.99-2.38,5.04-5.72,6.15-3.34,1.11-8.04,1.66-14.12,1.66-3.09,0-5.41-.09-6.95-.29l.45-3.62c.65-3.57,2.28-6.39,4.91-8.46,2.63-2.07,6.01-3.11,10.16-3.11s7.02.65,8.89,1.95c1.88,1.3,2.67,3.21,2.37,5.72Z"/></g><path class="cls-2" d="M432.69,277.48h19.27c9.46,0,18.21-7.67,19.54-17.13l4.82-34.27c1.28-9.08-4.74-16.5-13.59-17.09-.55-.02-1.09-.04-1.64-.04.55,0,1.1.02,1.64.04-.38-.03-.75-.04-1.14-.04h-51.4c-9.46,0-18.21,7.67-19.54,17.13l-9.63,68.53c-1.27,9.04,4.69,16.44,13.48,17.08.53.02,1.06.04,1.6.04-.54,0-1.07-.02-1.6-.04.41.03.82.05,1.24.05h25.7l3.91-27.84c.5-3.55,3.78-6.42,7.33-6.42Z"/><g class="cls-1"><rect class="cls-5" x="347.83" y="297.57" width="87.07" height="58.44"/><circle class="cls-3" cx="371.68" cy="284.24" r="53.37"/></g><g class="cls-10"><rect class="cls-9" x="342.47" y="161.9" width="183.35" height="159.62"/><circle class="cls-6" cx="380.53" cy="306.66" r="53.37"/><circle class="cls-7" cx="476.78" cy="238.61" r="42.7"/></g><g class="cls-11"><rect class="cls-4" x="412.84" y="212.29" width="110.03" height="118.08"/><circle class="cls-8" cx="483.96" cy="221.9" r="46.03"/></g></svg>';
  return span;
}
function SpinTextNode() {
  const text = isMobileSafari() ? 'Redirecting you to PayLater...' : 'Checking your payment status with PayLater...';
  const first= createElement('p', {}, text);
  const cont = createElement('span', {className: 'sptii-text'}, first);
  const spinner = createElement('span', { className: 'sptii-loading' }, Spinner());
  const spinText = createElement('span', { className: 'sptii-spinnerText' }, cont);
  spinText.appendChild(spinner);
  return spinText;
}
//--------------------

//Show the loading page
function showOverlay() {
  const overlay = createElement('div', {className: 'sptii-overlay'}, '');
  const logo = createElement('span', { className: 'sptii-logo' }, Logo());
  document.getElementsByTagName("body")[0].appendChild(overlay);
  overlay.appendChild(logo);
  overlay.appendChild(SpinTextNode());
}

//Remove the loading page
function removeOverlay() {
  var overlay = document.getElementsByClassName("sptii-overlay")[0];
  document.getElementsByTagName("body")[0].removeChild(overlay);
}

//Google tag manager
function onCheckout() {
  if (typeof dataLayer !== 'undefined') {
    // the variable is defined
    dataLayer.push({
      'event': 'checkout',
      'ecommerce': {
        'checkout': {
          'actionField': { 'step': 3, 'option': 'PayLaterpay' }
        }
      }
    }
    );
    dataLayer.push({
      'event': 'checkoutOption',
      'ecommerce': {
        'checkout_option': {
          'actionField': { 'step': 3, 'option': 'PayLaterpay' }
        }
      }
    });
  }
}

//Handle the response Decline/Accept
window.closeIFrameOnCompleteOrder = function (message) {

  var status = message.status;
  rejectUrl = message.rejectUrl;
  confirmUrl = message.confirmUrl;
  hidePopup = message.hidePopup;

  console.log(status);
  console.log('rejectUrl', rejectUrl);
  console.log(confirmUrl);

  switch (status) {
    case successCheckOutStatus: {
      if (!isSuccess) {
        isSuccess = true;
        console.log('successCheckOutStatus');
        if (typeof dataLayer !== 'undefined') {
          var params = confirmUrl.split('/');
          var reference = params[params.length - 2];
          var ids = reference.split('-');
          var id = ids[1];
          dataLayer.push({
            'event': 'purchase',
            'ecommerce': {
              'purchase': {
                'actionField': {
                  'id': id,                // Transaction ID. Required for purchases and refunds.
                  'affiliation': 'PayLater',
                }
              }
            }
          });
        }
        location.href = confirmUrl;
        document.getElementById('closeiframebtn').onclick = function () {
          location.href = confirmUrl;
        };
        removeOverlay();
      }
      break;
    }
    case failedCheckOutStatus: {
        console.log('failedCheckoutStatus');
      if (hidePopup && popup) {
        popup = false;
          console.log('hiding popup');
        document.getElementById('closeiframebtn').click();
      }
      if (!isFail) {
        isFail = true;
        isDeclined = true;
        console.log('isFail:',isFail)
        document.getElementById('closeiframebtn').onclick = function () {
          if (buttonOnce) {
              console.log('in buttonOnce if');
            buttonOnce = false;
            var rejectUrlSubmitted = rejectUrl.substring(0, rejectUrl.length - 2) + "1/";
            location.href = rejectUrlSubmitted;
          }
        };
      }
      console.log('break of failedStatus');
      break;
    }
    default: {
      removeOverlay();
      break;
    }
  }
};

define([
  "Magento_Customer/js/model/customer",
  "Magento_Checkout/js/model/resource-url-manager",
  "mage/storage",
  "Magento_Checkout/js/view/payment/default",
  "jquery",
  "Magento_Checkout/js/model/payment/additional-validators",
  "Magento_Checkout/js/action/set-payment-information",
  "mage/url",
  "mage/translate",
  "Magento_Checkout/js/checkout-data",
  "Magento_Checkout/js/action/select-payment-method",
  "Magento_Ui/js/model/messageList",
  "Magento_Checkout/js/model/quote",
], function (
  customer,
  resourceUrlManager,
  storage,
  Component,
  $,
  additionalValidators,
  setPaymentInformationAction,
  mageUrl,
  $t,
  checkoutData,
  selectPaymentMethodAction,
  globalMessageList,
  quote,
  fancy
) {
  "use strict";
  return Component.extend({
    defaults: {
      template: "PayLater_PayLaterpay/payment/ppaylater",
    },

    getSpotiipayImgSrc: function () {
      return "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB2aWV3Qm94PSIzMTguMzEgMTYxLjkgODAzLjI0IDE5OC4xMyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtjbGlwLXBhdGg6dXJsKCNjbGlwcGF0aCl9LmNscy0ye2ZpbGw6bm9uZX0uY2xzLTIsLmNscy0zLC5jbHMtNCwuY2xzLTUsLmNscy02LC5jbHMtNywuY2xzLTgsLmNscy05e3N0cm9rZS13aWR0aDowcHh9LmNscy0ze2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQpfS5jbHMtNHtmaWxsOiM0MTM3OTZ9LmNscy0xMHtjbGlwLXBhdGg6dXJsKCNjbGlwcGF0aC0xKX0uY2xzLTExe2NsaXAtcGF0aDp1cmwoI2NsaXBwYXRoLTIpfS5jbHMtNXtmaWxsOiMyN2M1ZDF9LmNscy02e2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQtMil9LmNscy03e2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQtMyl9LmNscy04e2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQtNCl9LmNscy05e2ZpbGw6IzgzNjlmMH08L3N0eWxlPjxjbGlwUGF0aCBpZD0iY2xpcHBhdGgiPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTM5NC41MSwzMTEuN2MtMjMuOTItLjgyLTQzLjE2LTIwLjA3LTQzLjk2LTQ0bC0zLjc4LDI2LjkyYy0zLjk5LDI4LjM5LDE1Ljc5LDUxLjQsNDQuMTcsNTEuNGgxOS4yN2MzLjU1LDAsNi44My0yLjg4LDcuMzMtNi40MmwzLjkxLTI3Ljg0aC0yNS43Yy0uNDIsMC0uODQtLjAyLTEuMjQtLjA1WiIvPjwvY2xpcFBhdGg+PHJhZGlhbEdyYWRpZW50IGlkPSJyYWRpYWwtZ3JhZGllbnQiIGN4PSIzNzEuNjgiIGN5PSIyODQuMjQiIGZ4PSIzNzEuNjgiIGZ5PSIyODQuMjQiIHI9IjUzLjM3IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjYThlNWQxIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjdjNWQxIi8+PC9yYWRpYWxHcmFkaWVudD48Y2xpcFBhdGggaWQ9ImNsaXBwYXRoLTEiPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ2Ni40MSwxNzQuNjloLTUxLjRjLTI4LjM5LDAtNTQuNjMsMjMuMDEtNTguNjIsNTEuNGwtNS44NSw0MS42MWMuOCwyMy45MywyMC4wNCw0My4xOCw0My45Niw0NC04Ljc5LS42NC0xNC43NS04LjA0LTEzLjQ4LTE3LjA4bDkuNjMtNjguNTNjMS4zMy05LjQ2LDEwLjA4LTE3LjEzLDE5LjU0LTE3LjEzaDUxLjRjLjM5LDAsLjc2LjAyLDEuMTQuMDQsMjQuMjEuODYsNDMuNjEsMjAuNTksNDMuOTQsNDQuOTNsMy45MS0yNy44NGMzLjk5LTI4LjM5LTE1Ljc5LTUxLjQtNDQuMTctNTEuNFoiLz48L2NsaXBQYXRoPjxyYWRpYWxHcmFkaWVudCBpZD0icmFkaWFsLWdyYWRpZW50LTIiIGN4PSIzODAuNTMiIGN5PSIzMDYuNjYiIGZ4PSIzODAuNTMiIGZ5PSIzMDYuNjYiIHI9IjUzLjM3IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjNDEzNzk2Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjODM2OWYwIi8+PC9yYWRpYWxHcmFkaWVudD48cmFkaWFsR3JhZGllbnQgaWQ9InJhZGlhbC1ncmFkaWVudC0zIiBjeD0iNDc2Ljc4IiBjeT0iMjM4LjYxIiBmeD0iNDc2Ljc4IiBmeT0iMjM4LjYxIiByPSI0Mi43IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjYjJhMmY2Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjODM2OWYwIi8+PC9yYWRpYWxHcmFkaWVudD48Y2xpcFBhdGggaWQ9ImNsaXBwYXRoLTIiPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ2Mi43NCwyMDljOC44NC41OSwxNC44Niw4LjAxLDEzLjU5LDE3LjA5bC00LjgyLDM0LjI3Yy0xLjMzLDkuNDYtMTAuMDgsMTcuMTMtMTkuNTQsMTcuMTNoLTE5LjI3Yy0zLjU1LDAtNi44MywyLjg4LTcuMzMsNi40MmwtMy45MSwyNy44NGgyNS43YzI4LjM5LDAsNTQuNjMtMjMuMDEsNTguNjItNTEuNGwuOS02LjQzYy0uMzMtMjQuMzQtMTkuNzMtNDQuMDctNDMuOTQtNDQuOTNaIi8+PC9jbGlwUGF0aD48cmFkaWFsR3JhZGllbnQgaWQ9InJhZGlhbC1ncmFkaWVudC00IiBjeD0iNDgzLjk2IiBjeT0iMjIxLjkiIGZ4PSI0ODMuOTYiIGZ5PSIyMjEuOSIgcj0iNDYuMDMiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiMyMTE3NDciLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiM0MTM3OTYiLz48L3JhZGlhbEdyYWRpZW50PjwvZGVmcz48Zz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik02MTYuMjEsMjE3Ljk4Yy01LjUtNi4xNy0xMy43LTkuMjYtMjQuNi05LjI2aC0zOC43N2MtMi4yMiwwLTMuODIuNDMtNC44MSwxLjMtLjk5Ljg3LTEuNjQsMi40MS0xLjk1LDQuNjNsLTEyLjc3LDkwLjg2Yy0uMzEsMi4yMi0uMDksMy43Ni42NSw0LjYzLjc1Ljg3LDIuMjMsMS4zLDQuNDUsMS4zaDExLjcyYzIuMjIsMCwzLjgyLS40Myw0LjgxLTEuMy45OS0uODcsMS42NC0yLjQxLDEuOTUtNC42M2wzLjg2LTI3LjQ5aDIxLjEyYzExLDAsMjAuMDgtMy4wNiwyNy4yNi05LjE5LDcuMTgtNi4xMiwxMS41My0xNC41OSwxMy4wNS0yNS4zOSwxLjUyLTEwLjgtLjQ3LTE5LjI5LTUuOTctMjUuNDZaTTU5Ny43MywyNDMuNDVjLS41OCw0LjE1LTIuMjIsNy4zNi00LjksOS42Mi0yLjY4LDIuMjctNi4xNSwzLjQtMTAuMzksMy40aC0xOC42NmwzLjctMjYuMzNoMTguNjZjNC4yNCwwLDcuMzgsMS4xOCw5LjQxLDMuNTQsMi4wMywyLjM2LDIuNzYsNS42MiwyLjE3LDkuNzdaIi8+PHBhdGggY2xhc3M9ImNscy00IiBkPSJNNjYyLjA0LDIzNC4wNGMtNy43MiwwLTE0LjM0LDEuMy0xOS44NiwzLjkxLTUuNTMsMi42LTkuOTMsNi4zMi0xMy4yMSwxMS4xNC0uODUsMS4yNS0xLjM1LDIuMzYtMS40OCwzLjMzLS4yNiwxLjgzLjg0LDMuMjgsMy4zLDQuMzRsNy41MSwzLjE4YzEuMjcuNTgsMi4yOS44NywzLjA2Ljg3Ljg3LDAsMS42My0uMjQsMi4yNy0uNzIuNjUtLjQ4LDEuNDQtMS4zLDIuMzctMi40NiwzLjItMy41Nyw3LjQ2LTUuMzUsMTIuNzYtNS4zNSwzLjk1LDAsNi42Ny44OSw4LjE2LDIuNjgsMS40OSwxLjc5LDEuOTcsNC41MSwxLjQ2LDguMTdsLS40OSwzLjQ3Yy00LjMtLjI5LTcuNy0uNDMtMTAuMjEtLjQzLTguMiwwLTE0LjgxLjcyLTE5Ljg0LDIuMTctNS4wMywxLjQ1LTguOTQsMy44OC0xMS43Myw3LjMxLTIuOCwzLjQyLTQuNjIsOC4xMy01LjQ2LDE0LjExLS43Niw1LjQtLjQyLDkuODQsMS4wMiwxMy4zMSwxLjQ0LDMuNDcsNC40Nyw2LjEsOS4wOSw3Ljg5LDQuNjIsMS43OCwxMS4xNywyLjY4LDE5LjY2LDIuNjgsMTIuNDQsMCwyMS43NC0xLjMsMjcuODktMy45MSwyLjI0LS44NywzLjgtMS44Niw0LjY4LTIuOTcuODgtMS4xMSwxLjQ5LTIuOTIsMS44NS01LjQzbDUuMTYtMzYuNzVjMS4zNi05LjY0LS4wNy0xNy4xNC00LjI5LTIyLjUtNC4yMi01LjM1LTEyLjExLTguMDMtMjMuNjgtOC4wM1pNNjYzLjg3LDI5NS4xYy0uMDcuNDgtLjQ1LjgyLTEuMTYsMS4wMS0yLjk2LjQ4LTYuODEuNzItMTEuNTMuNzItMy43NiwwLTYuMjMtLjYzLTcuNC0xLjg4LTEuMTctMS4yNS0xLjYtMy4wNC0xLjI3LTUuMzUuMzMtMi4zMiwxLjI3LTQuMSwyLjg1LTUuMzUsMS41Ny0xLjI1LDQuMjktMS44OCw4LjE1LTEuODgsMi42MSwwLDYuNjQuMTQsMTIuMDkuNDNsLTEuNzMsMTIuM1oiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik03NjYuNywyMzYuMjFoLTExLjI5Yy0xLjkzLDAtMy4zNi4zOS00LjI5LDEuMTYtLjkzLjc3LTEuNTMsMi4xNy0xLjgyLDQuMmwtNi43MSw0Ny43M2MtMy42Ny42OC03LjIzLDEuMDEtMTAuNzEsMS4wMS00LjE1LDAtNy4xMS0uODctOC44OS0yLjYtMS43OC0xLjc0LTIuNDEtNC40OS0xLjg4LTguMjVsNS4zMy0zNy45Yy4yOC0yLjAzLjEtMy40Mi0uNTctNC4yLS42Ni0uNzctMi4wMS0xLjE2LTQuMDMtMS4xNmgtMTEuMTRjLTIuMDMsMC0zLjQ4LjM5LTQuMzYsMS4xNi0uODguNzctMS40NiwyLjE3LTEuNzUsNC4ybC01LjQzLDM4LjYyYy0xLjM2LDkuNjUuMTgsMTcuMDUsNC42MiwyMi4yMSw0LjQzLDUuMTYsMTEuOTEsNy43NCwyMi40Miw3Ljc0LDUuNSwwLDEwLjAzLS4zNCwxMy42LTEuMDFsLS44Myw1LjkzYy0uNTQsMy44Ni0xLjk1LDYuOC00LjIxLDguODItMi4yNiwyLjAzLTUuMjMsMy4wNC04Ljg5LDMuMDQtMi44OSwwLTUuMTktLjQ2LTYuOS0xLjM3LTEuNy0uOTItMy4xLTIuMjktNC4xOS00LjEyLTEuMjUtMi4xMi0yLjY0LTMuMTgtNC4xOC0zLjE4LTEuMDYsMC0yLjM3LjM4LTMuOTIsMS4xNmwtOC44NCw0LjE5Yy0yLjU5LDEuMjUtNC4wMSwyLjgtNC4yNyw0LjYzLS4xOCwxLjI1LjEyLDIuNTUuOSwzLjkxLDQuNDIsOS4wNywxNC4xLDEzLjYsMjkuMDUsMTMuNiwxMS4zOCwwLDIwLjEzLTIuODcsMjYuMjQtOC42MSw2LjExLTUuNzQsOS44Ny0xMy42MywxMS4yOC0yMy42NmwxMC4xLTcxLjljLjI4LTIuMDMuMDktMy40Mi0uNTctNC4yLS42Ni0uNzctMS45Ni0xLjE2LTMuODktMS4xNloiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik04NDEuOTMsMjkwLjAzaC0zNy4zM2wxMC41OS03NS4zOGMuMzEtMi4yMi4wOS0zLjc2LS42NS00LjYzLS43NS0uODctMi4yMy0xLjMtNC40NS0xLjNoLTExLjcyYy0yLjIyLDAtMy44Mi40My00LjgxLDEuMy0uOTkuODctMS42NCwyLjQxLTEuOTUsNC42M2wtMTIuNzcsOTAuODZjLS4zMSwyLjIyLS4wOSwzLjc2LjY1LDQuNjMuNzUuODcsMi4yMywxLjMsNC40NSwxLjNoNTQuOThjMi4yMiwwLDMuODItLjQzLDQuODEtMS4zLjk5LS44NywxLjY0LTIuNDEsMS45NS00LjYzbDEuMzYtOS42OWMuMzEtMi4yMi4wOS0zLjc0LS42Ni00LjU2LS43NS0uODItMi4yNC0xLjIzLTQuNDYtMS4yM1oiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik04OTcuMDgsMjM0LjA0Yy03LjcyLDAtMTQuMzQsMS4zLTE5Ljg2LDMuOTEtNS41MywyLjYtOS45Myw2LjMyLTEzLjIxLDExLjE0LS44NSwxLjI1LTEuMzUsMi4zNi0xLjQ4LDMuMzMtLjI2LDEuODMuODQsMy4yOCwzLjMsNC4zNGw3LjUxLDMuMThjMS4yNy41OCwyLjI5Ljg3LDMuMDYuODcuODcsMCwxLjYzLS4yNCwyLjI3LS43Mi42NS0uNDgsMS40NC0xLjMsMi4zNy0yLjQ2LDMuMi0zLjU3LDcuNDYtNS4zNSwxMi43Ni01LjM1LDMuOTUsMCw2LjY3Ljg5LDguMTYsMi42OCwxLjQ5LDEuNzksMS45Nyw0LjUxLDEuNDYsOC4xN2wtLjQ5LDMuNDdjLTQuMy0uMjktNy43LS40My0xMC4yMS0uNDMtOC4yLDAtMTQuODEuNzItMTkuODQsMi4xNy01LjAzLDEuNDUtOC45NCwzLjg4LTExLjczLDcuMzEtMi44LDMuNDItNC42Miw4LjEzLTUuNDYsMTQuMTEtLjc2LDUuNC0uNDIsOS44NCwxLjAyLDEzLjMxLDEuNDQsMy40Nyw0LjQ3LDYuMSw5LjA5LDcuODksNC42MiwxLjc4LDExLjE3LDIuNjgsMTkuNjYsMi42OCwxMi40NCwwLDIxLjc0LTEuMywyNy44OS0zLjkxLDIuMjQtLjg3LDMuOC0xLjg2LDQuNjgtMi45Ny44OC0xLjExLDEuNS0yLjkyLDEuODUtNS40M2w1LjE2LTM2Ljc1YzEuMzYtOS42NC0uMDctMTcuMTQtNC4yOS0yMi41LTQuMjItNS4zNS0xMi4xMS04LjAzLTIzLjY4LTguMDNaTTg5OC45MSwyOTUuMWMtLjA3LjQ4LS40NS44Mi0xLjE2LDEuMDEtMi45Ni40OC02LjgxLjcyLTExLjUzLjcyLTMuNzYsMC02LjIzLS42My03LjQtMS44OC0xLjE3LTEuMjUtMS42LTMuMDQtMS4yNy01LjM1LjMzLTIuMzIsMS4yNy00LjEsMi44NS01LjM1LDEuNTctMS4yNSw0LjI5LTEuODgsOC4xNS0xLjg4LDIuNjEsMCw2LjY0LjE0LDEyLjA5LjQzbC0xLjczLDEyLjNaIi8+PHBhdGggY2xhc3M9ImNscy00IiBkPSJNOTgzLjUsMjM2LjIxaC0xMy40NmwxLjY5LTEyLjAxYy4yOC0yLjAzLjA5LTMuNDItLjU3LTQuMi0uNjYtLjc3LTEuOTYtMS4xNi0zLjg5LTEuMTZoLTExLjI4Yy0xLjkzLDAtMy4zNi4zOS00LjI5LDEuMTYtLjkzLjc3LTEuNTQsMi4xNy0xLjgyLDQuMmwtMS42OSwxMi4wMWgtNy42N2MtMi4wMywwLTMuNDguMzktNC4zNiwxLjE2LS44OC43Ny0xLjQ2LDIuMTctMS43NSw0LjJsLTEuMjIsOC42OGMtLjI3LDEuOTMtLjA4LDMuMy41OCw0LjEyLjY2LjgyLDIsMS4yMyw0LjAyLDEuMjNoNy42N2wtMy4yMywyM2MtMS4xOSw4LjQ5LS45NiwxNS4xLjY5LDE5LjgyLDEuNjUsNC43Myw0Ljg3LDguMDgsOS42NSwxMC4wNiw0Ljc5LDEuOTgsMTEuNTIsMi45NywyMC4yLDIuOTcsMi4wMywwLDMuNDgtLjQxLDQuMzctMS4yMy44OS0uODIsMS40OC0yLjI5LDEuNzgtNC40MWwxLjI4LTkuMTFjLjMtMi4xMi4xMi0zLjU3LS41NS00LjM0LS42Ni0uNzctMi4wMS0xLjE2LTQuMDMtMS4xNi0zLjQ3LDAtNi4wOC0uMzQtNy44Mi0xLjAxLTEuNzQtLjY3LTIuOS0xLjk4LTMuNS0zLjkxLS42LTEuOTMtLjYzLTQuNzctLjEtOC41NGwzLjExLTIyLjE0aDEzLjQ2YzEuOTMsMCwzLjM0LS40MSw0LjIyLTEuMjMuODktLjgyLDEuNDctMi4xOSwxLjc0LTQuMTJsMS4yMi04LjY4Yy4yOC0yLjAzLjEtMy40Mi0uNTctNC4yLS42Ni0uNzctMS45Ni0xLjE2LTMuODktMS4xNloiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik0xMTIwLjg3LDIzNy4zN2MtLjY2LS43Ny0yLjAxLTEuMTYtNC4wMy0xLjE2aC00LjYzYy0xMSwwLTIwLjUyLDEuNS0yOC41NSw0LjQ5LTIuNDQuODctNC4xMiwxLjg4LTUuMDYsMy4wNC0uOTQsMS4xNi0xLjU3LDIuOTQtMS45MSw1LjM1bC04LjAxLDU3Yy0uMjgsMi4wMy0uMDcsMy40Mi42NCw0LjIuNzEuNzcsMi4wMywxLjE2LDMuOTYsMS4xNmgxMS4yOGMxLjkzLDAsMy4zMy0uMzgsNC4yMS0xLjE2Ljg4LS43NywxLjQ2LTIuMTcsMS43NS00LjJsNi43OS00OC4zMmMuMDgtLjU4LjQyLS45MiwxLjAxLTEuMDEsMy4wOC0uNjcsNi41Ni0xLjAxLDEwLjQxLTEuMDFoNS4zNWMyLjAzLDAsMy40OC0uMzgsNC4zNi0xLjE2Ljg4LS43NywxLjQ2LTIuMTIsMS43My00LjA1bDEuMjYtOC45N2MuMjgtMi4wMy4wOS0zLjQyLS41Ny00LjJaIi8+PHBhdGggY2xhc3M9ImNscy00IiBkPSJNMTA1NS4wOSwyMzkuOTVjLTUuNDktNC0xMi44Ny02LTIyLjEzLTYtMTEuMTksMC0yMC4xNCwyLjU2LTI2Ljg2LDcuNjctNi43Miw1LjExLTEwLjc4LDEyLjQ0LTEyLjE4LDIxLjk5bC0yLjQ4LDE2LjA2Yy0uMzgsMy4wOS0uNTIsNS43NC0uNDUsNy45Ni4yNyw3LjgxLDIuOSwxNC4wOCw3Ljg5LDE4LjgxLDQuOTksNC43MywxMi41LDcuMDksMjIuNTMsNy4wOSwxNi4xMSwwLDI3LjQzLTQuMzksMzMuOTgtMTMuMTcsMS4yOS0xLjY0LDEuOTEtMy4xOCwxLjg2LTQuNjMtLjA1LTEuNDUtMS4wMS0yLjc1LTIuODgtMy45MWwtNi41LTMuNzZjLTEuNTgtLjk2LTIuODUtMS40NS0zLjgxLTEuNDUtLjc3LDAtMS41My4yNy0yLjI5LjgtLjc1LjUzLTEuNjQsMS4zMy0yLjY2LDIuMzktMy40NCwzLjg2LTguNDgsNS43OS0xNS4xMyw1Ljc5LTcuNDMsMC0xMS4yNC0yLjg0LTExLjQ0LTguNTQtLjAyLS41OC4wNC0xLjU0LjE5LTIuODlsLjM2LTIuMDNjNS4wMi4xOSw4Ljc0LjI5LDExLjE1LjI5LDExLjQ4LDAsMjAuNjMtMS41OSwyNy40Ny00Ljc3LDYuODMtMy4xOCwxMC43NC04LjY4LDExLjcyLTE2LjQ5LjIzLTEuNjQuMzItMy4xOC4yNy00LjYzLS4yNS03LjA0LTMuMTItMTIuNTYtOC42MS0xNi41NlpNMTA0Mi4wOSwyNTguOTdjLS40NywyLjk5LTIuMzgsNS4wNC01LjcyLDYuMTUtMy4zNCwxLjExLTguMDQsMS42Ni0xNC4xMiwxLjY2LTMuMDksMC01LjQxLS4wOS02Ljk1LS4yOWwuNDUtMy42MmMuNjUtMy41NywyLjI4LTYuMzksNC45MS04LjQ2LDIuNjMtMi4wNyw2LjAxLTMuMTEsMTAuMTYtMy4xMXM3LjAyLjY1LDguODksMS45NWMxLjg4LDEuMywyLjY3LDMuMjEsMi4zNyw1LjcyWiIvPjwvZz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MzIuNjksMjc3LjQ4aDE5LjI3YzkuNDYsMCwxOC4yMS03LjY3LDE5LjU0LTE3LjEzbDQuODItMzQuMjdjMS4yOC05LjA4LTQuNzQtMTYuNS0xMy41OS0xNy4wOS0uNTUtLjAyLTEuMDktLjA0LTEuNjQtLjA0LjU1LDAsMS4xLjAyLDEuNjQuMDQtLjM4LS4wMy0uNzUtLjA0LTEuMTQtLjA0aC01MS40Yy05LjQ2LDAtMTguMjEsNy42Ny0xOS41NCwxNy4xM2wtOS42Myw2OC41M2MtMS4yNyw5LjA0LDQuNjksMTYuNDQsMTMuNDgsMTcuMDguNTMuMDIsMS4wNi4wNCwxLjYuMDQtLjU0LDAtMS4wNy0uMDItMS42LS4wNC40MS4wMy44Mi4wNSwxLjI0LjA1aDI1LjdsMy45MS0yNy44NGMuNS0zLjU1LDMuNzgtNi40Miw3LjMzLTYuNDJaIi8+PGcgY2xhc3M9ImNscy0xIj48cmVjdCBjbGFzcz0iY2xzLTUiIHg9IjM0Ny44MyIgeT0iMjk3LjU3IiB3aWR0aD0iODcuMDciIGhlaWdodD0iNTguNDQiLz48Y2lyY2xlIGNsYXNzPSJjbHMtMyIgY3g9IjM3MS42OCIgY3k9IjI4NC4yNCIgcj0iNTMuMzciLz48L2c+PGcgY2xhc3M9ImNscy0xMCI+PHJlY3QgY2xhc3M9ImNscy05IiB4PSIzNDIuNDciIHk9IjE2MS45IiB3aWR0aD0iMTgzLjM1IiBoZWlnaHQ9IjE1OS42MiIvPjxjaXJjbGUgY2xhc3M9ImNscy02IiBjeD0iMzgwLjUzIiBjeT0iMzA2LjY2IiByPSI1My4zNyIvPjxjaXJjbGUgY2xhc3M9ImNscy03IiBjeD0iNDc2Ljc4IiBjeT0iMjM4LjYxIiByPSI0Mi43Ii8+PC9nPjxnIGNsYXNzPSJjbHMtMTEiPjxyZWN0IGNsYXNzPSJjbHMtNCIgeD0iNDEyLjg0IiB5PSIyMTIuMjkiIHdpZHRoPSIxMTAuMDMiIGhlaWdodD0iMTE4LjA4Ii8+PGNpcmNsZSBjbGFzcz0iY2xzLTgiIGN4PSI0ODMuOTYiIGN5PSIyMjEuOSIgcj0iNDYuMDMiLz48L2c+PC9zdmc+";
    },

    /**
     * Get Grand Total of the current cart
     * @returns {*}
     */
    getGrandTotal: function () {
      var total = quote.getCalculatedTotal();
      var format = window.checkoutConfig.priceFormat.pattern;

      storage
        .get(resourceUrlManager.getUrlForCartTotals(quote), false)
        .done(function (response) {
          var amount = response.base_grand_total;
          var installmentFee = response.base_grand_total / 3;
          var installmentFeeLast =
            amount -
            installmentFee.toFixed(
              window.checkoutConfig.priceFormat.precision
            ) *
              3;

          $(".spotii-grand-total").text(
            "Total : " +
            format.replace(
              /%s/g,
              amount.toFixed(window.checkoutConfig.priceFormat.precision)
            )
          );
          $(".spotii-installment-amount").text(
            format.replace(
              /%s/g,
              installmentFee.toFixed(
                window.checkoutConfig.priceFormat.precision
              )
            )
          );
          $(".spotii-installment-amount.final").text(
            format.replace(
              /%s/g,
              installmentFeeLast.toFixed(
                window.checkoutConfig.priceFormat.precision
              )
            )
          );

          return format.replace(/%s/g, amount);
        })
        .fail(function (response) {
          //do your error handling

          return "Error";
        });
    },
    /**
     * Get Checkout Message based on the currency
     * @returns {*}
     */
    getPaymentText: function () {
      return "Payment Schedule";
    },
    getQtyInvaildText: function () {
      document.getElementById('total-benchmark-info').textContent = "One or more of the items in your cart are out of stock.";
    },
    redirectToSpotiipayController: function (data) {
      if (!isDeclined) {
        var self = this;
        var renderPopup = function (url) {
          openIframeSpotiiCheckout(url);
        };

        var openIframeSpotiiCheckout = function (checkoutUrl) {
          $('.lightbox').attr('href', checkoutUrl).attr("data-src", checkoutUrl);
          loadIFrame();
        };

        var handleError = function(message) {
          console.log("handleError", message);
          if (!isSuccess) {
          removeOverlay();
          globalMessageList.addErrorMessage({
            message: message || $t('Unable to process payment. Please try again or select a different payment method.')
          });
            //window.location = mageUrl.build("checkout/cart");
          }
        };

        if (toggleFlag) {
          onCheckout();
          var url = mageUrl.build("ppaylater/standard/redirect");
          
          $.ajax({
            url: url,
            method: "post",
            showLoader: true,
            data: data,
            success: function (response) {
              try {
              jsonData = $.parseJSON(response);
              if (jsonData.redirectURL) {
                if (isMobileSafari()) {
                  redirectToSpotiiCheckout(jsonData.redirectURL, 2500);
                } else {
                    thirdPartySupported(root)
                      .then(() => {
                    renderPopup(jsonData.redirectURL);
                  })
                    .catch(() => {
                      redirectToSpotiiCheckout(jsonData.redirectURL, 2500);
                    });
                }
                } else {
                  handleError(jsonData.message);
                }
              } catch(e) {
                handleError();
                self.getQtyInvaildText();
              }
            },
            error: function(xhr, status, error) {
              handleError();
            }
          });
          toggleFlag = false;
        } else {
          loadIFrame();
        }
      }
    },
    handleRedirectAction: function () {
      var data = $("#co-shipping-form").serialize();
      if (!customer.isLoggedIn()) {
        var email = quote.guestEmail;
        data += "&email=" + email;
      }

      this.redirectToSpotiipayController(data);
    },

    continueToSpotiipay: function () {
      var url = mageUrl.build("ppaylater/standard/checkinventory");
      var finalResult = [];
      var itemsFromQuote = window.checkoutConfig.quoteItemData;
      for (var i = 0; i < itemsFromQuote.length; i++) {
        var tempQty = itemsFromQuote[i].qty;
        var tempSku = itemsFromQuote[i].sku;
        finalResult.push({ qty: tempQty, sku: tempSku });
      }
      var jsonString = JSON.stringify(finalResult);
      var x = this;
      var y = additionalValidators;
      $.ajax({
        url: url,
        method: "post",
        showLoader: true,
        //async: true,
        data: { "items": jsonString },
        success: function (response) {
          var jsonItems = $.parseJSON(response);
          if (
            x.validate() &&
            y.validate()
          ) {
            showOverlay();
            x.handleRedirectAction();
          }
          else {
            console.log("redirect failed");
            x.getQtyInvaildText();
          }
        }
      });
    },

    isTotalValid: function () {
      var total = this.getGrandTotal() ? this.getGrandTotal() : window.checkoutConfig.quoteData.grand_total;
      var curr = window.checkoutConfig.quoteData.quote_currency_code;
      var min=200;
      switch(curr){
        case "USD":
          total= total*3.6730;
          break;
        case "BHD":
        case "OMR":
        case "KWD":
          min= 20;
          break;
      }
      console.log(total+curr);
      if (total >= min) return true;
      else return false;
    },

    placeOrder: function (data, event) {
      this.continueToSpotiipay();
    },
  });
});
