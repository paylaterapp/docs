/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'ppaylater',
                component: 'PayLater_PayLaterpay/js/view/payment/method-renderer/ppaylater'
            }
        );

        /** Add view logic here if needed */
        return Component.extend({});
    }
);
