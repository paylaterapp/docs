<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Controller\Standard;

use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

/**
 * Class Cancel
 * @package PayLater\PayLaterpay\Controller\Standard
 */
class Cancel extends SpotiiPay
{
    /**
     * Cancel the transaction
     */
    public function execute()
    {
        try {
            $error = $this->getRequest()->getParam('error');
            if ($error) {
                $this->messageManager->addError(__($error));
                $this->spotiiHelper->logSpotiiActions("PayLater Error: " . $error);
            } else {
                $this->messageManager->addError(__("<b>Transaction Failed!</b>"));
                $this->spotiiHelper->logSpotiiActions("Returned from PayLater without completing payment, order not placed");
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->spotiiHelper->logSpotiiActions("Redirect Exception: " . $e->getMessage());
            $this->messageManager->addError(
                $e->getMessage()
            );
        }
        $this->spotiiHelper->logSpotiiActions("Abandoned Cart");
        $this->_checkoutSession->restoreQuote();
        $this->getResponse()->setRedirect(
            $this->_url->getUrl('checkout/cart')
        );
    }
}
