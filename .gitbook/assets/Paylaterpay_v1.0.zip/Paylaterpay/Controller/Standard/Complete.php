<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Controller\Standard;

use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

/**
 * Class Complete
 * @package PayLater\PayLaterpay\Controller\Standard
 */
class Complete extends SpotiiPay
{
    /**
     * Complete the transaction
     */
    public function execute()
    {
        try {
            xdebug_break();
            // Create order before redirect to success
            $quote = $this->_checkoutSession->getQuote();
            $quoteId = $quote->getId();
            $quote->collectTotals()->save();
            $order = $this->_quoteManagement->submit($quote);

            $payment = $quote->getPayment();
            $payment->setMethod('ppaylater');
            $payment->save();
            $quote->reserveOrderId();
            $quote->setPayment($payment);
            $quote->save();

            $this->_checkoutSession->replaceQuote($quote);
            $reference = $payment->getAdditionalInformation('ppaylater_order_id');

            $this->_spotiipayModel->createTransaction(
                $order,
                $reference,
                \Magento\Sales\Model\Order\Payment\Transaction::TYPE_ORDER
            );

            $order->save();

            // Set all necessary session data
            $this->_checkoutSession->setLastQuoteId($quoteId);
            $this->_checkoutSession->setLastSuccessQuoteId($quoteId);
            $this->_checkoutSession->setLastOrderId($order->getEntityId());
            $this->_checkoutSession->setLastRealOrderId($order->getIncrementId());

            $this->messageManager->addSuccess("<b>Success! Payment completed!</b><br>Thank you for your payment, your order with PayLater has been placed.");

            // Single redirect to success page
            return $this->_redirect('checkout/onepage/success');

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->spotiiHelper->logSpotiiActions("Transaction Exception: " . $e->getMessage());
            $this->messageManager->addError($e->getMessage());
            return $this->_redirect('checkout/cart');
        } catch (\Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Transaction Exception: " . $e->getMessage());
            $this->messageManager->addError("An error occurred while processing your payment. Please try again.");
            return $this->_redirect('checkout/cart');
        }
    }
}
