<?php

namespace PayLater\PayLaterpay\Controller\Standard;

use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

/**
 * PayLater Helper
 */
class CheckInventory extends SpotiiPay
{
    /**
     * Dump PayLater log actions
     *
     * @param string $msg
     * @return void
     */
    public function execute()
    {
        $post = $this->getRequest()->getPostValue();
        $itemsString = $post['items'];
        $this->spotiiHelper->logSpotiiActions($itemsString);

        $items = $this->_jsonHelper->jsonDecode($itemsString);
        $this->spotiiHelper->logSpotiiActions($items);

        $flag = true;
        foreach ($items as $item) {
            $sku = $item['sku'];
            $this->spotiiHelper->logSpotiiActions("checking ... " . $sku );
    
            $qtyOrdered = $item['qty'];
    
            $stockItem = $this->stockRegistry->getStockItemBySku($sku);
            $qtyInStock= $stockItem->getQty();
            if($qtyInStock < $qtyOrdered){
               $flag = false ;            
            }
            }
            $json = $this->_jsonHelper->jsonEncode(["isInStock" => $flag]);
            $jsonResult = $this->_resultJsonFactory->create();
            $jsonResult->setData($json);
            return $jsonResult;
    }
}