<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Model\Cron;

use PayLater\PayLaterpay\Model\Gateway;

/**
 * Class MerchantData
 * @package PayLater\PayLaterpay\Model\Cron
 */
class MerchantData
{
    /**
     * @var Gateway\Transaction
     */
    protected $transaction;
    /**
     * @var Gateway\Heartbeat
     */
    protected $heartbeat;

    /**
     * MerchantData constructor.
     * @param Gateway\Transaction $transaction
     * @param Gateway\Heartbeat $heartbeat
     */
    public function __construct(
        Gateway\Transaction $transaction,
        Gateway\Heartbeat $heartbeat
    ) {
        $this->transaction = $transaction;
        $this->heartbeat = $heartbeat;
    }

    /**
     * Jobs for PayLater handshake
     */
    public function execute()
    {
        $this->transaction->sendOrdersToSpotii();
        $this->heartbeat->send();
    }
}
