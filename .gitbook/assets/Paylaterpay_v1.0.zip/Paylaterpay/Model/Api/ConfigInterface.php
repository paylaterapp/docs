<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Model\Api;


/**
 * Interface ConfigInterface
 * @package PayLater\PayLaterpay\Model\Api
 */
interface ConfigInterface
{
    /**
     * Get complete url
     * @return string
     */
    public function getCompleteUrl();

    /**
     * Get cancel url
     * @param string|null $error Optional error message to append to URL
     * @return string
     */
    public function getCancelUrl($error = null);
}
