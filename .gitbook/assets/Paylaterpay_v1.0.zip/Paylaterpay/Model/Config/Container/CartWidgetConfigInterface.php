<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Model\Config\Container;

/**
 * Interface CartWidgetConfigInterface
 * @package PayLater\PayLaterpay\Model\Config\Container
 */
interface CartWidgetConfigInterface extends IdentityInterface
{

    /**
     * Get Target Xpath
     * @return mixed
     */
    public function getTargetXPath();

    /**
     * Get Render to Path
     * @return mixed
     */
    public function getRenderToPath();

    /**
     * Get forced show
     * @return mixed
     */
    public function getForcedShow();

    /**
     * Get alignment
     * @return mixed
     */
    public function getAlignment();

    /**
     * Get theme
     * @return mixed
     */
    public function getTheme();

    /**
     * Get width type
     * @return mixed
     */
    public function getWidthType();

    /**
     * Get image url
     * @return mixed
     */
    public function getImageUrl();

    /**
     * Get hide class
     * @return mixed
     */
    public function getHideClass();
}
