<?php
namespace PayLater\PayLaterpay\Block\Adminhtml\System\Config\Form;

class SpotiiRegisterConfig extends \Magento\Config\Block\System\Config\Form\Field
{

    /**
     * Render element value
     *
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
     * @return string
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $html = $this->_layout
            ->createBlock(\PayLater\PayLaterpay\Block\Adminhtml\System\Config\SpotiiRegisterAdmin::class)
            ->setTemplate('PayLater_PayLaterpay::system/config/spotii_register_admin.phtml')
            ->setCacheable(false)
            ->toHtml();

        return $html;
    }
}
