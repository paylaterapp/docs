/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

publicWidget.registry.PayLaterToggle = publicWidget.Widget.extend({
    selector: '.paylater-collapsible.paylater-pdp',
    events: {
        'click .paylater-toggle': '_onToggle',
    },
    _onToggle: function () {
        this.el.classList.toggle('expanded');
    },
});
