from . import models
from . import controllers
from odoo.fields import Command


def _post_init_hook(env):
    """Link redirect form and payment method to the PayLater provider."""
    redirect_form = env.ref('payment_paylater.redirect_form', raise_if_not_found=False)
    payment_method = env.ref('payment_paylater.payment_method_paylater', raise_if_not_found=False)

    provider = env['payment.provider'].search([('code', '=', 'paylater')], limit=1)

    if not provider:
        return

    vals = {}
    if redirect_form and not provider.redirect_form_view_id:
        vals['redirect_form_view_id'] = redirect_form.id
    if payment_method and payment_method not in provider.payment_method_ids:
        vals['payment_method_ids'] = [Command.link(payment_method.id)]
    if vals:
        provider.write(vals)

    # Also ensure the payment method is active
    if payment_method and not payment_method.active:
        payment_method.active = True


def _uninstall_hook(env):
    env['payment.provider'].search([('code', '=', 'paylater')]).write({
        'state': 'disabled',
        'is_published': False,
    })
