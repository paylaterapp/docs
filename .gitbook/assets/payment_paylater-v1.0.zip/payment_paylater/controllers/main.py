import logging
import pprint

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class PayLaterController(http.Controller):

    @http.route(
        '/payment/paylater/return',
        type='http', auth='public', methods=['GET'], csrf=False, save_session=False,
    )
    def paylater_return(self, **data):
        """Handle the customer returning from PayLater after payment."""
        _logger.info("PayLater: Customer return — data:\n%s", pprint.pformat(data))

        tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
            'paylater', data
        )
        _logger.info(
            "PayLater: Processing return — tx_id=%s ref=%s",
            tx_sudo.id, tx_sudo.reference,
        )
        tx_sudo._handle_notification_data('paylater', data)

        return request.redirect('/payment/status')

    @http.route(
        '/payment/paylater/callback',
        type='json', auth='public', methods=['POST'], csrf=False, save_session=False,
    )
    def paylater_callback(self, **data):
        """Handle server-to-server webhook callback from PayLater."""
        notification_data = request.get_json_data()
        _logger.info("PayLater: Webhook callback — data:\n%s", pprint.pformat(notification_data))

        tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
            'paylater', notification_data
        )
        _logger.info(
            "PayLater: Processing webhook — tx_id=%s ref=%s",
            tx_sudo.id, tx_sudo.reference,
        )
        tx_sudo._handle_notification_data('paylater', notification_data)

        return {'status': 'ok'}
