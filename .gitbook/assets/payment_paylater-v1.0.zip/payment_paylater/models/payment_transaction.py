import logging
import time
import requests
from urllib.parse import urlsplit, parse_qs, urlunsplit
from werkzeug.urls import url_encode

from odoo import _, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_rendering_values(self, processing_values):
        """Call PayLater web-checkout API to create a payment and get a redirect URL."""
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'paylater':
            return res

        provider = self.provider_id
        base_url = provider.get_base_url()
        api_base = provider._paylater_get_api_url()

        return_params = url_encode({'ref': self.reference})
        return_url = f'{base_url}/payment/paylater/return?{return_params}'

        # Unique order ID: Odoo reference + timestamp to avoid "Order ID must be unique"
        unique_order_id = f'{self.reference}-{int(time.time())}'

        payload = {
            'merchantId': provider.paylater_merchant_id or '1',
            'outletId': provider.paylater_outlet_id or 1,
            'currency': 'QAR',
            'amount': processing_values['amount'],
            'orderId': unique_order_id,
            'successRedirectUrl': return_url,
            'failRedirectUrl': return_url,
        }
        headers = {
            'x-api-key': provider.paylater_api_key or '',
            'Content-Type': 'application/json',
        }
        api_url = f'{api_base}/api/paylater/merchant-portal/web-checkout/'

        _logger.info(
            "PayLater [%s]: Creating payment — order=%s orderId=%s amount=%s",
            provider.paylater_environment, self.reference, unique_order_id,
            processing_values['amount'],
        )

        try:
            response = requests.post(api_url, json=payload, headers=headers, timeout=30)
            _logger.info(
                "PayLater [%s]: Response — order=%s http_status=%s body=%s",
                provider.paylater_environment, self.reference,
                response.status_code, response.text,
            )
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.Timeout:
            _logger.error("PayLater: Timeout for order=%s", self.reference)
            raise UserError(_("PayLater payment gateway timed out. Please try again."))
        except requests.exceptions.ConnectionError:
            _logger.error("PayLater: Connection failed for order=%s", self.reference)
            raise UserError(_("Could not connect to PayLater. Please try again."))
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Request error for order=%s: %s", self.reference, e)
            raise UserError(_("Could not connect to PayLater. Please try again."))

        if 'error' in data:
            _logger.error("PayLater: API error for order=%s: %s", self.reference, data['error'])
            raise UserError(_("PayLater error: %s", data['error']))

        payment_url = data.get('paymentLinkUrl')
        if not payment_url:
            _logger.error("PayLater: No paymentLinkUrl for order=%s — response: %s", self.reference, data)
            raise UserError(_("PayLater did not return a valid payment link."))

        # Store the unique order ID we sent to PayLater for status checks
        self.provider_reference = unique_order_id

        _logger.info("PayLater: Redirecting order=%s (paylater_id=%s) to %s", self.reference, unique_order_id, payment_url)

        # Split URL into base and query params so the GET form doesn't strip them
        parsed = urlsplit(payment_url)
        base_url_clean = urlunsplit((parsed.scheme, parsed.netloc, parsed.path, '', ''))
        url_params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        return {
            'api_url': base_url_clean,
            'url_params': url_params,
        }

    def _get_tx_from_notification_data(self, provider_code, notification_data):
        """Find the transaction based on the notification data."""
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'paylater' or len(tx) == 1:
            return tx

        reference = notification_data.get('ref')
        if not reference:
            _logger.error("PayLater: Missing reference in data: %s", notification_data)
            raise ValidationError("PayLater: " + _("Received data with missing reference."))

        tx = self.search([
            ('reference', '=', reference),
            ('provider_code', '=', 'paylater'),
        ])
        if not tx:
            _logger.error("PayLater: No transaction for reference=%s", reference)
            raise ValidationError("PayLater: " + _("No transaction found matching reference %s.", reference))

        _logger.info("PayLater: Found tx id=%s for ref=%s", tx.id, reference)
        return tx

    def _process_notification_data(self, notification_data):
        """Call the PayLater status API and update the transaction state."""
        super()._process_notification_data(notification_data)
        if self.provider_code != 'paylater':
            return

        provider = self.provider_id
        api_base = provider._paylater_get_api_url()

        # Use the unique order ID we stored in provider_reference
        paylater_order_id = self.provider_reference

        status_url = f'{api_base}/api/paylater/merchant-portal/web-checkout/status'
        headers = {
            'x-api-key': provider.paylater_api_key or '',
        }
        params = {
            'orderId': paylater_order_id,
            'merchantId': provider.paylater_merchant_id or '1',
        }

        _logger.info("PayLater: Checking status — ref=%s orderId=%s", self.reference, paylater_order_id)

        try:
            response = requests.get(status_url, params=params, headers=headers, timeout=30)
            _logger.info(
                "PayLater: Status response — ref=%s http_status=%s body=%s",
                self.reference, response.status_code, response.text,
            )
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Status check failed for ref=%s: %s", self.reference, e)
            raise ValidationError(_("Could not verify payment status with PayLater."))

        if 'error' in data:
            _logger.error("PayLater: Status error for ref=%s: %s", self.reference, data['error'])
            raise ValidationError(_("PayLater status error: %s", data['error']))

        paylater_id = data.get('payLaterOrderId')
        status = data.get('status')
        message = data.get('message', '')

        _logger.info("PayLater: ref=%s status=%s message=%s paylater_id=%s", self.reference, status, message, paylater_id)

        # Status codes: 1=pending, 2=success, 3=failed
        if status == 2:
            self._set_done()
            _logger.info("PayLater: Order %s — SUCCESS", self.reference)
        elif status == 1:
            self._set_pending()
            _logger.info("PayLater: Order %s — PENDING", self.reference)
        elif status == 3:
            self._set_canceled(state_message=_("Payment failed on PayLater."))
            _logger.warning("PayLater: Order %s — FAILED", self.reference)
        else:
            _logger.error("PayLater: Order %s — UNKNOWN status=%s", self.reference, status)
            self._set_error(state_message=_("Unknown payment status from PayLater: %s", message))
