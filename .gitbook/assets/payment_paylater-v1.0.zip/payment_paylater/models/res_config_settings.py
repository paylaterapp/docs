from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    paylater_show_on_plp = fields.Boolean(
        string="Show on Product List Page",
        config_parameter='payment_paylater.show_on_plp',
        default=False,
    )
    paylater_show_on_pdp = fields.Boolean(
        string="Show on Product Detail Page",
        config_parameter='payment_paylater.show_on_pdp',
        default=False,
    )
    paylater_min_price = fields.Float(
        string="Minimum Price",
        config_parameter='payment_paylater.min_price',
        default=300.0,
        help="Widget is hidden for products priced below this amount.",
    )
    paylater_heading_text = fields.Char(
        string="Heading Text",
        config_parameter='payment_paylater.heading_text',
        default='Split in {count} payments',
        help="Heading displayed in the widget. Use {count} for installment count.",
    )
    paylater_sub_heading_text = fields.Char(
        string="Sub-Heading Text",
        config_parameter='payment_paylater.sub_heading_text',
        default='interest free',
        help="Text shown after the amount (e.g. 'interest free').",
    )
    paylater_terms_text = fields.Char(
        string="Terms Text",
        config_parameter='payment_paylater.terms_text',
        default='No interest, no hidden fees. Pay in {count} easy installments with PayLater.',
        help="Footer text in the expanded PDP widget. Use {count} placeholder.",
    )
