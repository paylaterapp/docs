# Changelog

## 2.1.0 — 2026-04-27

### Environment
- **UAT endpoint**: `payment_mode = uat` now points to `https://connect.uat.paylaterapp.com/api/paylater/merchant-portal/` (was `connect-sandbox.paylaterapp.com`). Existing stores with the old saved value need to re-pick "UAT" in admin or run:
  ```sql
  UPDATE core_config_data
  SET value = 'uat'
  WHERE path = 'payment/ppaylater/payment_mode' AND value = 'sandbox';
  ```

### Order flow refactor (redirect-payment pattern)
- Order is now created in `pending_payment` state **before** the shopper is sent to the gateway, then settled (or cancelled) on return.
- `Model\SpotiiPay`: `$_isInitializeNeeded = true`; new `initialize()` pins state to pending_payment so submit() doesn't auto-authorize.
- New idempotent helpers `processSuccessfulPayment(Order, $reference, $gatewayTxnId)` and `processFailedPayment(Order, $reason)` — safe to call from the Complete controller, the Cancel controller, and the reconcile cron.

### Reconciliation cron (safety net)
- New `Cron\ReconcilePendingOrders` runs every 10 minutes.
- For each `pending_payment` ppaylater order older than 3 minutes, calls `web-checkout/status?orderId=<incrementId>` and acts on the response:
  - `status = 2` (success) → settle
  - `status = 3` (failed) → cancel
  - `status = 1` (pending) and order older than 24 h → cancel as abandoned
- Removed the old broken cron jobs that referenced missing `MerchantData` and `InventoryWorker` classes.

### Transaction id
- Magento's `transaction_id` (and invoice transaction id, last_trans_id) is now set to PayLater's own `payLaterOrderId` (e.g. `PL1744792493935483`) instead of the local Magento increment id. The increment id is preserved separately as `ppaylater_order_id` on payment additional info for reconciliation lookups.
- Order status history comment now reads: *"PayLater payment confirmed. Transaction: PL... (merchant ref: 000072152)"*.

### Bug fixes
- **Success message**: `Complete.php` was using PHP backticks (`shell_exec`) for the success message — replaced with `__('...')`. Success message now actually displays.
- **Amount precision**: gateway payload was casting grand total to `int` before rounding, dropping cents (QAR 19.99 → 19). Now `(float)`.
- **Status comparison**: strict-compare `!== 2` would fail if the gateway returned `"2"` as a string. Now casts to `int` first.
- **Amount tampering check**: `isOrderAmountMatched()` was a no-op `return true`. Now does a real currency match plus 0.01-tolerance amount comparison.
- **Inventory check**: `CheckInventory.php` had no input validation and double-encoded its JSON response (Magento's `Json::setData()` re-encodes its argument). Now validates input and returns clean JSON.
- **Email validation**: guest checkout in `Redirect.php` was setting customer email without `filter_var(..., FILTER_VALIDATE_EMAIL)`. Now validates.
- **Gateway error envelope**: `getOrderInfo()` now detects `{"error": "Order ID is required"}` responses and throws a clean `LocalizedException` instead of treating them as "still pending".
- **Observer string match**: `SalesOrderPlaceBefore` was comparing against `"spotiipay"` instead of `"ppaylater"`, so the observer never fired and order-confirmation emails weren't suppressed at order creation. Fixed; emails are now sent only after payment success.

### Security / privacy
- **Removed all 3rd-party JS loads** from the checkout page:
  - `widget.spotii.me/v1/javascript/iframe-lightbox.{js,css}` (was loaded by the payment renderer)
  - `mindmup.github.io/3rdpartycookiecheck/start.html` (was used as a 3rd-party cookie probe)
  - `widget.spotii.me/v1/javascript/spotii-catalog-widget.js` (was loaded by `catalog-widget.js`)
- The checkout JS is now ~50 lines instead of ~480, and uses a simple top-level `window.location.assign()` redirect — no iframe, no popup, no globals on `window`.
- **PII in logs**: removed `logSpotiiActions(json_encode($quote))` which was writing full quote objects (customer email, addresses) to `/var/log/ppaylater.log`. Relevant under PDPL.
- **Hardcoded inconsistent threshold**: removed the JS-side `isTotalValid()` (200 USD / 20 BHD/OMR/KWD with hardcoded FX `total * 3.6730`). The server-side QAR 300 floor is now the single source of truth.

### Cleanup
- Removed `.DS_Store` files (25 of them).
- Removed obsolete `.git` directory from the production zip.
- Removed dead progress-bar HTML and inline base-64 SVG payload from the checkout template.

### Compatibility
- No DB schema changes. `setup_version` unchanged at `2.0.0`.
- Constructor signature changed on `Model\SpotiiPay` (drops several unused dependencies, adds `InvoiceService`, `DbTransaction`, `OrderSender`, `InvoiceSender`). **`bin/magento setup:di:compile` is required** after deploy.

### Deploy
```
bin/magento module:enable PayLater_PayLaterpay
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento setup:static-content:deploy -f
bin/magento cache:flush
```
