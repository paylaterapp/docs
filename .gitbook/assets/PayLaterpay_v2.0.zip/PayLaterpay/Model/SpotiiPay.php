<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model;

use Exception;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\DataObject;
use Magento\Framework\DB\Transaction as DbTransaction;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Payment\Helper\Data;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\Method\Logger;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\Order\Invoice;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Sales\Model\Service\InvoiceService;
use PayLater\PayLaterpay\Helper\Data as PayLaterHelper;
use PayLater\PayLaterpay\Model\Api\PayloadBuilder;
use PayLater\PayLaterpay\Model\Api\ProcessorInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Zend_Log_Exception;

/**
 * PayLater payment method.
 *
 * Uses the redirect-payment pattern: order is created in `pending_payment` state
 * via initialize() before the shopper is sent to the gateway, then settled by
 * Complete controller (or cron reconciliation) after the gateway returns.
 */
class SpotiiPay extends AbstractMethod
{
    const PAYMENT_CODE = 'ppaylater';
    const ADDITIONAL_INFORMATION_KEY_ORDERID = 'ppaylater_order_id';
    const ADDITIONAL_INFORMATION_KEY_TXN_ID = 'paylater_transaction_id';

    /** Gateway status codes. */
    const GATEWAY_STATUS_PENDING = 1;
    const GATEWAY_STATUS_SUCCESS = 2;
    const GATEWAY_STATUS_FAILED = 3;

    /**
     * @var string
     */
    protected $_code = self::PAYMENT_CODE;

    /**
     * @var bool
     */
    protected $_isGateway = true;

    /**
     * Initialize-needed flag tells Magento to skip the standard authorize/capture
     * call at order placement and only invoke initialize() on the payment method.
     * The order is created in `pending_payment` state and settled later by the
     * Complete controller or the reconcile cron.
     *
     * @var bool
     */
    protected $_isInitializeNeeded = true;

    /**
     * @var bool
     */
    protected $_canOrder = true;

    /**
     * @var bool
     */
    protected $_canAuthorize = true;

    /**
     * @var bool
     */
    protected $_canCapture = true;

    /**
     * @var bool
     */
    protected $_canRefund = false;

    /**
     * @var bool
     */
    protected $_canRefundInvoicePartial = false;

    /**
     * @var bool
     */
    protected $_canUseInternal = false;

    /**
     * @var bool
     */
    protected $_canFetchTransactionInfo = true;

    /**
     * @var PayLaterHelper
     */
    protected $spotiiHelper;

    /**
     * @var PayloadBuilder
     */
    private $payloadBuilder;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * @var ProcessorInterface
     */
    private $apiProcessor;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var InvoiceService
     */
    private $invoiceService;

    /**
     * @var DbTransaction
     */
    private $dbTransaction;

    /**
     * @var OrderSender
     */
    private $orderSender;

    /**
     * @var InvoiceSender
     */
    private $invoiceSender;

    public function __construct(
        Context                             $context,
        SpotiiApiConfigInterface            $spotiiApiConfig,
        PayLaterHelper                      $spotiiHelper,
        PayloadBuilder                      $payloadBuilder,
        ProcessorInterface                  $apiProcessor,
        InvoiceService                      $invoiceService,
        DbTransaction                       $dbTransaction,
        OrderSender                         $orderSender,
        InvoiceSender                       $invoiceSender,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        Registry                            $registry,
        ExtensionAttributesFactory          $extensionFactory,
        AttributeValueFactory               $customAttributeFactory,
        Data                                $paymentData,
        ScopeConfigInterface                $scopeConfig,
        Logger                              $mageLogger
    ) {
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->spotiiHelper = $spotiiHelper;
        $this->payloadBuilder = $payloadBuilder;
        $this->apiProcessor = $apiProcessor;
        $this->invoiceService = $invoiceService;
        $this->dbTransaction = $dbTransaction;
        $this->orderSender = $orderSender;
        $this->invoiceSender = $invoiceSender;
        $this->jsonHelper = $jsonHelper;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $mageLogger
        );
    }

    /**
     * @param CartInterface|null $quote
     * @return bool
     */
    public function isAvailable(CartInterface $quote = null)
    {
        if (!$this->spotiiApiConfig->isEnabled()) {
            return false;
        }
        if (!$quote) {
            return false;
        }
        if (!$this->isTotalInAllowedRange((float) $quote->getGrandTotal())) {
            return false;
        }
        return parent::isAvailable($quote);
    }

    private function isTotalInAllowedRange(float $total): bool
    {
        // 300 is the hard floor for PayLater eligibility (currency = store currency).
        // The price_range admin field can raise the threshold further but not below.
        if ($total < 300) {
            return false;
        }
        $range = (float) $this->_scopeConfig->getValue(
            'payment/ppaylater/price_range',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $total >= $range;
    }

    /**
     * @param int|null $storeId
     * @return bool
     */
    public function isActive($storeId = null)
    {
        return $this->spotiiApiConfig->isEnabled();
    }

    /**
     * Called by the order place flow because $_isInitializeNeeded is true.
     * Marks the order as pending_payment so it is not fulfilled until the
     * gateway confirms payment.
     *
     * @param string $paymentAction
     * @param object $stateObject
     * @return $this
     */
    public function initialize($paymentAction, $stateObject)
    {
        $stateObject->setState(Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus(Order::STATE_PENDING_PAYMENT);
        $stateObject->setIsNotified(false);
        return $this;
    }

    /**
     * Generate the gateway checkout URL for an order. Stores the gateway
     * reference (= order increment id) on the order's payment additional info.
     *
     * @param OrderInterface $order
     * @return string
     * @throws Zend_Log_Exception
     */
    public function getCheckoutUrl(OrderInterface $order): string
    {
        $reference = $order->getIncrementId();
        $payment = $order->getPayment();
        $payment->setAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID, $reference);

        $this->spotiiHelper->logSpotiiActions("Building gateway checkout for order $reference");

        $url = $this->spotiiApiConfig->getSpotiiBaseUrl() . 'web-checkout/';
        $body = $this->payloadBuilder->buildCheckoutPayload($order, $reference);
        $apiKey = $this->spotiiApiConfig->getApiKey();

        $response = $this->apiProcessor->call($url, $apiKey, $body, 'POST');
        $decoded = $this->jsonHelper->jsonDecode($response, true);

        $paymentLinkUrl = is_array($decoded) && !empty($decoded['paymentLinkUrl'])
            ? $decoded['paymentLinkUrl']
            : null;

        if (!$paymentLinkUrl) {
            $this->spotiiHelper->logSpotiiActions(
                'No payment link URL in response: ' . substr((string) $response, 0, 500)
            );
            throw new LocalizedException(__('PayLater did not return a payment link.'));
        }

        return $paymentLinkUrl;
    }

    /**
     * Query gateway for the status of a reference.
     *
     * @param string $reference
     * @return array
     * @throws LocalizedException
     */
    public function getOrderInfo(string $reference): array
    {
        $url = $this->spotiiApiConfig->getSpotiiBaseUrl()
            . 'web-checkout/status?orderId=' . urlencode($reference)
            . '&merchantId=' . urlencode((string) $this->spotiiApiConfig->getMerchantId());
        $apiKey = $this->spotiiApiConfig->getApiKey();

        $raw = $this->apiProcessor->call($url, $apiKey, null, 'GET');
        $result = $this->jsonHelper->jsonDecode($raw, true);
        if (!is_array($result)) {
            throw new LocalizedException(__('Unexpected gateway response.'));
        }
        // Gateway error envelope: {"error": "Order ID is required"} on bad input.
        if (isset($result['error'])) {
            throw new LocalizedException(__('PayLater: %1', (string) $result['error']));
        }
        if (isset($result['status']) && (int) $result['status'] === ProcessorInterface::BAD_REQUEST) {
            throw new LocalizedException(__('Invalid checkout. Please retry again.'));
        }
        return $result;
    }

    /**
     * Settle a successful payment: create invoice, mark order processing,
     * record transaction, and send confirmation emails. Idempotent — safe to
     * call from both the Complete controller and the reconcile cron.
     *
     * The Magento `transaction_id` and invoice `transaction_id` fields are set
     * to the gateway's `payLaterOrderId` (e.g. `PL1744792493935483`) — that's
     * the authoritative reference for refund / reconciliation against PayLater.
     * The Magento increment id is preserved separately on payment additional
     * info as `ppaylater_order_id` for matching in the cron and logs.
     *
     * @param OrderInterface $order
     * @param string $reference Magento increment id (= merchantReference at gateway)
     * @param string|null $gatewayTransactionId payLaterOrderId from gateway
     * @return void
     * @throws LocalizedException
     */
    public function processSuccessfulPayment(
        OrderInterface $order,
        string $reference,
        ?string $gatewayTransactionId = null
    ): void {
        if ($order->getState() === Order::STATE_PROCESSING
            || $order->getState() === Order::STATE_COMPLETE) {
            $this->spotiiHelper->logSpotiiActions(
                "Order {$order->getIncrementId()} already settled (state={$order->getState()})"
            );
            return;
        }

        // Prefer the gateway's own transaction id; fall back to merchant reference
        // so refund flows still have something to point at if the response was malformed.
        $transactionId = $gatewayTransactionId ?: $reference;

        $payment = $order->getPayment();
        $payment->setTransactionId($transactionId);
        $payment->setLastTransId($transactionId);
        $payment->setIsTransactionClosed(true);
        $payment->setAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID, $reference);
        if ($gatewayTransactionId) {
            $payment->setAdditionalInformation(
                self::ADDITIONAL_INFORMATION_KEY_TXN_ID,
                $gatewayTransactionId
            );
        }

        // Create the invoice (online capture not needed — gateway already captured).
        if ($order->canInvoice()) {
            $invoice = $this->invoiceService->prepareInvoice($order);
            $invoice->setRequestedCaptureCase(Invoice::CAPTURE_OFFLINE);
            $invoice->setTransactionId($transactionId);
            $invoice->register();

            $this->dbTransaction
                ->addObject($invoice)
                ->addObject($invoice->getOrder())
                ->save();

            try {
                $this->invoiceSender->send($invoice);
            } catch (Exception $e) {
                $this->spotiiHelper->logSpotiiActions(
                    "Invoice email failed for {$order->getIncrementId()}: " . $e->getMessage()
                );
            }
        }

        $order->setState(Order::STATE_PROCESSING)
              ->setStatus(Order::STATE_PROCESSING)
              ->addCommentToStatusHistory(
                  __(
                      'PayLater payment confirmed. Transaction: %1 (merchant ref: %2)',
                      $transactionId,
                      $reference
                  )
              );
        $order->save();

        try {
            $this->orderSender->send($order, true);
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions(
                "Order email failed for {$order->getIncrementId()}: " . $e->getMessage()
            );
        }

        $this->spotiiHelper->logSpotiiActions("Settled order {$order->getIncrementId()} as paid");
    }

    /**
     * Cancel a pending order. Idempotent.
     *
     * @param OrderInterface $order
     * @param string $reason
     * @return void
     */
    public function processFailedPayment(OrderInterface $order, string $reason = ''): void
    {
        if ($order->getState() === Order::STATE_CANCELED) {
            return;
        }
        if (!$order->canCancel()) {
            $this->spotiiHelper->logSpotiiActions(
                "Order {$order->getIncrementId()} cannot be canceled (state={$order->getState()})"
            );
            return;
        }
        $order->cancel();
        if ($reason !== '') {
            $order->addCommentToStatusHistory(__('PayLater: %1', $reason));
        }
        $order->save();
        $this->spotiiHelper->logSpotiiActions(
            "Canceled order {$order->getIncrementId()}: $reason"
        );
    }
}
