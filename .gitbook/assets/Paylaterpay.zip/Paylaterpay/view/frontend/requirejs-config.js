/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
var config = {
    map: {
        '*': {
            productWidget: 'PayLater_PayLaterpay/js/product-widget',
            catalogWidget: 'PayLater_PayLaterpay/js/catalog-widget'
        }
    }
};
