<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Source\Payment;

use Magento\Framework\Option\ArrayInterface;

/**
 * PayLater Payment Action Dropdown source
 */
class PaymentAction implements ArrayInterface
{
    /**
     * @inheritdoc
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => \PayLater\PayLaterpay\Model\SpotiiPay::ACTION_AUTHORIZE,
                'label' => __('Authorize Only'),
            ],
            [
                'value' => \PayLater\PayLaterpay\Model\SpotiiPay::ACTION_AUTHORIZE_CAPTURE,
                'label' => __('Authorize and Capture')
            ]
        ];
    }
}
