<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Model\Gateway;

use PayLater\PayLaterpay\Helper\Data as SpotiiHelper;
use PayLater\PayLaterpay\Model\Api\ConfigInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

/**
 * Class Transaction
 * @package PayLater\PayLaterpay\Model\Gateway
 */
class Transaction
{
    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    private $orderFactory;
    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;
    /**
     * @var \PayLater\PayLaterpay\Model\Api\ProcessorInterface
     */
    private $spotiiApiProcessor;
    /**
     * @var \Psr\Log\LoggerInterface
     */
    private $logger;
    /**
     * @var \Magento\Sales\Api\Data\OrderInterface
     */
    private $orderInterface;
    /**
     * @var ConfigInterface
     */
    private $config;

    /**
     * @var SpotiiHelper
     */
    private $spotiiHelper;

    /**
     * @var SpotiiApiConfigInterface
     */
    protected $spotiiApiIdentity;

    protected $_orderCollectionFactory;

    const PAYMENT_CODE = 'ppaylater';
    /**
     * Transaction constructor.
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param SpotiiHelper $spotiiHelper
     * @param ConfigInterface $config
     * @param \Psr\Log\LoggerInterface $logger
     * @param \PayLater\PayLaterpay\Model\Api\ProcessorInterface $spotiiApiProcessor
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param \Magento\Sales\Api\Data\OrderInterface $orderInterface
     */
    public function __construct(
        \Magento\Sales\Model\OrderFactory $orderFactory,
        SpotiiHelper $spotiiHelper,
        ConfigInterface $config,
        \Psr\Log\LoggerInterface $logger,
        \PayLater\PayLaterpay\Model\Api\ProcessorInterface $spotiiApiProcessor,
        SpotiiApiConfigInterface $spotiiApiConfig,
        \Magento\Sales\Api\Data\OrderInterface $orderInterface,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
    ) {
        $this->orderFactory = $orderFactory;
        $this->spotiiHelper = $spotiiHelper;
        $this->config = $config;
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->spotiiApiProcessor = $spotiiApiProcessor;
        $this->logger = $logger;
        $this->orderInterface = $orderInterface;
        $this->_orderCollectionFactory = $orderCollectionFactory;
    }

    /**
     * Send orders to PayLater
     */
    public function sendOrdersToSpotii()
    {
        $this->spotiiHelper->logSpotiiActions("****Order sync process start****");
        $today = date("Y-m-d H:i:s");
        $this->spotiiHelper->logSpotiiActions("Current date : $today");
        $yesterday = date("Y-m-d H:i:s", strtotime("-1 days"));
        $yesterday = date('Y-m-d H:i:s', strtotime($yesterday));
        $today = date('Y-m-d H:i:s', strtotime($today));

        try {
                $ordersCollection = $this->_orderCollectionFactory->create()
                ->addFieldToFilter(
                'status',
                ['eq' => 'paymentauthorised',
                 'eq' => 'processing']
                )->addFieldToFilter(
                 'created_at',
                ['gteq' => $yesterday]
                )->addFieldToFilter(
                'created_at',
                ['lteq' => $today]
                )->addAttributeToSelect('increment_id');


                $this->spotiiHelper->logSpotiiActions("ordersCollection ".sizeof($ordersCollection));

            $body = $this->_buildOrderPayLoad($ordersCollection);
            $url = $this->spotiiApiConfig->getSpotiiBaseUrl() . '/v1.0/merchant' . '/magento/orders';
            $authToken = $this->config->getAuthToken();
            $this->spotiiApiProcessor->call(
                $url,
                $authToken,
                $body,
                'POST'
            );
            $this->spotiiHelper->logSpotiiActions("****Order sync process end****");
        } catch (\Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Error while sending order to PayLater" . $e->getMessage());
        }
    }

    /**
     * Build Payload
     *
     * @param null $ordersCollection
     * @return array
     */
    private function _buildOrderPayLoad($ordersCollection = null)
    {
        $body = [];
        if ($ordersCollection) {
            foreach ($ordersCollection as $orderObj) {
                $orderIncrementId = $orderObj->getIncrementId();
                $order = $this->orderInterface->loadByIncrementId($orderIncrementId);
                $payment = $order->getPayment();
                $paymentMethod =$payment->getMethod();
                $this->spotiiHelper->logSpotiiActions("Orders ".$orderIncrementId);
                if($paymentMethod == self::PAYMENT_CODE){
                $billing = $order->getBillingAddress();
                $orderForSpotii = [
                    'order_number' => $orderIncrementId,
                    'payment_method' => $paymentMethod,
                    'amount' => strval(round($order->getGrandTotal(), \PayLater\PayLaterpay\Model\Api\PayloadBuilder::PRECISION)),
                    'currency' => $order->getOrderCurrencyCode(),
                    'reference' => $payment->getLastTransId(),
                    'customer_email' => $billing->getEmail(),
                    'customer_phone' => $billing->getTelephone(),
                    'billing_address1' => $billing->getStreetLine(1),
                    'billing_address2' => $billing->getStreetLine(2),
                    'billing_city' => $billing->getCity(),
                    'billing_state' => $billing->getRegionCode(),
                    'billing_postcode' => $billing->getPostcode(),
                    'billing_country' => $billing->getCountryId(),
                    'merchant_id' => $this->spotiiApiConfig->getMerchantId()
                ];
                array_push($body, $orderForSpotii);
            }
            }
        }
        return $body;
    }
}
