<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Model;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\Context;
use Magento\Sales\Model\Order;

/**
 * Class SpotiiPay
 * @package PayLater\PayLaterpay\Model
 */
class SpotiiPay extends \Magento\Payment\Model\Method\AbstractMethod
{
    const PAYMENT_CODE = 'ppaylater';
    const ADDITIONAL_INFORMATION_KEY_ORDERID = 'ppaylater_order_id';
    const SPOTII_CAPTURE_EXPIRY = 'ppaylater_capture_expiry';

    /**
     * @var string
     */
    protected $_code = self::PAYMENT_CODE;
    /**
     * @var bool
     */
    protected $_isGateway = true;

    protected $_isOffline = false;

    /**
     * @var bool
     */
    protected $_isInitializeNeeded = false;
    /**
     * @var bool
     */
    protected $_canOrder = true;
    /**
     * @var bool
     */
    protected $_canAuthorize = true;
    /**
     * @var bool
     */
    protected $_canCapture = true;
    /**
     * @var bool
     */
    protected $_canRefund = true;
    /**
     * @var bool
     */
    protected $_canRefundInvoicePartial = true;
    /**
     * @var bool
     */
    protected $_canUseInternal = false;
    /**
     * @var bool
     */
    protected $_canFetchTransactionInfo = true;

    /**
     * @var Api\PayloadBuilder
     */
    private $apiPayloadBuilder;
    /**
     * @var Config\Container\SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;
    /**
     * @var Config\Container\SpotiiApiConfigInterface
     */
    private $spotiiApiIdentity;
    /**
     * @var Api\ProcessorInterface
     */
    private $spotiiApiProcessor;
    /**
     * @var Order\Payment\Transaction\BuilderInterface
     */
    private $_transactionBuilder;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var \PayLater\PayLaterpay\Helper\Data
     */
    protected $spotiiHelper;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    private $dateTime;

    /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $messageManager;

    /**
     * @var Api\ConfigInterface
     */
    private $apiConfig;

    /**
     * SpotiiPay constructor.
     * @param Context $context
     * @param Config\Container\SpotiiApiConfigInterface $spotiiApiIdentity
     * @param Config\Container\SpotiiApiConfigInterface $spotiiApiConfig
     * @param \PayLater\PayLaterpay\Helper\Data $spotiiHelper
     * @param Api\PayloadBuilder $apiPayloadBuilder
     * @param Api\ProcessorInterface $spotiiApiProcessor
     * @param Api\ConfigInterface $apiConfig
     * @param Order\Payment\Transaction\BuilderInterface $transactionBuilder
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $mageLogger
     * @param CheckoutSession $checkoutSession
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
     */
    public function __construct(
        Context $context,
        Config\Container\SpotiiApiConfigInterface $spotiiApiIdentity,
        Config\Container\SpotiiApiConfigInterface $spotiiApiConfig,
        \PayLater\PayLaterpay\Helper\Data $spotiiHelper,
        Api\PayloadBuilder $apiPayloadBuilder,
        Api\ProcessorInterface $spotiiApiProcessor,
        Api\ConfigInterface $apiConfig,
        Order\Payment\Transaction\BuilderInterface $transactionBuilder,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $mageLogger,
        CheckoutSession $checkoutSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime
    ) {
        $this->apiPayloadBuilder = $apiPayloadBuilder;
        $this->spotiiHelper = $spotiiHelper;
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->spotiiApiIdentity = $spotiiApiIdentity;
        $this->spotiiApiProcessor = $spotiiApiProcessor;
        $this->apiConfig = $apiConfig;
        $this->_transactionBuilder = $transactionBuilder;
        $this->jsonHelper = $jsonHelper;
        $this->messageManager = $messageManager;
        $this->dateTime = $dateTime;
        $this->checkoutSession = $checkoutSession;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $mageLogger
        );
    }

    /**
     * Check whether payment method can be used
     *
     * @param \Magento\Quote\Api\Data\CartInterface|null $quote
     * @return bool
     */
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        // First, use our identity object to check the active flag based on the new config path
        if (!$this->spotiiApiIdentity->isEnabled()) {
            return false;
        }
        // Then, call the parent isAvailable method to perform standard checks (like totals, allowed countries etc.)
        return parent::isAvailable($quote);
    }

    /**
     * Override isActive to check the correct config path
     *
     * @param int|null $storeId
     * @return bool
     */
    public function isActive($storeId = null)
    {
        // Use the injected identity class which reads from payment/ppaylater/active
        return $this->spotiiApiIdentity->isEnabled();
    }

    /**
     * Get PayLater checkout url
     * @param $quote
     * @return bool|string
     */
    public function getSpotiiCheckoutUrl($quote)
    {
        try {
            $reference = uniqid() . "-" . $quote->getReservedOrderId();
            $this->spotiiHelper->logSpotiiActions("Reference Id : $reference");
            $payment = $quote->getPayment();
            $payment->setAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID, $reference);
            $payment->save();

            $this->spotiiHelper->logSpotiiActions(json_encode($quote));

            $response = $this->getSpotiiRedirectUrl($quote, $reference);
            $this->spotiiHelper->logSpotiiActions("response : $response");
            $result = $this->jsonHelper->jsonDecode($response, true);
            $orderUrl = array_key_exists('paymentLinkUrl', $result) ? $result['paymentLinkUrl'] : false;
            $this->spotiiHelper->logSpotiiActions("Order url : $orderUrl");
            
            if (!$orderUrl) {
                $this->spotiiHelper->logSpotiiActions("No payment link URL in response");
                return $this->apiConfig->getCancelUrl("No payment link URL in response");
            }
            return $orderUrl;
        } catch (\Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Error in getSpotiiCheckoutUrl: " . $e->getMessage());
            return $this->apiConfig->getCancelUrl($e->getMessage());
        }
    }

    /**
     * Get PayLater redirect url
     * @param $quote
     * @param $reference
     * @return mixed
     */
    public function getSpotiiRedirectUrl($quote, $reference)
    {
        $url = $this->spotiiApiIdentity->getSpotiiBaseUrl() . 'web-checkout/';
        $requestBody = $this->apiPayloadBuilder->buildSpotiiCheckoutPayload($quote, $reference);
        $this->spotiiHelper->logSpotiiActions("RB BEFORE CALL****");
        $this->spotiiHelper->logSpotiiActions(json_encode($requestBody));
        try {
            $apiKey = $this->spotiiApiConfig->getApiKey();
            $response = $this->spotiiApiProcessor->call(
                $url,
                $apiKey,
                $requestBody,
                'POST'
            );
            return $response;
        } catch (\Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Error in getSpotiiRedirectUrl: " . $e->getMessage());
            // Try to decode the error message as JSON
            $errorMessage = $e->getMessage();
            try {
                $decodedError = json_decode($errorMessage, true);
                if (isset($decodedError['error'])) {
                    $errorMessage = $decodedError['error'];
                }
            } catch (\Exception $jsonError) {
                // If JSON decode fails, keep the original error message
            }
            $this->messageManager->addErrorMessage(__('%1', $errorMessage));
            return json_encode([
                'paymentLinkUrl' => $this->apiConfig->getCancelUrl($errorMessage)
            ]);
        }
    }


    /**
     * Check if order total is matching
     *
     * @param float $magentoAmount
     * @param float $spotiiAmount
     * @return bool
     */
    public function isOrderAmountMatched($magentoAmount, $spotiiAmount, $magentoCurrency, $spotiiCurrency)
    {
        return true;
    }

    /**
     * Send authorize request to gateway
     *
     * @param \Magento\Framework\DataObject|\Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     * @throws LocalizedException
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $this->spotiiHelper->logSpotiiActions("****Authorization start****");
        $reference = $payment->getAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID);
        $currency =$payment->getOrder()->getGlobalCurrencyCode();
        $grandTotalInCents = round($amount, \PayLater\PayLaterpay\Model\Api\PayloadBuilder::PRECISION);
        $this->spotiiHelper->logSpotiiActions("PayLater Reference ID : $reference");
        $this->spotiiHelper->logSpotiiActions("Magento Order Total : $grandTotalInCents");
        $result = $this->getSpotiiOrderInfo($reference);
        $spotiiOrderTotal = isset($result['total']) ?
                                $result['total'] :
                                null;
        $spotiiOrderCurr = isset($result['currency']) ?
        $result['currency'] :
        null;
        $this->spotiiHelper->logSpotiiActions("PayLater Order Total : $spotiiOrderTotal");
        $this->spotiiHelper->logSpotiiActions("PayLater Order Currency : $spotiiOrderCurr");
        if ($spotiiOrderTotal != null
        && !$this->isOrderAmountMatched($grandTotalInCents, $spotiiOrderTotal, $currency, $spotiiOrderCurr)) {
            $this->spotiiHelper->logSpotiiActions("PayLater gateway has rejected request due to invalid order total");
            throw new LocalizedException(__('PayLater gateway has rejected request due to invalid order total.'));
        } else {
            $payment->setAdditionalInformation('payment_type', $this->getConfigData('payment_action'));
            $this->spotiiHelper->logSpotiiActions("Authorization successful");
            $this->spotiiHelper->logSpotiiActions("Authorization end");
        }
    }

    /**
     * Capture at Magento
     *
     * @param \Magento\Framework\DataObject|\Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return $this
     * @throws LocalizedException
     */
    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $reference = $payment->getAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID);
        $payment->setAdditionalInformation('payment_type', $this->getConfigData('payment_action'));
    }

    public function capturePostSpotii(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $this->spotiiHelper->logSpotiiActions("****Capture at Magento start****");
        if ($amount <= 0) {
            throw new LocalizedException(__('Invalid amount for capture.'));
        }
        $reference = $payment->getAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID);
        $currency =$payment->getOrder()->getGlobalCurrencyCode();
        $grandTotalInCents = round($amount, \PayLater\PayLaterpay\Model\Api\PayloadBuilder::PRECISION);
        $this->spotiiHelper->logSpotiiActions("PayLater Reference ID : $reference");
        $this->spotiiHelper->logSpotiiActions("Magento Order Total : $grandTotalInCents");

        $result = $this->getSpotiiOrderInfo($reference);
        $spotiiOrderTotal = isset($result['total']) ?
                                $result['total'] :
                                null;
        $spotiiOrderCurr = isset($result['currency']) ?
        $result['currency'] :
        null;
        $this->spotiiHelper->logSpotiiActions("PayLater Order Total : $spotiiOrderTotal");

        if ($spotiiOrderTotal != null
            && !$this->isOrderAmountMatched($grandTotalInCents, $spotiiOrderTotal, $currency, $spotiiOrderCurr)) {
            $this->spotiiHelper->logSpotiiActions("PayLater gateway has rejected request due to invalid order total");
            throw new LocalizedException(__('PayLater gateway has rejected request due to invalid order total.'));
        }

        $payment->setAdditionalInformation('payment_type', $this->getConfigData('payment_action'));
            //$this->spotiiCapture($reference);
            $payment->setTransactionId($reference)->setIsTransactionClosed(false);
            $this->spotiiHelper->logSpotiiActions("Authorized on PayLater");
            $this->spotiiHelper->logSpotiiActions("****Capture at Magento end****");
    }

    /**
     * Set PayLater Capture Expiry
     *
     * @param string $reference
     * @param \Magento\Sales\Api\Data\OrderPaymentInterface $payment
     * @return void
     * @throws LocalizedException
     */
    public function setSpotiiCaptureExpiry($reference, $payment)
    {
        $spotiiOrder = $this->getSpotiiOrderInfo($reference);
        if (isset($spotiiOrder['capture_expiration']) && $spotiiOrder['capture_expiration']) {
            $payment->setAdditionalInformation(self::SPOTII_CAPTURE_EXPIRY, $spotiiOrder['capture_expiration']);
            $payment->save();
        }
    }

    /**
     * Get order info from PayLater
     *
     * @param string $reference
     * @throws LocalizedException
     * @return array
     */
    public function getSpotiiOrderInfo($reference)
    {
        $this->spotiiHelper->logSpotiiActions("****Getting order status from PayLater****");
        $url = $this->spotiiApiIdentity->getSpotiiBaseUrl() . 'web-checkout/status?orderId=' . $reference . '&merchantId=' . $this->spotiiApiConfig->getMerchantId();
        $apiKey = $this->spotiiApiConfig->getApiKey();
        $result = $this->spotiiApiProcessor->call(
            $url,
            $apiKey,
            null,
            'GET'
        );
        $result = $this->jsonHelper->jsonDecode($result, true);
        if (isset($result['status']) && $result['status'] == \PayLater\PayLaterpay\Model\Api\ProcessorInterface::BAD_REQUEST) {
            throw new LocalizedException(__('Invalid checkout. Please retry again.'));
            return $this;
        }
        $this->spotiiHelper->logSpotiiActions("****Order successfully fetched from PayLater****");
        return $result;
    }

    /**
     * Capture payment at PayLater
     *
     * @param $reference
     * @return mixed
     * @throws LocalizedException
     */
    public function spotiiCapture($reference)
    {
        try {
            $this->spotiiHelper->logSpotiiActions("****Capture at PayLater Start****");
            $url = $this->spotiiApiIdentity->getSpotiiBaseUrl() . 'web-checkout/capture?orderId=' . $reference . '&merchantId=' . $this->spotiiApiConfig->getMerchantId();
            $apiKey = $this->spotiiApiConfig->getApiKey();
            $response = $this->spotiiApiProcessor->call(
                $url,
                $apiKey,
                null,
                'POST'
            );
            $this->spotiiHelper->logSpotiiActions("****Capture at PayLater End****");
        } catch (\Exception $e) {
            $this->spotiiHelper->logSpotiiActions($e->getMessage());
            throw new LocalizedException(__($e->getMessage()));
        }
        return $response;
    }

    /**
     * Create refund
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param $amount
     * @return $this
     * @throws LocalizedException
     */
    public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $this->spotiiHelper->logSpotiiActions("****Refund Start****");
        $orderId = $payment->getAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID);
        $this->spotiiHelper->logSpotiiActions("Order Id : $orderId");
        if ($orderId) {
            $currency = $payment->getOrder()->getGlobalCurrencyCode();
            $this->spotiiHelper->logSpotiiActions("Currency : $currency");
            try {
                $url = $this->spotiiApiIdentity->getSpotiiBaseUrl() . 'web-checkout/refund?orderId=' . $orderId . '&merchantId=' . $this->spotiiApiConfig->getMerchantId();
                $apiKey = $this->spotiiApiConfig->getApiKey();
                $requestPayload = [
                    "total" => round($amount, \PayLater\PayLaterpay\Model\Api\PayloadBuilder::PRECISION),
                    "currency" => $currency
                ];
                $this->spotiiApiProcessor->call(
                    $url,
                    $apiKey,
                    $requestPayload,
                    'POST'
                );
                $this->spotiiHelper->logSpotiiActions("****Refund End****");
                return $this;
            } catch (\Exception $e) {
                $this->spotiiHelper->logSpotiiActions($e->getMessage());
                throw new LocalizedException(__($e->getMessage()));
            }
        } else {
            $message = __('There are no PayLater payment linked to this order. Please use refund offline for this order.');
            throw new LocalizedException($message);
        }
    }

    public function processBeforeRefund($invoice, $payment){}
    public function processCreditmemo($creditmemo, $payment){}

    /**
     * Create transaction
     * @param $order
     * @param $reference
     * @return mixed
     */
    public function createTransaction($order, $reference, $type)
    {
        $this->spotiiHelper->logSpotiiActions("****Transaction start****");
        
        ob_start();
        print_r($order->debug()); // Or $order->getData() for raw data array
        $orderData = ob_get_clean();

        $this->spotiiHelper->logSpotiiActions("Order Details:\n" . $orderData);
        //$this->spotiiHelper->logSpotiiActions("Order Id : " . $order->getId());

        $this->spotiiHelper->logSpotiiActions("Reference Id : $reference");
        $payment = $order->getPayment();
        $payment->setLastTransId($reference);
        $payment->setTransactionId($reference);
        $formattedPrice = $order->getBaseCurrency()->formatTxt(
            $order->getGrandTotal()
        );

        if ($type == \Magento\Sales\Model\Order\Payment\Transaction::TYPE_ORDER) {
            $message = __('Order placed for amount %1.', $formattedPrice);
            $transactionId = $reference;
        } else {
            $message = __('Payment processed for amount %1.', $formattedPrice);
            $transactionId = $reference . '-' . $type;
        }
        $this->spotiiHelper->logSpotiiActions($message);
        $transaction = $this->_transactionBuilder->setPayment($payment)
            ->setOrder($order)
            ->setTransactionId($transactionId)
            ->setFailSafe(true)
            ->build($type);

        $payment->addTransactionCommentsToOrder(
            $transaction,
            $message
       );

        $payment->setParentTransactionId(null);
        $payment->save();
        // $quote->collectTotals()->save();
        $order->save();
        $transactionId = $transaction->save()->getTransactionId();
        $this->spotiiHelper->logSpotiiActions("Transaction Id : $transactionId");
        $this->spotiiHelper->logSpotiiActions("****Transaction End****");
        return $transactionId;
    }

    public function canRefund() {
        return true;
    }

    public function isOffline() {
        return false;
    }
}
