<?php

declare(strict_types=1);

namespace PayLater\PayLaterpay\Pricing\Render\ConfigurableProduct;

use Magento\Catalog\Model\Product\Pricing\Renderer\SalableResolverInterface;
use Magento\Catalog\Pricing\Price\MinimalPriceCalculatorInterface;
use Magento\ConfigurableProduct\Pricing\Price\ConfigurableOptionsProviderInterface;
use Magento\ConfigurableProduct\Pricing\Render\FinalPriceBox;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Pricing\Price\PriceInterface;
use Magento\Framework\Pricing\Render\RendererPool;
use Magento\Framework\Pricing\SaleableInterface;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\ScopeInterface;

class PayLaterConfiguration extends FinalPriceBox
{
    public $scopeConfig;

    public function __construct(
        Context                              $context,
        ScopeConfigInterface                 $scopeConfig,
        SaleableInterface                    $saleableItem,
        PriceInterface                       $price,
        RendererPool                         $rendererPool,
        SalableResolverInterface             $salableResolver,
        MinimalPriceCalculatorInterface      $minimalPriceCalculator,
        ConfigurableOptionsProviderInterface $configurableOptionsProvider,
        array                                $data = []
    ) {
        parent::__construct($context, $saleableItem, $price, $rendererPool, $salableResolver, $minimalPriceCalculator, $configurableOptionsProvider, $data);
        $this->scopeConfig = $scopeConfig;
    }

    public function getIsPlpActive()
    {
        //        return true;
        return $this->scopeConfig->getValue(
            'payment/ppaylater/plp_active',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getPlpMainHeading()
    {
        return $this->scopeConfig->getValue(
            'payment/ppaylater/main_heaing_plp',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getPlpSubHeading()
    {
        return $this->scopeConfig->getValue(
            'payment/ppaylater/sub_heading_plp',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getIsPdpActive()
    {
        return $this->scopeConfig->getValue(
            'payment/ppaylater/pdp_active',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getPdpMainHeading()
    {
        return $this->scopeConfig->getValue(
            'payment/ppaylater/main_heaing_pdp',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getPdpSubHeading()
    {
        return $this->scopeConfig->getValue(
            'payment/ppaylater/sub_heading_pdp',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getPdpTerms()
    {
        return $this->scopeConfig->getValue(
            'payment/ppaylater/terms',
            ScopeInterface::SCOPE_STORE,
        );
    }

    public function getIsPriceRangeFollowed($price)
    {
        $range = (string) $this->scopeConfig->getValue(
            'payment/ppaylater/price_range',
            ScopeInterface::SCOPE_STORE
        );

        if ($price < $range) {
            return false;
        }

        // Validate range rules
        if ($range >= 300) {
            return true;
        }

        return false;
    }
}
