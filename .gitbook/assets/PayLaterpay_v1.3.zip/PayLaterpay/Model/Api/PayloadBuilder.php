<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\StoreManagerInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

/**
 * Class PayloadBuilder
 * @package PayLater\PayLaterpay\Model\Api
 */
class PayloadBuilder
{
    const PRECISION = 2;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var SpotiiApiConfigInterface
     */
    protected $spotiiApiConfig;

    /**
     * @var ConfigInterface
     */
    protected $config;

    /**
     * PayloadBuilder constructor.
     * @param StoreManagerInterface $storeManager
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param ConfigInterface $config
     */
    public function __construct(
        StoreManagerInterface    $storeManager,
        SpotiiApiConfigInterface $spotiiApiConfig,
        ConfigInterface          $config
    ) {
        $this->storeManager = $storeManager;
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->config = $config;
    }

    /**
     * Build PayLater checkout payload
     * @param $quote
     * @param $reference
     * @return array
     */
    public function buildSpotiiCheckoutPayload($quote, $reference)
    {
        return [
            'merchantId' => $this->spotiiApiConfig->getMerchantId(),
            'outletId' => $this->spotiiApiConfig->getOutletId(),
            'currency' => $quote->getQuoteCurrencyCode(),
            'amount' => round((int)$quote->getGrandTotal(), self::PRECISION),
            'orderId' => $reference,
            'successRedirectUrl' => urldecode($this->config->getCompleteUrl()),
            'failRedirectUrl' => urldecode($this->config->getCancelUrl())
        ];
    }

    /**
     * Build Checkout Payload from Magento Checkout
     * @param $quote
     * @param $reference
     * @return mixed
     * @throws NoSuchEntityException
     */
    private function buildCheckoutPayload($quote, $reference)
    {
        $orderId = $quote->getReservedOrderId();
        $completeUrl = $this->spotiiApiConfig->getCompleteUrl($orderId, $reference, $quote->getId());
        $cancelUrl = $this->spotiiApiConfig->getCancelUrl($orderId, $reference);
        $checkoutPayload["total"] = strval(round($quote->getGrandTotal(), self::PRECISION));
        $checkoutPayload["currency"] = $this->storeManager->getStore()->getCurrentCurrencyCode();
        $checkoutPayload["description"] = $reference;
        $checkoutPayload["reference"] = $reference;
        $checkoutPayload["display_reference"] = $orderId;
        $checkoutPayload["reject_callback_url"] = $cancelUrl;
        $checkoutPayload["confirm_callback_url"] = $completeUrl;
        return $checkoutPayload;
    }

    /**
     * Build Order Payload
     * @param $quote
     * @return mixed
     */
    private function buildOrderPayload($quote)
    {
        $orderPayload["order"] = [
            "tax_amount" => $quote->getShippingAddress()->getBaseTaxAmount(),
            "shipping_amount" => $quote->getShippingAddress()->getShippingAmount(),
            "discount" => ($quote->getSubtotal() - $quote->getSubtotalWithDiscount())
        ];
        return $orderPayload;
    }

    /**
     * Build Customer Payload
     * @param $quote
     * @return mixed
     */
    private function buildCustomerPayload($quote)
    {
        $billingAddress = $quote->getBillingAddress();
        $customerPayload["order"]["customer"] = [
            "first_name" => $quote->getCustomerFirstname() ? $quote->getCustomerFirstname() : $billingAddress->getFirstname(),
            "last_name" => $quote->getCustomerLastname() ? $quote->getCustomerLastname() : $billingAddress->getLastname(),
            "email" => $quote->getCustomerEmail(),
            "phone" => $billingAddress->getTelephone(),
        ];
        return $customerPayload;
    }

    /**
     * Build Billing Address Payload
     * @param $quote
     * @return mixed
     */
    private function buildBillingPayload($quote)
    {
        $billingAddress = $quote->getBillingAddress();
        $billingPayload["order"]["billing_address"] = [
            "line1" => $billingAddress->getStreetLine(1),
            "line2" => $billingAddress->getStreetLine(2),
            "line4" => $billingAddress->getCity(),
            "state" => $billingAddress->getRegionCode(),
            "postcode" => $billingAddress->getPostcode(),
            "country" => $billingAddress->getCountryId(),
            "phone" => $billingAddress->getTelephone(),
        ];
        return $billingPayload;
    }

    /**
     * Build Shipping Address Payload
     * @param $quote
     * @return mixed
     */
    private function buildShippingPayload($quote)
    {
        $shippingAddress = $quote->getShippingAddress();
        $shippingPayload["order"]["shipping_address"] = [
            "line1" => $shippingAddress->getStreetLine(1),
            "line2" => $shippingAddress->getStreetLine(2),
            "line4" => $shippingAddress->getCity(),
            "state" => $shippingAddress->getRegionCode(),
            "postcode" => $shippingAddress->getPostcode(),
            "country" => $shippingAddress->getCountryId(),
            "phone" => $shippingAddress->getTelephone(),
        ];
        return $shippingPayload;
    }

    /**
     * Build Cart Item Payload
     * @param $quote
     * @return mixed
     * @throws NoSuchEntityException
     */
    private function buildItemPayload($quote)
    {
        $currencyCode = $this->storeManager->getStore()->getCurrentCurrencyCode();
        $itemPayload["order"]["lines"] = [];
        foreach ($quote->getAllVisibleItems() as $item) {
            $productName = $item->getName();
            $productSku = $item->getSku();
            $productQuantity = $item->getQtyOrdered();
            $itemData = [
                "title" => $productName,
                "sku" => $productSku,
                "quantity" => $productQuantity,
                "price" => strval(round($item->getPriceInclTax(), self::PRECISION)),
                "currency" => $currencyCode,
            ];
            array_push($itemPayload["order"]["lines"], $itemData);
        }
        return $itemPayload;
    }
}
