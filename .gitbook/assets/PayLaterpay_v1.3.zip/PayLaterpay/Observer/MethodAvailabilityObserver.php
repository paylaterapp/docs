<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class MethodAvailabilityObserver
 * @package PayLater\PayLaterpay\Observer
 */
class MethodAvailabilityObserver implements ObserverInterface
{
    const PAYMENT_CODE = 'ppaylater';

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * MethodAvailabilityObserver constructor.
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param Logger $logger
     */
    public function __construct(
        SpotiiApiConfigInterface $spotiiApiConfig,
        Logger                   $logger
    )
    {
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->logger = $logger;
    }

    /**
     * Hide the method if merchant id, outlet id or API key are not present
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $result = $observer->getEvent()->getResult();
        $methodInstance = $observer->getEvent()->getMethodInstance();
        $methodCode = $methodInstance->getCode();

        $this->logger->info('PayLater Availability Check - Method Code: ' . $methodCode);

        if ($methodCode == self::PAYMENT_CODE) {
            $merchantId = $this->spotiiApiConfig->getMerchantId();
            $outletId = $this->spotiiApiConfig->getOutletId();
            $apiKey = $this->spotiiApiConfig->getApiKey();

            $this->logger->info('PayLater Availability Check - Merchant ID: ' . ($merchantId ? $merchantId : 'EMPTY'));
            $this->logger->info('PayLater Availability Check - Outlet ID: ' . ($outletId ? $outletId : 'EMPTY'));
            $this->logger->info('PayLater Availability Check - API Key: ' . ($apiKey ? 'PRESENT' : 'EMPTY'));

            if (!$merchantId || !$outletId || !$apiKey) {
                $result->setData('is_available', false);
                $this->logger->info('PayLater Availability Check - Result: Method DISABLED due to missing configuration.');
            } else {
                // Optionally log when it's available
                $this->logger->info('PayLater Availability Check - Result: Method ENABLED.');
            }
        } else {
            $this->logger->info('PayLater Availability Check - Skipping method: ' . $methodCode);
        }
    }
}
