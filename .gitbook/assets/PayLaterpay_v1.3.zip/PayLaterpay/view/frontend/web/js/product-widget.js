/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
define([
    'jquery',
    'ko',
    'uiComponent',
    'domReady!'
], function ($, ko, Component) {
    'use strict';

    return Component.extend({
        initialize: function () {
            this._super();
            this.processPayLaterDocument();
        },

        processPayLaterDocument: function() {
            console.log("rendering started");
            var self = this;
            console.log(self.jsConfig);
            document.paylaterConfig = self.jsConfig;

            if (!document.paylaterConfig) {
                console.warn('PayLater: document.paylaterConfig is not set, cannot render widget');
                return;
            }

            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = require.toUrl('PayLater_PayLaterpay/js/paylater-widget.js');
            $("head").append(script);

            console.log("dom loaded");
        }
    });
});
