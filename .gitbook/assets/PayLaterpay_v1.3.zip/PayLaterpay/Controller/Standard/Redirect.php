<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Controller\Standard;

use Exception;
use Magento\Customer\Api\Data\GroupInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

/**
 * Class Redirect
 * @package PayLater\PayLaterpay\Controller\Standard
 */
class Redirect extends SpotiiPay
{
    /**
     * Redirection
     *
     * @return mixed
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function execute()
    {
        $this->spotiiHelper->logSpotiiActions("****Starting PayLater****");
        $quote = $this->checkoutSession->getQuote();
        $this->spotiiHelper->logSpotiiActions("Quote Id : " . $quote->getId());
        if ($this->customerSession->isLoggedIn()) {
            $customerId = $this->customerSession->getCustomer()->getId();
            $this->spotiiHelper->logSpotiiActions("Customer Id : $customerId");
            $customer = $this->customerRepository->getById($customerId);
            $quote->setCustomer($customer);
            $billingAddress = $quote->getBillingAddress();
            $shippingAddress = $quote->getShippingAddress();
            if ((empty($shippingAddress) || empty($shippingAddress->getStreetLine(1))) && (empty($billingAddress) || empty($billingAddress->getStreetLine(1)))) {
                $json = $this->jsonHelper->jsonEncode(["message" => "Please select an address"]);
                $jsonResult = $this->resultJsonFactory->create();
                $jsonResult->setData($json);
                return $jsonResult;
            } elseif (empty($billingAddress) || empty($billingAddress->getStreetLine(1)) || empty($billingAddress->getFirstname())) {
                $quote->setBillingAddress($shippingAddress);
            }
        } else {
            $post = $this->getRequest()->getPostValue();
            $this->spotiiHelper->logSpotiiActions('Post Data: ' . print_r($post, true));
            $this->spotiiHelper->logSpotiiActions("Guest customer");
            if (!empty($post['email'])) {
                $quote->setCustomerEmail($post['email'])
                    ->setCustomerIsGuest(true)
                    ->setCustomerGroupId(GroupInterface::NOT_LOGGED_IN_ID);
            }
        }
        $payment = $quote->getPayment();
        $payment->setMethod('ppaylater');
        $payment->save();
        $quote->reserveOrderId();
        $quote->setPayment($payment);
        $quote->save();
        $this->checkoutSession->replaceQuote($quote);
        $checkoutUrl = $this->spotiipayModel->getSpotiiCheckoutUrl($quote);
        $this->spotiiHelper->logSpotiiActions("Checkout Url : $checkoutUrl");
        try {
            $json = $this->jsonHelper->jsonEncode(["redirectURL" => $checkoutUrl]);
            $jsonResult = $this->resultJsonFactory->create();
            $jsonResult->setData($json);

        } catch (LocalizedException|Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Redirect Exception: " . $e->getMessage());
            $this->messageManager->addErrorMessage(
                $e->getMessage()
            );
        }
        return $jsonResult;
    }
}
