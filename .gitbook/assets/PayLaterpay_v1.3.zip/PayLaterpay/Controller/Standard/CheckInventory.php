<?php

namespace PayLater\PayLaterpay\Controller\Standard;

use Magento\Framework\Exception\NoSuchEntityException;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;
use Zend_Log_Exception;

/**
 * PayLater Helper
 */
class CheckInventory extends SpotiiPay
{
    /**
     * Dump PayLater log actions
     * @throws NoSuchEntityException
     * @throws Zend_Log_Exception
     */
    public function execute()
    {
        $post = $this->getRequest()->getPostValue();
        $itemsString = $post['items'];
        $this->spotiiHelper->logSpotiiActions($itemsString);

        $items = $this->jsonHelper->jsonDecode($itemsString);
        $this->spotiiHelper->logSpotiiActions($items);

        $flag = true;
        foreach ($items as $item) {
            $sku = $item['sku'];
            $this->spotiiHelper->logSpotiiActions("checking ... " . $sku);

            $qtyOrdered = $item['qty'];

            $stockItem = $this->stockRegistry->getStockItemBySku($sku);
            $qtyInStock = $stockItem->getQty();
            if ($qtyInStock < $qtyOrdered) {
                $flag = false;
            }
        }
        $json = $this->jsonHelper->jsonEncode(["isInStock" => $flag]);
        $jsonResult = $this->resultJsonFactory->create();
        $jsonResult->setData($json);
        return $jsonResult;
    }
}
