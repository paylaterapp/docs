<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Block\Adminhtml\System\Config;

use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use PayLater\PayLaterpay\Model\System\Config;

class SpotiiRegisterAdmin extends Template
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var Json
     */
    private $jsonHelper;

    /**
     * SpotiiRegisterAdmin constructor.
     *
     * @param Context $context
     * @param Config $config
     * @param Json $jsonHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Json    $jsonHelper,
        Config  $config,
        array   $data = []
    ) {
        parent::__construct($context, $data);
        $this->config = $config;
        $this->jsonHelper = $jsonHelper;
    }

    /**
     * Return config settings
     */
    public function getJsonConfig()
    {
        return $this->jsonHelper->serialize($this->config->getSpotiiJsonConfig());
    }
}
