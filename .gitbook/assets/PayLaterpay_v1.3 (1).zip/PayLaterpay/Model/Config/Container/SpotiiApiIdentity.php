<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Container;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class SpotiiApiIdentity
 * @package PayLater\PayLaterpay\Model\Config\Container
 */
class SpotiiApiIdentity extends Container implements SpotiiApiConfigInterface
{
    const XML_PATH_PAYMENT_ACTIVE = 'payment/ppaylater/active';
    const XML_PATH_API_KEY = 'payment/ppaylater/api_key';
    const XML_PATH_PAYMENT_MODE = 'payment/ppaylater/payment_mode';
    const XML_PATH_MERCHANT_ID = 'payment/ppaylater/merchant_id';
    const XML_PATH_OUTLET_ID = 'payment/ppaylater/outlet_id';
    const XML_PATH_LOG_ENABLED = 'payment/ppaylater/log_tracker';

    private $apiUrlLive = "https://connect.paylaterapp.com/api/paylater/merchant-portal/";
    //private $apiUrlSandbox = "https://api.sandbox.paylaterapp.com/api/paylater/merchant-portal/";
    private $apiUrlSandbox = "https://connect-sandbox.paylaterapp.com/api/paylater/merchant-portal/";

    /**
     * @var EncryptorInterface
     */
    private $encryptor;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param EncryptorInterface $encryptor
     */
    public function __construct(
        ScopeConfigInterface  $scopeConfig,
        StoreManagerInterface $storeManager,
        EncryptorInterface    $encryptor
    ) {
        $this->encryptor = $encryptor;
        parent::__construct($scopeConfig, $storeManager);
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_PAYMENT_ACTIVE,
            ScopeInterface::SCOPE_STORE,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getApiKey()
    {
        $encryptedApiKey = $this->getConfigValue(
            self::XML_PATH_API_KEY,
            $this->getStore()->getStoreId()
        );
        return $encryptedApiKey ? $this->encryptor->decrypt($encryptedApiKey) : null;
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getMerchantId()
    {
        return $this->getConfigValue(
            self::XML_PATH_MERCHANT_ID,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getOutletId()
    {
        return $this->getConfigValue(
            self::XML_PATH_OUTLET_ID,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     */
    public function getSpotiiBaseUrl()
    {
        return $this->getPaymentMode() === 'sandbox'
            ? $this->apiUrlSandbox
            : $this->apiUrlLive;
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getPaymentMode()
    {
        return $this->getConfigValue(
            self::XML_PATH_PAYMENT_MODE,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function isLogEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_LOG_ENABLED,
            ScopeInterface::SCOPE_STORE,
            $this->getStore()->getStoreId()
        );
    }
}
