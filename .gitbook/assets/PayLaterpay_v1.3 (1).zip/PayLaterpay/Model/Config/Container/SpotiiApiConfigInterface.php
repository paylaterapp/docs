<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Container;

use Magento\Store\Model\Store;

/**
 * Interface IdentityInterface
 * @package PayLater\PayLaterpay\Model\Config\Container
 */
interface SpotiiApiConfigInterface
{
    /**
     * Check if payment method is enabled
     * @return bool
     */
    public function isEnabled();

    /**
     * Get API Key
     * @return string
     */
    public function getApiKey();

    /**
     * Get Merchant ID
     * @return string
     */
    public function getMerchantId();

    /**
     * Get Outlet ID
     * @return string
     */
    public function getOutletId();

    /**
     * Get Payment Mode (sandbox/live)
     * @return string
     */
    public function getPaymentMode();

    /**
     * Get Base URL for API
     * @return string
     */
    public function getSpotiiBaseUrl();

    /**
     * Get if logging is enabled
     * @return bool
     */
    public function isLogEnabled();
}
