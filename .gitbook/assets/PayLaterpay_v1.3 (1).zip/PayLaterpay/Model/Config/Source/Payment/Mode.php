<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Source\Payment;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Mode
 * @package PayLater\PayLaterpay\Model\Config\Source\Payment
 */
class Mode implements ArrayInterface
{

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => 'live',
                'label' => 'Live',
            ],
            [
                'value' => 'sandbox',
                'label' => 'Sandbox',
            ]
        ];
    }
}
