<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Source\Product;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class ThemeAlignment
 * @package PayLater\PayLaterpay\Model\Config\Source\Product
 */
class ThemeAlignment implements OptionSourceInterface
{

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => 'light',
                'label' => 'Light',
            ],
            [
                'value' => 'dark',
                'label' => 'Dark',
            ],
        ];
    }
}
