<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\System\Config\Source;

use Magento\Directory\Model\ResourceModel\Country\CollectionFactory;
use Magento\Framework\Data\OptionSourceInterface;
use PayLater\PayLaterpay\Model\System\Config;

/**
 * Source model for merchant countries supported by PayLater
 */
class MerchantCountry implements OptionSourceInterface
{
    /**
     * @var Config
     */
    private $config;

    /**
     * @var CollectionFactory
     */
    private $countryCollectionFactory;

    /**
     * @param Config $config
     * @param CollectionFactory $countryCollectionFactory
     */
    public function __construct(
        Config            $config,
        CollectionFactory $countryCollectionFactory
    ) {
        $this->config = $config;
        $this->countryCollectionFactory = $countryCollectionFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        $supported = $this->config->getSupportedMerchantCountryCodes();
        $options = $this->countryCollectionFactory->create()->addCountryCodeFilter(
            $supported,
            'iso2'
        )->loadData()->toOptionArray(false);

        return $options;
    }
}
