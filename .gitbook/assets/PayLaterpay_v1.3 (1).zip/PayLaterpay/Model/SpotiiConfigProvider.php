<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model;

use Magento\Checkout\Model\ConfigProviderInterface;

/**
 * Class SpotiiConfigProvider
 * @package PayLater\PayLaterpay\Model
 */
class SpotiiConfigProvider implements ConfigProviderInterface
{

    /**
     * @return array
     */
    public function getConfig()
    {
        return [
            'payment' => [
                'ppaylater' => [
                    'methodCode' => "ppaylater"
                ]
            ]
        ];
    }
}
