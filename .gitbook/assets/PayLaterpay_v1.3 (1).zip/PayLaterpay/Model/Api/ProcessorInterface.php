<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Framework\HTTP\ZendClient;

/**
 * Interface ProcessorInterface
 * @package PayLater\PayLaterpay\Model\Api
 */
interface ProcessorInterface
{
    const BAD_REQUEST = 400;

    /**
     * Call to PayLater Gateway
     *
     * @param string $url
     * @param string $apiKey
     * @param array|bool $body
     * @param string $method
     * @return mixed
     */
    public function call(
        $url,
        $apiKey,
        $body = false,
        $method = ZendClient::GET
    );
}
