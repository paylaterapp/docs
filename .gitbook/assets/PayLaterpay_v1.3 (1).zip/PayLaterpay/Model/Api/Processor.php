<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Exception;
use Magento\Framework\App\Config\ScopeConfigInterface as ScopeConfig;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\HTTP\ZendClient;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use PayLater\PayLaterpay\Helper\Data as SpotiiHelper;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class Processor
 * @package PayLater\PayLaterpay\Model\Api
 */
class Processor implements ProcessorInterface
{

    /**
     * @var JsonHelper
     */
    protected $jsonHelper;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var ScopeConfig
     */
    protected $scopeConfig;

    /**
     * @var Curl
     */
    protected $curl;

    /**
     * @var SpotiiHelper
     */
    protected $spotiiHelper;

    /**
     * Processor constructor.
     * @param Curl $curl
     * @param SpotiiHelper $spotiiHelper
     * @param JsonHelper $jsonHelper
     * @param Logger $logger
     * @param ScopeConfig $scopeConfig
     */
    public function __construct(
        Curl         $curl,
        SpotiiHelper $spotiiHelper,
        JsonHelper   $jsonHelper,
        Logger       $logger,
        ScopeConfig  $scopeConfig
    ) {
        $this->curl = $curl;
        $this->spotiiHelper = $spotiiHelper;
        $this->jsonHelper = $jsonHelper;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Call to PayLater Gateway
     *
     * @param string $url
     * @param string $apiKey
     * @param array|bool $body
     * @param string $method
     * @return mixed
     * @throws LocalizedException
     */
    public function call($url, $apiKey, $body = false, $method = ZendClient::GET)
    {
        try {
            //xdebug_break();
            $this->spotiiHelper->logSpotiiActions("****API KEY****");
            if ($apiKey) {
                $this->spotiiHelper->logSpotiiActions("Using API Key: " . $apiKey);
            }

            // Initialize headers as key-value pairs
            $headerArray = [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'X-Api-Key' => $apiKey,
                'User-Agent' => 'PayLater-Magento/1.0'
            ];

            // Convert to curl format with proper spacing
            $headers = array_map(function ($key, $value) {
                return $key . ': ' . $value;
            }, array_keys($headerArray), $headerArray);

            if ($this->spotiiHelper->isLogEnabled()) {
                $this->spotiiHelper->logSpotiiActions("****Request Info****");
                $requestLog = [
                    'type' => 'Request',
                    'method' => $method,
                    'url' => $url,
                    'body' => $body,
                    'headers' => $headerArray  // Log the key-value pairs for clarity
                ];
                $this->spotiiHelper->logSpotiiActions(json_encode($requestLog, JSON_UNESCAPED_SLASHES));
            }

            switch ($method) {
                case 'POST':
                    $encodedBody = json_encode($body, JSON_UNESCAPED_SLASHES);
                    if ($this->spotiiHelper->isLogEnabled()) {
                        $curlCommand = sprintf(
                            "curl -X POST '%s' \\\n%s \\\n-d '%s'",
                            $url,
                            implode(" \\\n", array_map(function ($header) {
                                return "-H '$header'";
                            }, $headers)),
                            $encodedBody
                        );

                        $curlDetails = [
                            'type' => 'CURL Details',
                            'url' => $url,
                            'headers' => $headerArray,  // Log the key-value pairs for clarity
                            'raw_payload' => $encodedBody,
                            'curl_command' => $curlCommand
                        ];
                        $this->spotiiHelper->logSpotiiActions("****CURL Request Details****");
                        $this->spotiiHelper->logSpotiiActions(json_encode($curlDetails, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
                    }

                    // Use native PHP curl
                    $ch = curl_init($url);

                    // Basic options
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedBody);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_TIMEOUT, ApiParamsInterface::TIMEOUT);
                    curl_setopt($ch, CURLOPT_HEADER, true);  // Include headers in response
                    curl_setopt($ch, CURLOPT_ENCODING, '');  // Accept all encodings
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  // Follow redirects
                    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);  // Use HTTP/2
                    curl_setopt($ch, CURLOPT_USERAGENT, 'PayLater-Magento/1.0');

                    // SSL options
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
                    curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);

                    // Debug options
                    $verbose = fopen('php://temp', 'w+');
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_STDERR, $verbose);

                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $error = curl_error($ch);

                    // Split response into headers and body since we set CURLOPT_HEADER
                    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                    $responseHeaders = substr($response, 0, $headerSize);
                    $responseBody = substr($response, $headerSize);

                    // Get verbose information
                    rewind($verbose);
                    $verboseLog = stream_get_contents($verbose);
                    fclose($verbose);

                    if ($this->spotiiHelper->isLogEnabled()) {
                        $responseLog = [
                            'type' => 'Response',
                            'method' => $method,
                            'url' => $url,
                            'httpStatusCode' => $httpCode,
                            'responseHeaders' => $responseHeaders,
                            'response' => $responseBody,
                            'curl_error' => $error,
                            'curl_info' => curl_getinfo($ch),
                            'verbose_log' => $verboseLog
                        ];
                        $this->spotiiHelper->logSpotiiActions("****Response Info****");
                        $this->spotiiHelper->logSpotiiActions(json_encode($responseLog, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
                    }

                    curl_close($ch);

                    if ($httpCode >= 400) {
                        // Try to decode JSON response
                        $decodedResponse = json_decode($responseBody, true);
                        $errorMessage = isset($decodedResponse['error']) ? $decodedResponse['error'] : ($responseBody ?: $error);

                        throw new LocalizedException(
                            //__('Gateway error: %1', $responseBody ?: $error)
                            __('%1', $errorMessage)
                        );
                    }

                    return $responseBody;

                case 'GET':
                    // Use native PHP curl for GET
                    $ch = curl_init($url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_TIMEOUT, ApiParamsInterface::TIMEOUT);

                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $error = curl_error($ch);

                    if ($this->spotiiHelper->isLogEnabled()) {
                        $responseLog = [
                            'type' => 'Response',
                            'method' => $method,
                            'url' => $url,
                            'httpStatusCode' => $httpCode,
                            'response' => $response,
                            'curl_error' => $error
                        ];
                        $this->spotiiHelper->logSpotiiActions("****Response Info****");
                        $this->spotiiHelper->logSpotiiActions(json_encode($responseLog, JSON_UNESCAPED_SLASHES));
                    }

                    curl_close($ch);

                    if ($httpCode >= 400) {
                        throw new LocalizedException(
                            __('%1', $response ?: $error)
                        );
                    }
                    break;

                default:
                    break;
            }

            return $response;
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions($e->getMessage());
            throw new LocalizedException(
                __('%1', $e->getMessage())
            );
        }
    }
}
