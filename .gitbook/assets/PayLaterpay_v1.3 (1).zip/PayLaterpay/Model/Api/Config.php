<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Framework\App\Config\ScopeConfigInterface as ScopeConfig;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\Framework\UrlInterface;
use PayLater\PayLaterpay\Helper\Data as SpotiiHelper;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class Config
 * @package PayLater\PayLaterpay\Model\Api
 */
class Config implements ConfigInterface
{
    /**
     * @var JsonHelper
     */
    protected $jsonHelper;

    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var ScopeConfig
     */
    protected $scopeConfig;

    /**
     * @var SpotiiApiConfigInterface
     */
    protected $spotiiApiConfig;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * @var ProcessorInterface
     */
    protected $apiProcessor;

    /**
     * @var SpotiiHelper
     */
    protected $spotiiHelper;

    /**
     * Config constructor.
     * @param UrlInterface $urlBuilder
     * @param ProcessorInterface $apiProcessor
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param SpotiiHelper $spotiiHelper
     * @param JsonHelper $jsonHelper
     * @param Logger $logger
     * @param ScopeConfig $scopeConfig
     */
    public function __construct(
        UrlInterface             $urlBuilder,
        ProcessorInterface       $apiProcessor,
        SpotiiApiConfigInterface $spotiiApiConfig,
        SpotiiHelper             $spotiiHelper,
        JsonHelper               $jsonHelper,
        Logger                   $logger,
        ScopeConfig              $scopeConfig
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->apiProcessor = $apiProcessor;
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->spotiiHelper = $spotiiHelper;
        $this->jsonHelper = $jsonHelper;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Get complete url
     * @return string
     */
    public function getCompleteUrl()
    {
        return $this->urlBuilder->getUrl(
            "ppaylater/standard/complete",
            ['_secure' => true]
        );
    }

    /**
     * Get cancel url
     * @param string|null $error Optional error message to append to URL
     * @return string
     */
    public function getCancelUrl($error = null)
    {
        $params = ['_secure' => true];
        if ($error !== null) {
            $params['error'] = $error;
        }
        return $this->urlBuilder->getUrl(
            "ppaylater/standard/cancel",
            $params
        );
    }
}
