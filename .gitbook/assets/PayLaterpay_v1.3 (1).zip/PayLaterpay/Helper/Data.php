<?php

declare(strict_types=1);

namespace PayLater\PayLaterpay\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Zend_Log;
use Zend_Log_Writer_Stream;

/**
 * PayLater Helper
 */
class Data extends AbstractHelper
{
    const SPOTII_LOG_FILE_PATH = '/var/log/ppaylater.log';

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * Initialize dependencies.
     *
     * @param Context $context
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     */
    public function __construct(
        Context                  $context,
        SpotiiApiConfigInterface $spotiiApiConfig
    ) {
        $this->spotiiApiConfig = $spotiiApiConfig;
        parent::__construct($context);
    }

    /**
     * Dump PayLater log actions
     *
     * @param string $msg
     * @return void
     * @throws \Zend_Log_Exception
     */
    public function logSpotiiActions($data = null)
    {
        if ($this->isLogEnabled()) {
            $writer = new Zend_Log_Writer_Stream(BP . self::SPOTII_LOG_FILE_PATH);
            $logger = new Zend_Log();
            $logger->addWriter($writer);
            $logger->info($data);
        }
    }

    /**
     * Check if logging is enabled
     * @return bool
     */
    public function isLogEnabled()
    {
        return $this->spotiiApiConfig->isLogEnabled();
    }
}
