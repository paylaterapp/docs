<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Block\Adminhtml\System\Config\Form;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use PayLater\PayLaterpay\Block\Adminhtml\System\Config\SpotiiRegisterAdmin;

class SpotiiRegisterConfig extends Field
{

    /**
     * Render element value
     *
     * @param AbstractElement $element
     * @return string
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function render(AbstractElement $element)
    {
        $html = $this->_layout
            ->createBlock(SpotiiRegisterAdmin::class)
            ->setTemplate('PayLater_PayLaterpay::system/config/spotii_register_admin.phtml')
            ->setCacheable(false)
            ->toHtml();

        return $html;
    }
}
