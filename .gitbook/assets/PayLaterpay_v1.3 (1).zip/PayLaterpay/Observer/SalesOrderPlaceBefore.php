<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Observer;

use Exception;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface;
use Magento\Quote\Model\QuoteFactory;
use Magento\Sales\Model\OrderFactory;
use PayLater\PayLaterpay\Helper\Data;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use PayLater\PayLaterpay\Model\SpotiiPay;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class MethodAvailabilityObserver
 * @package PayLater\PayLaterpay\Observer
 */
class SalesOrderPlaceBefore implements ObserverInterface
{
    const PAYMENT_CODE = 'ppaylater';

    /**
     * @var QuoteFactory
     */
    protected $quoteFactory;

    /**
     * @var OrderFactory
     */
    protected $_orderFactory;

    /**
     * @var SpotiiPay
     */
    private $spotiiPayModel;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiIdentity;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var Data
     */
    private $spotiiHelper;

    /**
     * @var ManagerInterface
     */
    private $messageManager;

    /**
     * MethodAvailabilityObserver constructor.
     * @param SpotiiApiConfigInterface $spotiiApiIdentity
     * @param Logger $logger
     * @param SpotiiPay $spotiiPayModel
     * @param Data $spotiiHelper
     * @param ManagerInterface $messageManager
     * @param QuoteFactory $quoteFactory
     * @param OrderFactory $orderFactory
     */
    public function __construct(
        SpotiiApiConfigInterface $spotiiApiIdentity,
        Logger                   $logger,
        SpotiiPay                $spotiiPayModel,
        Data                     $spotiiHelper,
        ManagerInterface         $messageManager,
        QuoteFactory             $quoteFactory,
        OrderFactory             $orderFactory
    ) {
        $this->spotiiApiIdentity = $spotiiApiIdentity;
        $this->logger = $logger;
        $this->spotiiPayModel = $spotiiPayModel;
        $this->spotiiHelper = $spotiiHelper;
        $this->messageManager = $messageManager;
        $this->quoteFactory = $quoteFactory;
    }

    /**
     * Hide the method if merchant id, public key & private key are not present
     * @param Observer $observer
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $this->spotiiHelper->logSpotiiActions("PayLater observer order ID " . $order->getQuoteId());
        $quoteId = $order->getQuoteId();
        $quote = $this->quoteFactory->create()->load($quoteId);
        $this->spotiiHelper->logSpotiiActions("PayLater observer payment method " . strval($quote->getPayment()->getMethod()));

        if ($quote->getPayment()->getMethod() == "spotiipay") {
            try {
                $order->setCanSendNewEmailFlag(false);
                $order->setEmailSent(false);
            } catch (LocalizedException $e) {
                $this->spotiiHelper->logSpotiiActions('OrderPlaceBefore local' . $e->getMessage());
            } catch (Exception $e) {
                $this->spotiiHelper->logSpotiiActions('OrderPlaceBefore ' . $e->getMessage());
            }
        }
    }
}
