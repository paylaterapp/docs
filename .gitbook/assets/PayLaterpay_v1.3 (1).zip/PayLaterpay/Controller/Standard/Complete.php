<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Controller\Standard;

use Exception;
use Magento\Customer\Api\Data\GroupInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order\Payment\Transaction;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

/**
 * Class Complete
 * @package PayLater\PayLaterpay\Controller\Standard
 */
class Complete extends SpotiiPay
{
    /**
     * Complete the transaction
     */
    public function execute()
    {
        try {
            //            xdebug_break();
            // Create order before redirect to success
            $quote = $this->checkoutSession->getQuote();

            // First verify the payment status from PayLater
            $payment = $quote->getPayment();
            $reference = $payment->getAdditionalInformation('ppaylater_order_id');

            // Verify payment status first
            $spotiiOrderInfo = $this->spotiipayModel->getSpotiiOrderInfo($reference);

            $this->spotiiHelper->logSpotiiActions("OrderInfo : " . json_encode($spotiiOrderInfo));

            /*
                Only proceed if payment is successful
                Status 1 is pending
                Status 2 is successful
                Status 3 is failed
            */

            if (!isset($spotiiOrderInfo['status']) || $spotiiOrderInfo['status'] !== 2) {
                throw new LocalizedException(
                    __('Payment was not successful. Please try again.')
                );
            }

            $quoteId = $quote->getId();
            $quote->collectTotals()->save();

            $this->spotiiHelper->logSpotiiActions("Quote Customer Email: " . $quote->getCustomerEmail());
            $this->spotiiHelper->logSpotiiActions("Is Guest: " . ($quote->getCustomerIsGuest() ? 'Yes' : 'No'));
            $this->spotiiHelper->logSpotiiActions("Customer ID: " . $quote->getCustomerId());

            if (!$this->customerSession->isLoggedIn()) {
                $this->spotiiHelper->logSpotiiActions("=== Processing Guest User ===");
                $shippingAddress = $quote->getShippingAddress();
                if ($shippingAddress && $shippingAddress->getEmail()) {
                    $addressData = [
                        'name' => $shippingAddress->getName(),
                        'email' => $shippingAddress->getEmail(),
                        'street' => implode(', ', $shippingAddress->getStreet()),
                        'city' => $shippingAddress->getCity(),
                        'postcode' => $shippingAddress->getPostcode(),
                        'country' => $shippingAddress->getCountryId()
                    ];
                    $this->spotiiHelper->logSpotiiActions("Shipping address: " . json_encode($addressData));
                    $quote->setCustomerEmail($shippingAddress->getEmail())
                        ->setCustomerIsGuest(true)
                        ->setCustomerGroupId(GroupInterface::NOT_LOGGED_IN_ID);
                }
            }

            // Submit quote to create order
            try {
                $order = $this->quoteManagement->submit($quote);
            } catch (LocalizedException $e) {
                if (strpos($e->getMessage(), 'Email has a wrong format') !== false) {
                    $quote->setCustomerEmail($quote->getCustomerEmail());
                    $order = $this->quoteManagement->submit($quote);
                } else {
                    throw $e;
                }
            }

            $payment = $quote->getPayment();
            $payment->setMethod('ppaylater');
            $payment->save();
            $quote->reserveOrderId();
            $quote->setPayment($payment);
            $quote->save();

            $this->checkoutSession->replaceQuote($quote);
            $reference = $payment->getAdditionalInformation('ppaylater_order_id');

            $this->spotiipayModel->createTransaction(
                $order,
                $reference,
                Transaction::TYPE_ORDER
            );

            $order->save();

            // Set all necessary session data
            $this->checkoutSession->setLastQuoteId($quoteId);
            $this->checkoutSession->setLastSuccessQuoteId($quoteId);
            $this->checkoutSession->setLastOrderId($order->getEntityId());
            $this->checkoutSession->setLastRealOrderId($order->getIncrementId());

            $this->messageManager->addSuccessMessage(`<b>Success! Payment completed!</b><br>Thank you for your payment, your order with PayLater has been placed.`);

            // Single redirect to success page
            return $this->_redirect('checkout/onepage/success');

        } catch (LocalizedException $e) {
            $this->spotiiHelper->logSpotiiActions("Transaction Exception: " . $e->getMessage());
            $this->messageManager->addErrorMessage($e->getMessage());
            return $this->_redirect('checkout/cart');
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Transaction Exception: " . $e->getMessage());
            $this->messageManager->addErrorMessage("An error occurred while processing your payment. Please try again.");
            return $this->_redirect('checkout/cart');
        }
    }
}
