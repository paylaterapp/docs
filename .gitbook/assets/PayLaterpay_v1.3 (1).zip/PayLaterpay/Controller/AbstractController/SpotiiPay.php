<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Controller\AbstractController;

use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Checkout\Model\Session;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\DB\TransactionFactory;
use Magento\Framework\Json\Helper\Data;
use Magento\Quote\Model\QuoteManagement;
use Magento\Sales\Model\Order\Config;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\Order\InvoiceRepository;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;
use Magento\Sales\Model\Order\Status\HistoryFactory;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\Service\InvoiceService;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Psr\Log\LoggerInterface;

/**
 * Class PayLaterpay
 * @package PayLater\PayLaterpay\Controller\AbstractController
 */
abstract class SpotiiPay extends Action
{

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var OrderFactory
     */
    protected $orderFactory;

    /**
     * @var HistoryFactory
     */
    protected $orderHistoryFactory;

    /**
     * @var \PayLater\PayLaterpay\Model\SpotiiPay
     */
    protected $spotiipayModel;

    /**
     * @var Config
     */
    protected $salesOrderConfig;

    /**
     * @var InvoiceService
     */
    protected $invoiceService;

    /**
     * @var TransactionFactory
     */
    protected $transactionFactory;

    /**
     * @var OrderSender
     */
    protected $orderSender;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Data
     */
    protected $jsonHelper;

    /**
     * @var QuoteManagement
     */
    protected $quoteManagement;

    /**
     * @var BuilderInterface
     */
    protected $transactionBuilder;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * @var \PayLater\PayLaterpay\Helper\Data
     */
    protected $spotiiHelper;

    /**
     * @var SpotiiApiConfigInterface
     */
    protected $spotiiApiIdentity;

    /**
     * @var StockRegistryInterface
     */
    protected $stockRegistry;

    /**
     * @var InvoiceRepository
     */
    protected $invoiceRepository;

    /**
     * PayLaterpay constructor.
     * @param Context $context
     * @param CustomerRepositoryInterface $customerRepository
     * @param \Magento\Customer\Model\Session $customerSession
     * @param Session $checkoutSession
     * @param OrderFactory $orderFactory
     * @param HistoryFactory $orderHistoryFactory
     * @param \PayLater\PayLaterpay\Model\SpotiiPay $spotiipayModel
     * @param \PayLater\PayLaterpay\Helper\Data $spotiiHelper
     * @param Config $salesOrderConfig
     * @param InvoiceService $invoiceService
     * @param LoggerInterface $logger
     * @param JsonFactory $resultJsonFactory
     * @param TransactionFactory $transactionFactory
     * @param Data $jsonHelper
     * @param QuoteManagement $quoteManagement
     * @param BuilderInterface $transactionBuilder
     * @param OrderSender $orderSender
     * @param SpotiiApiConfigInterface $spotiiApiIdentity
     * @param StockRegistryInterface $stockRegistry
     * @param InvoiceRepository $invoiceRepository
     */
    public function __construct(
        Context $context,
        CustomerRepositoryInterface          $customerRepository,
        \Magento\Customer\Model\Session      $customerSession,
        Session                              $checkoutSession,
        OrderFactory                         $orderFactory,
        HistoryFactory                       $orderHistoryFactory,
        \PayLater\PayLaterpay\Model\SpotiiPay $spotiipayModel,
        \PayLater\PayLaterpay\Helper\Data     $spotiiHelper,
        Config                               $salesOrderConfig,
        InvoiceService                       $invoiceService,
        LoggerInterface                      $logger,
        JsonFactory                          $resultJsonFactory,
        TransactionFactory                   $transactionFactory,
        Data                                 $jsonHelper,
        QuoteManagement                      $quoteManagement,
        BuilderInterface                     $transactionBuilder,
        OrderSender                          $orderSender,
        SpotiiApiConfigInterface             $spotiiApiIdentity,
        StockRegistryInterface               $stockRegistry,
        InvoiceRepository                    $invoiceRepository
    ) {
        $this->customerSession = $customerSession;
        $this->spotiiHelper = $spotiiHelper;
        $this->customerRepository = $customerRepository;
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->orderHistoryFactory = $orderHistoryFactory;
        $this->spotiipayModel = $spotiipayModel;
        $this->salesOrderConfig = $salesOrderConfig;
        $this->invoiceService = $invoiceService;
        $this->transactionFactory = $transactionFactory;
        $this->logger = $logger;
        $this->jsonHelper = $jsonHelper;
        $this->quoteManagement = $quoteManagement;
        $this->transactionBuilder = $transactionBuilder;
        $this->orderSender = $orderSender;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->spotiiApiIdentity = $spotiiApiIdentity;
        $this->stockRegistry = $stockRegistry;
        $this->invoiceRepository = $invoiceRepository;
        parent::__construct($context);
    }

    public function canRefund()
    {
        return true;
    }

    /**
     * @return mixed
     */
    protected function getOrder()
    {
        return $this->orderFactory->create()->loadByIncrementId(
            $this->checkoutSession->getLastRealOrderId()
        );
    }
}
