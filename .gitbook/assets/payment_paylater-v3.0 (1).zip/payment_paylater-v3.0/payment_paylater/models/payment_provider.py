import logging
from datetime import timedelta

import requests

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools.translate import _

_logger = logging.getLogger(__name__)

PAYLATER_URLS = {
    'uat': 'https://connect.uat.paylaterapp.com',
    'live': 'https://connect.paylaterapp.com',
}

TOKEN_PATH = '/auth/realms/api/protocol/openid-connect/token'
TOKEN_REFRESH_LEEWAY = 60


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('paylater', 'PayLater')],
        ondelete={'paylater': 'set default'},
    )

    paylater_environment = fields.Selection(
        string="Environment",
        selection=[('uat', 'UAT (Testing)'), ('live', 'Live (Production)')],
        default='uat',
        required_if_provider='paylater',
    )
    paylater_client_id = fields.Char(
        string="Client ID",
        required_if_provider='paylater',
        groups='base.group_system',
        help="OAuth2 client_id provided by PayLater (e.g. merchant-815).",
    )
    paylater_client_secret = fields.Char(
        string="Client Secret",
        required_if_provider='paylater',
        groups='base.group_system',
        help="OAuth2 client_secret provided by PayLater.",
    )
    paylater_outlet_id = fields.Integer(
        string="Outlet ID",
        required_if_provider='paylater',
        groups='base.group_system',
    )
    paylater_webhook_secret = fields.Char(
        string="Webhook Secret",
        groups='base.group_system',
        help="The secret PayLater provides for your webhook endpoint, used to verify HMAC SHA-256 signatures.",
    )
    paylater_minimum_amount = fields.Float(
        string="Minimum Order Amount",
        default=300.0,
        help="Minimum order amount required to offer PayLater at checkout. Orders below this amount will not see PayLater as a payment option.",
    )
    # Token cache — auto-managed, hidden from UI.
    paylater_access_token = fields.Char(groups='base.group_system')
    paylater_token_expiry = fields.Datetime(groups='base.group_system')
    paylater_refresh_token = fields.Char(groups='base.group_system')
    paylater_refresh_token_expiry = fields.Datetime(groups='base.group_system')

    def _paylater_get_api_url(self):
        self.ensure_one()
        return PAYLATER_URLS.get(self.paylater_environment, PAYLATER_URLS['uat'])

    # ------------------------------------------------------------------
    # OAuth2 token lifecycle
    # ------------------------------------------------------------------
    def _paylater_get_access_token(self, force_refresh=False):
        """Return a valid OAuth2 access token.

        Flow:
          1. If cached access_token still valid → reuse it.
          2. Else if refresh_token still valid → request new access_token via refresh_token grant.
          3. Else (or refresh fails) → full client_credentials grant.
        """
        self.ensure_one()
        provider = self.sudo()
        now = fields.Datetime.now()

        if (
            not force_refresh
            and provider.paylater_access_token
            and provider.paylater_token_expiry
            and provider.paylater_token_expiry > now
        ):
            return provider.paylater_access_token

        if (
            provider.paylater_refresh_token
            and provider.paylater_refresh_token_expiry
            and provider.paylater_refresh_token_expiry > now
        ):
            try:
                return provider._paylater_token_request({
                    'grant_type': 'refresh_token',
                    'client_id': provider.paylater_client_id or '',
                    'client_secret': provider.paylater_client_secret or '',
                    'refresh_token': provider.paylater_refresh_token,
                }, grant_label='refresh_token')
            except UserError as e:
                _logger.warning("PayLater: refresh_token grant failed (%s) — falling back to client_credentials", e)

        return provider._paylater_token_request({
            'grant_type': 'client_credentials',
            'client_id': provider.paylater_client_id or '',
            'client_secret': provider.paylater_client_secret or '',
        }, grant_label='client_credentials')

    def _paylater_token_request(self, form_data, grant_label):
        """POST the token endpoint, store the resulting tokens, return access_token."""
        self.ensure_one()
        api_base = self._paylater_get_api_url()
        url = f'{api_base}{TOKEN_PATH}'

        _logger.info("PayLater: Token request — grant=%s", grant_label)
        try:
            response = requests.post(
                url,
                data=form_data,
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=30,
            )
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Token request error (%s): %s", grant_label, e)
            raise UserError(_("Could not reach PayLater to authenticate: %s", e))

        if response.status_code != 200:
            _logger.error(
                "PayLater: Token endpoint returned %s for grant=%s: %s",
                response.status_code, grant_label, response.text,
            )
            try:
                err = response.json()
                raise UserError(_(
                    "PayLater authentication failed (%s): %s — %s",
                    grant_label,
                    err.get('error', 'unknown'),
                    err.get('error_description', ''),
                ))
            except ValueError:
                raise UserError(_(
                    "PayLater authentication failed (%s, HTTP %s).",
                    grant_label, response.status_code,
                ))

        data = response.json()
        access_token = data.get('access_token')
        if not access_token:
            raise UserError(_("PayLater did not return an access token."))

        expires_in = int(data.get('expires_in') or 3600)
        refresh_expires_in = int(data.get('refresh_expires_in') or 0)
        refresh_token = data.get('refresh_token') or False

        now = fields.Datetime.now()
        vals = {
            'paylater_access_token': access_token,
            'paylater_token_expiry': now + timedelta(seconds=max(60, expires_in - TOKEN_REFRESH_LEEWAY)),
        }
        if refresh_token:
            vals['paylater_refresh_token'] = refresh_token
            if refresh_expires_in <= 0:
                refresh_expires_in = 30 * 24 * 3600
            vals['paylater_refresh_token_expiry'] = now + timedelta(
                seconds=max(60, refresh_expires_in - TOKEN_REFRESH_LEEWAY)
            )

        self.write(vals)

        _logger.info(
            "PayLater: Token obtained via %s — access expires in %ss, refresh expires in %ss",
            grant_label, expires_in, refresh_expires_in,
        )
        return access_token

    def _paylater_auth_headers(self):
        """Build the Bearer auth header for PayLater API calls."""
        return {
            'Authorization': f'Bearer {self._paylater_get_access_token()}',
            'Content-Type': 'application/json',
        }

    # ------------------------------------------------------------------
    # Standard payment.provider overrides
    # ------------------------------------------------------------------
    def _get_default_payment_method_codes(self):
        self.ensure_one()
        if self.code != 'paylater':
            return super()._get_default_payment_method_codes()
        return {'paylater'}

    def _compute_feature_support_fields(self):
        super()._compute_feature_support_fields()
        self.filtered(lambda p: p.code == 'paylater').update({
            'support_refund': 'partial',
        })

    @api.model
    def _get_compatible_providers(self, company_id, partner_id, amount, **kwargs):
        providers = super()._get_compatible_providers(
            company_id, partner_id, amount, **kwargs
        )
        providers = providers.filtered(
            lambda p: p.code != 'paylater'
            or not p.paylater_minimum_amount
            or amount >= p.paylater_minimum_amount
        )
        return providers
