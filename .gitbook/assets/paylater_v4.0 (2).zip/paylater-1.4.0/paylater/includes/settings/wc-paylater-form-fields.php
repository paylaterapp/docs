<?php
/**
 * PayLater Pro - Native Styled Form Fields
 */

function paylater_form_fields($th, $section = '') {
    switch ($section) {
        case 'api':
            $webhook_url = esc_url( home_url( '/?wc-api=paylater_webhook' ) );

            $th->form_fields = array(
                'api_section_start' => array(
                    'title'       => __( 'API Credentials', 'paylater' ),
                    'type'        => 'title',
                    'description' => __( 'PayLater uses OAuth2 client credentials. Paste the Client ID and Client Secret issued to your merchant account for each environment.', 'paylater' ),
                ),
                'testMode' => array(
                    'title'   => __( 'Test Mode', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Enable Test Mode', 'paylater' ),
                    'default' => 'yes',
                ),
                'testClientId' => array(
                    'title'       => __( 'Test Client ID', 'paylater' ),
                    'type'        => 'text',
                    'placeholder' => 'merchant-XXX',
                    'description' => __( 'Client ID issued for the UAT environment.', 'paylater' ),
                ),
                'testClientSecret' => array(
                    'title'       => __( 'Test Client Secret', 'paylater' ),
                    'type'        => 'password',
                    'placeholder' => '••••••••••••••••',
                    'description' => __( 'Client secret issued for the UAT environment.', 'paylater' ),
                ),
                'clientId' => array(
                    'title'       => __( 'Live Client ID', 'paylater' ),
                    'type'        => 'text',
                    'placeholder' => 'merchant-XXX',
                    'description' => __( 'Client ID issued for the production environment.', 'paylater' ),
                ),
                'clientSecret' => array(
                    'title'       => __( 'Live Client Secret', 'paylater' ),
                    'type'        => 'password',
                    'placeholder' => '••••••••••••••••',
                    'description' => __( 'Client secret issued for the production environment.', 'paylater' ),
                ),
                'outletId' => array(
                    'title'       => __( 'Outlet ID', 'paylater' ),
                    'type'        => 'text',
                    'description' => __( 'Your unique PayLater Outlet Identifier.', 'paylater' ),
                ),
                'paymentExpiryMinutes' => array(
                    'title'             => __( 'Payment Link Expiry (minutes)', 'paylater' ),
                    'type'              => 'number',
                    'default'           => '10',
                    'description'       => __( 'How long a shopper has to complete the redirect-checkout flow before the link expires.', 'paylater' ),
                    'custom_attributes' => array(
                        'min'  => '1',
                        'step' => '1',
                    ),
                ),
                'webhook_section' => array(
                    'title'       => __( 'Webhook', 'paylater' ),
                    'type'        => 'title',
                    'description' => sprintf(
                        /* translators: %s: webhook callback URL */
                        __( 'Share this URL with PayLater Operations so they can configure outgoing notifications: <code>%s</code>. PayLater will issue you a webhook secret per environment; paste them below.', 'paylater' ),
                        $webhook_url
                    ),
                ),
                'testWebhookSecret' => array(
                    'title'       => __( 'Test Webhook Secret', 'paylater' ),
                    'type'        => 'password',
                    'placeholder' => '••••••••••••••••',
                    'description' => __( 'Secret used to validate webhook signatures while Test Mode is enabled.', 'paylater' ),
                ),
                'webhookSecret' => array(
                    'title'       => __( 'Live Webhook Secret', 'paylater' ),
                    'type'        => 'password',
                    'placeholder' => '••••••••••••••••',
                    'description' => __( 'Secret used to validate webhook signatures in production.', 'paylater' ),
                ),
            );
            break;

        case 'display':
            $th->form_fields = array(
                'display_section_start' => array(
                    'title'       => __( 'Widget Customization', 'paylater' ),
                    'type'        => 'title',
                    'description' => __( 'Configure messages for Product List (PLP) and Product Details (PDP).', 'paylater' ),
                ),
                // PDP WIDGET SETTINGS
                'show_pdp_widget' => array(
                    'title'   => __( 'Enable PDP Widget', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Display full widget on single product pages', 'paylater' ),
                    'default' => 'yes',
                ),
                'pdp_main_message' => array(
                    'title'       => __( 'PDP Main Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Pay with PayLater', 'paylater' ),
                    'description' => __( 'Main heading for the details page widget.', 'paylater' ),
                ),
                'pdp_sub_message' => array(
                    'title'       => __( 'PDP Sub Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Interest-free', 'paylater' ),
                    'description' => __( 'Supporting text for the details page widget.', 'paylater' ),
                ),
                // PLP WIDGET SETTINGS
                'show_plp_widget' => array(
                    'title'   => __( 'Enable PLP Widget', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Display summary bar on shop and list pages', 'paylater' ),
                    'default' => 'yes',
                ),
                'plp_main_message' => array(
                    'title'       => __( 'PLP Main Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Pay with PayLater', 'paylater' ),
                    'description' => __( 'Main heading for the list page bar.', 'paylater' ),
                ),
                'plp_sub_message' => array(
                    'title'       => __( 'PLP Sub Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Interest-free', 'paylater' ),
                    'description' => __( 'Supporting text for the list page bar.', 'paylater' ),
                ),
            );
            break;

        default: // General settings
            $th->form_fields = array(
                'main_section_start' => array(
                    'title'       => __( 'Enable and customise', 'paylater' ),
                    'type'        => 'title',
                    'description' => __( 'Configure the core settings for the PayLater Pro gateway.', 'paylater' ),
                ),
                'enabled' => array(
                    'title'   => __( 'Enable PayLater', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Enable PayLater Pro gateway', 'paylater' ),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __( 'TITLE', 'paylater' ),
                    'type'        => 'text',
                    'description' => __( 'Payment method name that the customer will see during checkout.', 'paylater' ),
                    'default'     => __( 'PayLater', 'paylater' ),
                ),
                'description' => array(
                    'title'       => __( 'DESCRIPTION', 'paylater' ),
                    'type'        => 'textarea',
                    'description' => __( 'Payment method description that the customer will see during checkout.', 'paylater' ),
                    'default'     => __( 'Buy now and pay later with interest-free installments.', 'paylater' ),
                    'css'         => 'width: 100%; max-width: 600px;',
                ),
                'order_min' => array(
                    'title'       => __( 'ORDER MINIMUM', 'paylater' ),
                    'type'        => 'number',
                    'description' => __( 'The minimum cart total required to show this gateway. PayLater enforces a 300 QAR minimum on the gateway side, so this cannot be set lower.', 'paylater' ),
                    'default'     => '300',
                    'custom_attributes' => array(
                        'min'  => '300',
                        'step' => '1',
                    ),
                ),
            );
            break;
    }
}