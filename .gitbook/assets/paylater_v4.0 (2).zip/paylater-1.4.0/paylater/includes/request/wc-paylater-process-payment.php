<?php
/**
 * PayLater Pro - Process Payment (v2)
 *
 */

defined( 'ABSPATH' ) || exit;

function processPaylaterPayment( $order_id, $th, $addon ) {
    $order = wc_get_order( $order_id );

    if ( ! $order ) {
        return array(
            'result'   => 'failure',
            'messages' => __( 'Invalid Order ID.', 'paylater' ),
        );
    }

    $currency = $order->get_currency();
    $total    = (float) $order->get_total();
    $min      = (float) $th->order_min;

    try {
        if ( $total < $min ) {
            throw new Exception( sprintf(
                __( 'The minimum order amount for PayLater is %1$s %2$s.', 'paylater' ),
                $min,
                $currency
            ) );
        }

        $unique_ref = $order_id . '_' . time();

        $payload = array(
            'outlet_id'            => is_numeric( $th->outletId ) ? (int) $th->outletId : (string) $th->outletId,
            'currency'             => $currency,
            'amount'               => $total,
            'order_id'             => $unique_ref,
            'success_redirect_url' => add_query_arg(
                array(
                    'wc-api'  => $addon,
                    'o'       => $order_id,
                    's'       => 's',
                    'orderId' => $unique_ref,
                ),
                home_url( '/' )
            ),
            'fail_redirect_url'    => add_query_arg(
                array(
                    'wc-api'  => $addon,
                    'o'       => $order_id,
                    's'       => 'f',
                    'orderId' => $unique_ref,
                ),
                home_url( '/' )
            ),
            'expiry_duration'      => (int) $th->paymentExpiryMinutes,
        );

        $order->update_meta_data( '_paylater_unique_ref', $unique_ref );
        $order->save();

        $response = paylater_post_with_bearer( $th, $th->api, $payload );

        if ( is_wp_error( $response ) ) {
            throw new Exception( $response->get_error_message() );
        }

        $status_code   = (int) wp_remote_retrieve_response_code( $response );
        $raw_body      = (string) wp_remote_retrieve_body( $response );
        $response_body = json_decode( $raw_body, true );

        $payment_link = '';
        if ( is_array( $response_body ) ) {
            if ( ! empty( $response_body['paymentLinkUrl'] ) ) {
                $payment_link = (string) $response_body['paymentLinkUrl'];
            } elseif ( ! empty( $response_body['payment_link_url'] ) ) {
                $payment_link = (string) $response_body['payment_link_url'];
            }
        }

        if ( $payment_link !== '' ) {
            $order->update_meta_data( '_paylater_link', $payment_link );
            $order->update_status( 'pending', __( 'Customer redirected to PayLater portal.', 'paylater' ) );
            $order->save();

            return array(
                'result'   => 'success',
                'redirect' => $payment_link,
            );
        }

        $error = '';
        if ( is_array( $response_body ) ) {
            if ( ! empty( $response_body['error'] ) ) {
                $error = (string) $response_body['error'];
            } elseif ( ! empty( $response_body['message'] ) ) {
                $error = (string) $response_body['message'];
            }
        }

        if ( $error !== '' ) {
            throw new Exception( sprintf(
                __( 'PayLater handshake rejected (HTTP %1$d): %2$s', 'paylater' ),
                $status_code,
                $error
            ) );
        }

        // Unrecognised response. Include status + body excerpt so the cause is visible.
        $excerpt = trim( preg_replace( '/\s+/', ' ', $raw_body ) );
        if ( strlen( $excerpt ) > 240 ) {
            $excerpt = substr( $excerpt, 0, 240 ) . '…';
        }
        if ( $excerpt === '' ) {
            $excerpt = '<empty body>';
        }

        throw new Exception( sprintf(
            __( 'PayLater handshake failed (HTTP %1$d). Endpoint: %2$s. Body: %3$s', 'paylater' ),
            $status_code,
            $th->api,
            $excerpt
        ) );

    } catch ( Exception $e ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'PayLater Exception: ' . $e->getMessage() );
        }

        wc_add_notice( $e->getMessage(), 'error' );

        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }
}

/**
 * Helper that POSTs a JSON body with a Bearer token
 */
function paylater_post_with_bearer( $th, $url, $payload ) {
    $token = paylater_get_access_token( $th );

    $args = array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ),
        'body'    => wp_json_encode( $payload ),
        'timeout' => 45,
    );

    $response = wp_remote_post( $url, $args );

    if ( ! is_wp_error( $response ) && (int) wp_remote_retrieve_response_code( $response ) === 401 ) {
        $token                            = paylater_get_access_token( $th, true );
        $args['headers']['Authorization'] = 'Bearer ' . $token;
        $response                         = wp_remote_post( $url, $args );
    }

    return $response;
}

/**
 * Helper that performs a GET with a Bearer token
 */
function paylater_get_with_bearer( $th, $url ) {
    $token = paylater_get_access_token( $th );

    $args = array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $token,
            'Accept'        => 'application/json',
        ),
        'timeout' => 30,
    );

    $response = wp_remote_get( $url, $args );

    if ( ! is_wp_error( $response ) && (int) wp_remote_retrieve_response_code( $response ) === 401 ) {
        $token                            = paylater_get_access_token( $th, true );
        $args['headers']['Authorization'] = 'Bearer ' . $token;
        $response                         = wp_remote_get( $url, $args );
    }

    return $response;
}
