<?php
/**
 * PayLater Pro - Refund Handler (v2)
 *
 */

defined( 'ABSPATH' ) || exit;

function processPaylaterRefund( $order_id, $th, $amount = null, $reason = '' ) {
    $order = wc_get_order( $order_id );

    try {
        if ( ! $order ) {
            throw new Exception( __( 'Order not found.', 'paylater' ) );
        }

        if ( $order->get_payment_method() !== $th->id ) {
            throw new Exception( __( 'Order was not paid through PayLater.', 'paylater' ) );
        }

        $merchant_ref = (string) $order->get_meta( '_paylater_unique_ref' );
        if ( $merchant_ref === '' ) {
            throw new Exception( __( 'Original transaction reference not found on this order.', 'paylater' ) );
        }

        $amount = (float) $amount;
        if ( $amount <= 0 ) {
            throw new Exception( __( 'Refund amount must be greater than zero.', 'paylater' ) );
        }

        $order_total  = (float) $order->get_total();
        $is_full      = abs( $amount - $order_total ) < 0.005;
        $reason_clean = $reason !== '' ? sanitize_text_field( $reason ) : __( 'Customer refund', 'paylater' );

        $payload = array( 'order_id' => $merchant_ref );
        if ( ! $is_full ) {
            $payload['amount'] = number_format( $amount, 2, '.', '' );
        }

        $refund_url = rtrim( $th->api, '/' ) . '/refund';
        $response   = paylater_post_with_bearer( $th, $refund_url, $payload );

        if ( is_wp_error( $response ) ) {
            throw new Exception( $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code >= 400 || ( is_array( $body ) && ! empty( $body['error'] ) ) ) {
            $error = '';
            if ( is_array( $body ) ) {
                if ( ! empty( $body['error'] ) && ! empty( $body['message'] ) ) {
                    $error = $body['error'] . ': ' . $body['message'];
                } elseif ( ! empty( $body['error'] ) ) {
                    $error = $body['error'];
                } elseif ( ! empty( $body['message'] ) ) {
                    $error = $body['message'];
                }
            }
            if ( $error === '' ) {
                $error = __( 'Gateway declined the refund request.', 'paylater' );
            }
            throw new Exception( $error );
        }

        $note_template = $is_full
            ? __( 'PayLater refund request accepted for %1$s. Final settlement will be confirmed via webhook. Reason: %2$s', 'paylater' )
            : __( 'PayLater partial refund request accepted for %1$s. Final settlement will be confirmed via webhook. Reason: %2$s', 'paylater' );

        $note = sprintf( $note_template, strip_tags( wc_price( $amount ) ), $reason_clean );

        if ( is_array( $body ) && ! empty( $body['message'] ) ) {
            $note .= ' [' . sanitize_text_field( $body['message'] ) . ']';
        }

        $order->add_order_note( $note );
        return true;

    } catch ( Exception $e ) {
        $error_msg = sprintf( __( 'PayLater Refund Error: %s', 'paylater' ), $e->getMessage() );
        if ( $order ) {
            $order->add_order_note( $error_msg );
        }
        return new WP_Error( 'refund_error', $error_msg );
    }
}
