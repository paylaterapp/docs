<?php
/**
 * PayLater Pro - Webhook Handler
 *
 */

defined( 'ABSPATH' ) || exit;

function paylater_webhook_send_response( $code, $message ) {
    status_header( $code );
    nocache_headers();
    wp_send_json( array( 'message' => $message ), $code );
    exit;
}

function paylaterWebhookHandler() {
    $raw     = file_get_contents( 'php://input' );
    $payload = json_decode( $raw, true );

    if ( ! is_array( $payload ) ) {
        paylater_webhook_send_response( 400, 'Invalid JSON' );
    }

    $required = array( 'merchantId', 'orderId', 'status', 'timestamp', 'signature', 'txHash' );
    foreach ( $required as $field ) {
        if ( ! isset( $payload[ $field ] ) || $payload[ $field ] === '' ) {
            paylater_webhook_send_response( 400, 'Missing field: ' . $field );
        }
    }

    $settings  = get_option( 'woocommerce_paylater_shop_now_pay_later_settings', array() );
    $test_mode = isset( $settings['testMode'] ) && $settings['testMode'] === 'yes';
    $secret    = $test_mode
        ? (string) ( isset( $settings['testWebhookSecret'] ) ? $settings['testWebhookSecret'] : '' )
        : (string) ( isset( $settings['webhookSecret'] ) ? $settings['webhookSecret'] : '' );

    if ( $secret === '' ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'PayLater webhook rejected: no secret configured for current mode.' );
        }
        paylater_webhook_send_response( 503, 'Webhook secret not configured' );
    }

    $comments = isset( $payload['comments'] ) ? (string) $payload['comments'] : '';

    $data_string = strtoupper(
        (string) $payload['merchantId']
        . (string) $payload['orderId']
        . (string) $payload['status']
        . (string) $payload['timestamp']
        . $comments
    );
    $computed_tx_hash = md5( $data_string );

    if ( ! hash_equals( $computed_tx_hash, (string) $payload['txHash'] ) ) {
        paylater_webhook_send_response( 403, 'Invalid txHash' );
    }

    $computed_signature = hash_hmac( 'sha256', $computed_tx_hash, $secret );
    if ( ! hash_equals( $computed_signature, (string) $payload['signature'] ) ) {
        paylater_webhook_send_response( 403, 'Invalid signature' );
    }

    $merchant_ref = (string) $payload['orderId'];

    $orders = wc_get_orders( array(
        'limit'      => 1,
        'meta_key'   => '_paylater_unique_ref',
        'meta_value' => $merchant_ref,
    ) );

    if ( empty( $orders ) ) {
        paylater_webhook_send_response( 200, 'Order not found, acknowledged' );
    }

    $order = $orders[0];

    if ( $order->get_payment_method() !== 'paylater_shop_now_pay_later' ) {
        paylater_webhook_send_response( 200, 'Not a PayLater order, acknowledged' );
    }

    $status       = strtolower( (string) $payload['status'] );
    $paylater_ref = isset( $payload['paylaterRef'] ) ? (string) $payload['paylaterRef'] : '';
    $note_suffix  = $comments !== '' ? ' Notes: ' . sanitize_text_field( $comments ) : '';

    if ( $status === 'success' ) {
        if ( $order->has_status( array( 'processing', 'completed', 'refunded', 'cancelled' ) ) ) {
            $order->add_order_note( sprintf(
                __( 'PayLater webhook: success received for order already in %1$s state. Ref: %2$s.%3$s', 'paylater' ),
                $order->get_status(),
                $paylater_ref,
                $note_suffix
            ) );
            paylater_webhook_send_response( 200, 'Already processed' );
        }

        if ( $paylater_ref !== '' ) {
            $order->update_meta_data( '_paylater_order_id', $paylater_ref );
            $order->save();
        }

        $order->payment_complete( $paylater_ref !== '' ? $paylater_ref : $merchant_ref );
        $order->add_order_note( sprintf(
            __( 'PayLater webhook: payment confirmed. Ref: %1$s.%2$s', 'paylater' ),
            $paylater_ref,
            $note_suffix
        ) );

        paylater_webhook_send_response( 200, 'Webhook received successfully' );
    }

    if ( $status === 'failed' ) {
        if ( $order->has_status( array( 'processing', 'completed' ) ) ) {
            $order->add_order_note( sprintf(
                __( 'PayLater webhook: failed status received against a paid order (possible refund failure). Ref: %1$s.%2$s', 'paylater' ),
                $paylater_ref,
                $note_suffix
            ) );
        } elseif ( ! $order->has_status( array( 'failed', 'cancelled' ) ) ) {
            $order->update_status( 'failed', sprintf(
                __( 'PayLater webhook: payment failed. Ref: %1$s.%2$s', 'paylater' ),
                $paylater_ref,
                $note_suffix
            ) );
        }

        paylater_webhook_send_response( 200, 'Webhook received successfully' );
    }

    if ( $status === 'pending' ) {
        $order->add_order_note( sprintf(
            __( 'PayLater webhook: pending. Ref: %1$s.%2$s', 'paylater' ),
            $paylater_ref,
            $note_suffix
        ) );
        paylater_webhook_send_response( 200, 'Webhook received successfully' );
    }

    $order->add_order_note( sprintf(
        __( 'PayLater webhook: unrecognised status "%1$s". Ref: %2$s.%3$s', 'paylater' ),
        $status,
        $paylater_ref,
        $note_suffix
    ) );
    paylater_webhook_send_response( 200, 'Webhook received successfully' );
}
