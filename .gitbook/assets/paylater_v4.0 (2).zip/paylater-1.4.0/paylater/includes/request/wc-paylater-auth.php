<?php

defined( 'ABSPATH' ) || exit;

function paylater_token_endpoint( $test_mode ) {
    return $test_mode
        ? 'https://connect.uat.paylaterapp.com/auth/realms/api/protocol/openid-connect/token'
        : 'https://connect.paylaterapp.com/auth/realms/api/protocol/openid-connect/token';
}

function paylater_token_transient_key( $test_mode ) {
    return $test_mode ? 'paylater_token_test' : 'paylater_token_live';
}

/**
 * Returns a Bearer access token.
 *
 * @param object $th             Gateway instance (provides clientId, clientSecret, testMode).
 * @param bool   $force_refresh  Skip the cached access_token check (still tries refresh first).
 * @throws Exception when credentials are missing or both grants fail.
 */
function paylater_get_access_token( $th, $force_refresh = false ) {
    $test_mode = ! empty( $th->testMode );
    $cache_key = paylater_token_transient_key( $test_mode );
    $now       = time();

    $cached = get_transient( $cache_key );
    if ( ! is_array( $cached ) ) {
        $cached = null;
    }

    if ( ! $force_refresh
         && $cached
         && ! empty( $cached['access_token'] )
         && $now < ( (int) ( $cached['access_expires_at'] ?? 0 ) - 60 ) ) {
        return (string) $cached['access_token'];
    }

    if ( $cached
         && ! empty( $cached['refresh_token'] )
         && $now < ( (int) ( $cached['refresh_expires_at'] ?? 0 ) - 60 ) ) {
        try {
            $token_data = paylater_fetch_token_via_refresh( $th, (string) $cached['refresh_token'] );
            paylater_store_token( $cache_key, $token_data, $now, $cached );
            return (string) $token_data['access_token'];
        } catch ( Exception $e ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( 'PayLater refresh_token grant failed, falling back to client_credentials: ' . $e->getMessage() );
            }
        }
    }

    $token_data = paylater_fetch_token_via_client_credentials( $th );
    paylater_store_token( $cache_key, $token_data, $now );
    return (string) $token_data['access_token'];
}

/**
 * Drop the cached token entirely. Forces a full re-auth on the next call.
 * Used when admins save new credentials.
 */
function paylater_invalidate_token( $th ) {
    $test_mode = ! empty( $th->testMode );
    delete_transient( paylater_token_transient_key( $test_mode ) );
}

/**
 * Exchanges client_id + client_secret for a fresh token pair.
 */
function paylater_fetch_token_via_client_credentials( $th ) {
    $client_id     = isset( $th->clientId ) ? trim( (string) $th->clientId ) : '';
    $client_secret = isset( $th->clientSecret ) ? trim( (string) $th->clientSecret ) : '';

    if ( $client_id === '' || $client_secret === '' ) {
        throw new Exception( __( 'PayLater client ID or client secret is not configured.', 'paylater' ) );
    }

    return paylater_request_token( $th, array(
        'grant_type'    => 'client_credentials',
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
    ) );
}

/**
 * Exchanges an existing refresh_token for a fresh access_token
 */
function paylater_fetch_token_via_refresh( $th, $refresh_token ) {
    $client_id     = isset( $th->clientId ) ? trim( (string) $th->clientId ) : '';
    $client_secret = isset( $th->clientSecret ) ? trim( (string) $th->clientSecret ) : '';

    if ( $client_id === '' || $client_secret === '' ) {
        throw new Exception( __( 'PayLater client ID or client secret is not configured.', 'paylater' ) );
    }

    return paylater_request_token( $th, array(
        'grant_type'    => 'refresh_token',
        'client_id'     => $client_id,
        'client_secret' => $client_secret,
        'refresh_token' => (string) $refresh_token,
    ) );
}

/**
 * Internal: POST to the token endpoint and parse the response.
 *
 * @throws Exception on transport failure, non-200, or malformed payload.
 */
function paylater_request_token( $th, array $body ) {
    $test_mode = ! empty( $th->testMode );

    $response = wp_remote_post( paylater_token_endpoint( $test_mode ), array(
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept'       => 'application/json',
        ),
        'body'    => $body,
        'timeout' => 30,
    ) );

    if ( is_wp_error( $response ) ) {
        throw new Exception( $response->get_error_message() );
    }

    $status_code = (int) wp_remote_retrieve_response_code( $response );
    $raw_body    = (string) wp_remote_retrieve_body( $response );
    $decoded     = json_decode( $raw_body, true );

    if ( is_array( $decoded ) && ! empty( $decoded['access_token'] ) ) {
        return $decoded;
    }

    $error = '';
    if ( is_array( $decoded ) ) {
        if ( ! empty( $decoded['error_description'] ) ) {
            $error = (string) $decoded['error_description'];
        } elseif ( ! empty( $decoded['error'] ) ) {
            $error = (string) $decoded['error'];
        }
    }

    if ( $error !== '' ) {
        throw new Exception( sprintf( __( 'PayLater auth failed: %s', 'paylater' ), $error ) );
    }

    $excerpt = trim( preg_replace( '/\s+/', ' ', $raw_body ) );
    if ( strlen( $excerpt ) > 240 ) {
        $excerpt = substr( $excerpt, 0, 240 ) . '…';
    }
    if ( $excerpt === '' ) {
        $excerpt = '<empty body>';
    }

    throw new Exception( sprintf(
        __( 'PayLater auth failed: no access token in response (HTTP %1$d). Endpoint: %2$s. Body: %3$s', 'paylater' ),
        $status_code,
        paylater_token_endpoint( ! empty( $th->testMode ) ),
        $excerpt
    ) );
}

/**
 * Persist a token response to the transient cache. Computes absolute expiry
 * timestamps so the get_access_token() check is a simple integer compare.
 *
 * @param string     $cache_key  Transient key for the current environment.
 * @param array      $data       Decoded token endpoint response.
 * @param int        $now        Wall-clock time at the start of the grant call.
 * @param array|null $previous   Existing cache contents, used to preserve a
 *                               refresh_token if the server didn't rotate it.
 */
function paylater_store_token( $cache_key, array $data, $now, $previous = null ) {
    $access_lifetime  = isset( $data['expires_in'] ) ? (int) $data['expires_in'] : 3600;
    $refresh_lifetime = isset( $data['refresh_expires_in'] ) ? (int) $data['refresh_expires_in'] : 0;

    if ( $refresh_lifetime <= 0 ) {
        $refresh_lifetime = 30 * DAY_IN_SECONDS;
    }

    $refresh_token = isset( $data['refresh_token'] ) ? (string) $data['refresh_token'] : '';
    if ( $refresh_token === '' && $previous && ! empty( $previous['refresh_token'] ) ) {
        $refresh_token = (string) $previous['refresh_token'];
    }

    $cache = array(
        'access_token'       => (string) $data['access_token'],
        'access_expires_at'  => $now + max( 60, $access_lifetime ),
        'refresh_token'      => $refresh_token,
        'refresh_expires_at' => $refresh_token !== '' ? ( $now + $refresh_lifetime ) : 0,
    );

    $ttl = max( 60, $cache['refresh_expires_at'] - $now, $cache['access_expires_at'] - $now );
    set_transient( $cache_key, $cache, $ttl );
}
