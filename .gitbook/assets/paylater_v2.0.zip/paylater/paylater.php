<?php
/**
 * Plugin Name: PayLater Pro
 * Plugin URI: https://paylaterapp.com/
 * Description: A Professional Paylater payment platform for WooCommerce with Product Widgets and Advanced Configuration.
 * Version: 1.1.0
 * Author: PayLater
 * Author URI: https://paylaterapp.com
 * Text Domain: paylater
 * @package PayLater
 */

defined( 'ABSPATH' ) || exit;

/**
 * 1. Declare Compatibility (HPOS & Blocks)
 */
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
});

/**
 * 2. Register the Gateway
 */
add_filter('woocommerce_payment_gateways', function ($gateways){
    $gateways[] = 'WC_PayLater_Gateway_Shop_Now_Pay_Later';
    return $gateways;
});

/**
 * 3. Load Dependencies
 */
add_action('plugins_loaded', function (){
    if (!class_exists('WC_Payment_Gateway')) return;

    if (!defined('WC_PAYLATER_DIR_PATH')) {
        define( 'WC_PAYLATER_DIR_PATH', plugin_dir_path( __FILE__ ) );
    }

    // Load Core logic
    require_once WC_PAYLATER_DIR_PATH . 'includes/settings/wc-paylater-gateway-parameters.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/settings/wc-paylater-form-fields.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/request/wc-paylater-process-payment.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/request/wc-paylater-response-handler.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/request/wc-paylater-refund.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/gateways/class-wc-shop-now-pay-later.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/wc-paylater-gateway-blocks-support.php';
    require_once WC_PAYLATER_DIR_PATH . 'includes/class-wc-paylater-pro-display.php';
});

/**
 * 4. Register Blocks Support
 */
add_action( 'woocommerce_blocks_loaded', function() {
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }
    add_action('woocommerce_blocks_payment_method_type_registration', function( $payment_method_registry ) {
        $payment_method_registry->register( new WC_Paylater_Gateway_Blocks_Support() );
    });
});

/**
 * 5. Admin Navigation Sections
 * Fixed: Updated section ID to 'paylater_shop_now_pay_later' to match the gateway class
 */
add_action( 'woocommerce_sections_paylater_shop_now_pay_later', 'paylater_admin_sections' );
function paylater_admin_sections() {
    $current_section = isset( $_GET['sub-section'] ) ? sanitize_text_field( $_GET['sub-section'] ) : '';
    $sections = array(
        ''        => __( 'General', 'paylater' ),
        'api'     => __( 'API Configuration', 'paylater' ),
        'display' => __( 'Widget Settings', 'paylater' ),
    );

    echo '<ul class="subsubsub" style="margin-bottom: 20px;">';
    foreach ( $sections as $id => $label ) {
        // Corrected section URL parameter
        $url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=paylater_shop_now_pay_later&sub-section=' . $id );
        $class = ( $current_section === $id ) ? 'current' : '';
        echo '<li><a href="' . esc_url( $url ) . '" class="' . $class . '">' . esc_html( $label ) . '</a>' . ( end($sections) === $label ? '' : ' | ' ) . '</li>';
    }
    echo '</ul><br class="clear" />';
}

/**
 * 6. Enqueue Frontend Assets
 */
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'paylater-pro-checkout-css',
        plugins_url( 'assets/css/paylater-checkout.css', __FILE__ ),
        array(),
        '1.1.0'
    );

    // Lightbox is needed for iframe redirects
    wp_enqueue_script(
        'paylater-pro-lightbox-js',
        plugins_url( 'assets/js/paylater-iframe-lightbox.js', __FILE__ ),
        array(),
        '1.1.0',
        true
    );
});

add_action('admin_head', function() {
    ?>
    <style>
        #paylater_shop_now_pay_later .woocommerce-list__item-image,
        .settings-payment-gateways__list tr[data-gateway_id="paylater_shop_now_pay_later"] .woocommerce-list__item-image {
            width: 100% !important;
            max-width: 200px !important;
        }
    </style>
    <?php
});