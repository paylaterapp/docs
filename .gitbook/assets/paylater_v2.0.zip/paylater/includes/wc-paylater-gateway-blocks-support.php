<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

defined( 'ABSPATH' ) || exit;

class WC_Paylater_Gateway_Blocks_Support extends AbstractPaymentMethodType {

    private $gateway;

    // The name must match exactly the ID used in your JS registration
    protected $name = 'paylater_shop_now_pay_later';

    public function initialize() {
        // Fetch the full options array directly from the DB
        $this->settings = get_option( 'woocommerce_paylater_shop_now_pay_later_settings', [] );
        $this->gateway  = new WC_PayLater_Gateway_Shop_Now_Pay_Later();
    }

    public function is_active() {
        // Only show if the gateway is enabled in WooCommerce settings
        return !empty($this->settings['enabled']) && 'yes' === $this->settings['enabled'];
    }

    public function get_payment_method_script_handles() {
        $handle = 'paylater-pro-blocks-integration';

        wp_register_script(
            $handle,
            // Uses dirname to properly step out of /includes to /assets
            plugins_url( 'assets/js/paylater-checkout.js', dirname( __DIR__ ) . '/paylater.php' ),
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            '1.1.2', // Specific version to clear browser cache
            true
        );

        if( function_exists( 'wp_set_script_translations' ) ) {
            wp_set_script_translations( $handle, 'paylater' );
        }

        return [ $handle ];
    }

    /**
     * Data passed to window.wc.wcSettings.getSetting('paylater_shop_now_pay_later_data')
     */
    public function get_payment_method_data() {
        return [
            'title'       => $this->gateway->title,
            'description' => $this->gateway->description,
            'supports'    => array_filter( $this->gateway->supports, [ $this->gateway, 'supports' ] ),
            'icon'        => 'https://paylaterapp.com/wp-content/uploads/2024/12/paylater-logo.svg',
            'pro_data'    => [
                'min_amount'    => (float) ($this->settings['order_min'] ?? 200),
                'show_benefits' => 'yes'
            ]
        ];
    }
}