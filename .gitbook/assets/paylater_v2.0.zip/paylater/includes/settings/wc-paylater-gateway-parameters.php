<?php
/**
 * PayLater Pro Gateway Parameters
 * Centralized loader for all Pro-tier configuration and API endpoints.
 */

defined( 'ABSPATH' ) || exit;

function gatewayPaylaterParameters($th, $title) {
    // 1. Core Gateway Identity
    $th->id = 'paylater_shop_now_pay_later';
    $th->icon = apply_filters('woocommerce_paylater_icon', 'https://paylaterapp.com/wp-content/uploads/2024/12/paylater-logo.svg');
    $th->has_fields = false;
    $th->method_title = $title;
    $th->method_description = __('PayLater Payment Gateway.', 'paylater');

    // 2. Capabilities for 2026
    $th->supports = array('products', 'refunds');

    // 3. Load Saved Settings
    $th->init_settings();

    // 4. Map General Settings
    $th->enabled     = $th->get_option('enabled');
    $th->title       = $th->get_option('title');
    $th->description = $th->get_option('description');
    $th->order_min   = $th->get_option('order_min', '300');

    // 5. Map Pro Display Variables (PDP)
    $th->show_pdp_widget    = $th->get_option('show_pdp_widget', 'yes');
    $th->pdp_main_message   = $th->get_option('pdp_main_message', __('Pay with PayLater', 'paylater'));
    $th->pdp_sub_message    = $th->get_option('pdp_sub_message', __('Interest-free', 'paylater'));

    // 6. Map Pro Display Variables (PLP)
    $th->show_plp_widget    = $th->get_option('show_plp_widget', 'yes');
    $th->plp_main_message   = $th->get_option('plp_main_message', __('Pay with PayLater', 'paylater'));
    $th->plp_sub_message    = $th->get_option('plp_sub_message', __('Interest-free', 'paylater'));

    // 7. Map API Credentials
    $th->testMode   = $th->get_option('testMode') === 'yes';
    $th->apiKey     = $th->testMode ? $th->get_option('testApiKey') : $th->get_option('apiKey');
    $th->merchantId = $th->get_option('merchantId');
    $th->outletId   = $th->get_option('outletId');

    // 8. Secure API Endpoints for 2026
    $th->api = $th->testMode ?
        'https://connect-sandbox.paylaterapp.com/api/paylater/merchant-portal/web-checkout/' :
        'https://connect.paylaterapp.com/api/paylater/merchant-portal/web-checkout/';

    // 9. Administrative Hooks - Corrected to process_admin_options for saving
    add_action('woocommerce_update_options_payment_gateways_' . $th->id, array($th, 'process_admin_options'));
}