<?php
/**
 * PayLater Pro - Native Styled Form Fields
 * Configured with separate settings for PLP and PDP widgets.
 */

function paylater_form_fields($th, $section = '') {
    switch ($section) {
        case 'api':
            $th->form_fields = array(
                'api_section_start' => array(
                    'title'       => __( 'API Credentials', 'paylater' ),
                    'type'        => 'title',
                    'description' => __( 'Configure your PayLater API keys for secure transaction processing.', 'paylater' ),
                ),
                'testMode' => array(
                    'title'   => __( 'Test Mode', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Enable Test Mode', 'paylater' ),
                    'default' => 'yes',
                ),
                'testApiKey' => array(
                    'title'       => __( 'Test API Key', 'paylater' ),
                    'type'        => 'password',
                    'placeholder' => '••••••••••••••••',
                ),
                'apiKey' => array(
                    'title'       => __( 'Live API Key', 'paylater' ),
                    'type'        => 'password',
                    'placeholder' => '••••••••••••••••',
                ),
                'merchantId' => array(
                    'title'       => __( 'Merchant ID', 'paylater' ),
                    'type'        => 'text',
                    'description' => __( 'Your unique PayLater Merchant Identifier.', 'paylater' ),
                ),
                'outletId' => array(
                    'title'       => __( 'Outlet ID', 'paylater' ),
                    'type'        => 'text',
                    'description' => __( 'Your unique PayLater Outlet Identifier.', 'paylater' ),
                ),
            );
            break;

        case 'display':
            $th->form_fields = array(
                'display_section_start' => array(
                    'title'       => __( 'Widget Customization', 'paylater' ),
                    'type'        => 'title',
                    'description' => __( 'Configure messages for Product List (PLP) and Product Details (PDP).', 'paylater' ),
                ),
                // PDP WIDGET SETTINGS
                'show_pdp_widget' => array(
                    'title'   => __( 'Enable PDP Widget', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Display full widget on single product pages', 'paylater' ),
                    'default' => 'yes',
                ),
                'pdp_main_message' => array(
                    'title'       => __( 'PDP Main Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Pay with PayLater', 'paylater' ),
                    'description' => __( 'Main heading for the details page widget.', 'paylater' ),
                ),
                'pdp_sub_message' => array(
                    'title'       => __( 'PDP Sub Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Interest-free', 'paylater' ),
                    'description' => __( 'Supporting text for the details page widget.', 'paylater' ),
                ),
                // PLP WIDGET SETTINGS
                'show_plp_widget' => array(
                    'title'   => __( 'Enable PLP Widget', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Display summary bar on shop and list pages', 'paylater' ),
                    'default' => 'yes',
                ),
                'plp_main_message' => array(
                    'title'       => __( 'PLP Main Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Pay with PayLater', 'paylater' ),
                    'description' => __( 'Main heading for the list page bar.', 'paylater' ),
                ),
                'plp_sub_message' => array(
                    'title'       => __( 'PLP Sub Message', 'paylater' ),
                    'type'        => 'text',
                    'default'     => __( 'Interest-free', 'paylater' ),
                    'description' => __( 'Supporting text for the list page bar.', 'paylater' ),
                ),
            );
            break;

        default: // General settings
            $th->form_fields = array(
                'main_section_start' => array(
                    'title'       => __( 'Enable and customise', 'paylater' ),
                    'type'        => 'title',
                    'description' => __( 'Configure the core settings for the PayLater Pro gateway.', 'paylater' ),
                ),
                'enabled' => array(
                    'title'   => __( 'Enable PayLater', 'paylater' ),
                    'type'    => 'checkbox',
                    'label'   => __( 'Enable PayLater Pro gateway', 'paylater' ),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title'       => __( 'TITLE', 'paylater' ),
                    'type'        => 'text',
                    'description' => __( 'Payment method name that the customer will see during checkout.', 'paylater' ),
                    'default'     => __( 'PayLater', 'paylater' ),
                ),
                'description' => array(
                    'title'       => __( 'DESCRIPTION', 'paylater' ),
                    'type'        => 'textarea',
                    'description' => __( 'Payment method description that the customer will see during checkout.', 'paylater' ),
                    'default'     => __( 'Buy now and pay later with interest-free installments.', 'paylater' ),
                    'css'         => 'width: 100%; max-width: 600px;',
                ),
                'order_min' => array(
                    'title'       => __( 'ORDER MINIMUM', 'paylater' ),
                    'type'        => 'number',
                    'description' => __( 'The minimum cart total required to show this gateway.', 'paylater' ),
                    'default'     => '200',
                ),
            );
            break;
    }
}