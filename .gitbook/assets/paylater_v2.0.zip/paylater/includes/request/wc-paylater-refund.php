<?php
/**
 * PayLater Pro - Refund Handler
 * Processes automated refunds directly from the WooCommerce Order Edit screen.
 */

defined( 'ABSPATH' ) || exit;

function processPaylaterRefund($order_id, $amount = null, $reason = '', $th) {
    // 1. Load Order using modern CRUD (HPOS Compliant)
    $order = wc_get_order($order_id);

    try {
        if (!$order) {
            throw new Exception(__('Order not found.', 'paylater'));
        }

        // 2. Retrieve the unique transaction reference (e.g., 123_1737876550)
        $unique_ref = $order->get_meta('_paylater_unique_ref');

        if (!$unique_ref) {
            throw new Exception(__('Original transaction reference not found. Manual refund required.', 'paylater'));
        }

        // 3. Prepare Pro Refund Payload
        // Normalizes the API URL to ensure /refund is appended correctly
        $refund_url = rtrim($th->api, '/') . '/refund';

        $headers = array(
            'x-api-key'    => $th->apiKey,
            'Content-Type' => 'application/json'
        );

        $payload = array(
            'merchantId' => $th->merchantId,
            'orderId'    => $unique_ref,
            'amount'     => (float) $amount,
            'reason'     => !empty($reason) ? sanitize_text_field($reason) : __('Customer refund', 'paylater'),
            'currency'   => $order->get_currency()
        );

        // 4. Execute Remote Post to Gateway API
        $response = wp_remote_post($refund_url, array(
            'headers' => $headers,
            'body'    => json_encode($payload),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        // 5. Success Verification
        $status = isset($response_body['status']) ? strtoupper($response_body['status']) : '';

        if (in_array($status, ['REFUNDED', 'SUCCESS', 'COMPLETED'])) {
            $order->add_order_note(sprintf(
                __('PayLater Pro: Refund of %s processed successfully. Reason: %s', 'paylater'),
                strip_tags(wc_price($amount)),
                $payload['reason']
            ));
            return true;
        } else {
            $error_message = isset($response_body['message']) ? $response_body['message'] : __('Gateway declined the refund request.', 'paylater');
            throw new Exception($error_message);
        }

    } catch (Exception $e) {
        $error_msg = sprintf(__('PayLater Pro Refund Error: %s', 'paylater'), $e->getMessage());
        if ($order) {
            $order->add_order_note($error_msg);
        }
        return new WP_Error('refund_error', $error_msg);
    }
}