<?php
/**
 * PayLater Pro - Process Payment
 * Handles the initial API handshake and redirects the customer to the
 * secure PayLater payment portal.
 */

defined( 'ABSPATH' ) || exit;

function processPaylaterPayment($order_id, $th, $type = null, $addon) {
    // 1. Load Order using modern CRUD (HPOS Compatible)
    $order = wc_get_order($order_id);

    if ( ! $order ) {
        return array(
            'result'   => 'failure',
            'messages' => __('Invalid Order ID.', 'paylater')
        );
    }

    $currency = $order->get_currency();
    $total    = $order->get_total();

    // Ensure we use the dynamic setting from the gateway object
    $min = (float) $th->order_min;

    try {
        // 2. Minimum Order Enforcement
        if ($total < $min) {
            throw new Exception(sprintf(
                __('The minimum order amount for PayLater is %s %s. Please add more items to your cart.', 'paylater'),
                $min,
                $currency
            ));
        }

        // 3. Generate Unique Transaction Reference
        // Appending time prevents duplicate order errors on the gateway side
        $unique_ref = $order_id . '_' . time();

        // 4. Prepare Payload for API
        $payload = array(
            'merchantId'         => $th->merchantId,
            'outletId'           => $th->outletId,
            'currency'           => $currency,
            'amount'             => $total,
            'orderId'            => $unique_ref,
            'successRedirectUrl' => add_query_arg(['wc-api' => $addon, 'o' => $order_id, 's' => 's', 'orderId' => $unique_ref], home_url('/')),
            'failRedirectUrl'    => add_query_arg(['wc-api' => $addon, 'o' => $order_id, 's' => 'f', 'orderId' => $unique_ref], home_url('/'))
        );

        // 5. Store Metadata (HPOS compliant)
        $order->update_meta_data('_paylater_unique_ref', $unique_ref);
        $order->save();

        // 6. Execute API Request
        $response = wp_remote_post($th->api, array(
            'headers' => array(
                'x-api-key'    => $th->apiKey,
                'Content-Type' => 'application/json'
            ),
            'body'    => json_encode($payload),
            'timeout' => 45
        ));

        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }

        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        // 7. Handle Redirect to Gateway Portal
        if (isset($response_body['paymentLinkUrl'])) {

            $order->update_meta_data('_paylater_link', $response_body['paymentLinkUrl']);

            // Set status to pending to reserve stock during the session
            $order->update_status('pending', __('Customer redirected to PayLater portal.', 'paylater'));
            $order->save();

            return array(
                'result'   => 'success',
                'redirect' => $response_body['paymentLinkUrl']
            );

        } else {
            $error = isset($response_body['message']) ? $response_body['message'] : __('Gateway handshake failed. Please try again.', 'paylater');
            throw new Exception($error);
        }

    } catch (Exception $e) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PayLater Exception: ' . $e->getMessage());
        }

        wc_add_notice($e->getMessage(), 'error');

        return array(
            'result'   => 'failure',
            'redirect' => ''
        );
    }
}