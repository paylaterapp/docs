<?php
/**
 * PayLater Pro - Response Handler
 * Processes the return/callback from the PayLater portal with server-side verification.
 */

defined( 'ABSPATH' ) || exit;

function paylaterResponseHandler($th) {
    try {
        // 1. Sanitize and Validate Request Parameters
        $order_id          = isset($_GET['o']) ? sanitize_text_field($_GET['o']) : null;
        $status            = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : null;
        $paylater_order_id = isset($_GET['orderId']) ? sanitize_text_field($_GET['orderId']) : null;

        if (!$order_id) {
            throw new Exception(__('Order ID not found in response.', 'paylater'));
        }

        // 2. Load Order Object (HPOS Compatible)
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            throw new Exception(__('Invalid order received.', 'paylater'));
        }

        // 3. Prevent Duplicate Processing
        if ($order->has_status(array('completed', 'processing'))) {
            wp_redirect($order->get_checkout_order_received_url());
            exit;
        }

        // 4. Handle Success Callback ('s') with Server-Side Verification
        if ($status === 's') {

            // PRO SECURITY: Construct Status Verification URL
            $base_api = rtrim($th->api, '/');
            $status_url = add_query_arg([
                'orderId'    => $paylater_order_id,
                'merchantId' => $th->merchantId
            ], $base_api . '/status');

            $headers = array(
                'x-api-key'    => $th->apiKey,
                'Content-Type' => 'application/json'
            );

            // Execute verification call directly to PayLater servers
            $response = wp_remote_get($status_url, array(
                'headers' => $headers,
                'timeout' => 30
            ));

            $is_verified = false;

            if (!is_wp_error($response)) {
                $response_body = wp_remote_retrieve_body($response);
                $response_data = json_decode($response_body, true);
                $api_status    = isset($response_data['status']) ? strtoupper($response_data['status']) : '';

                // Verify specific status from gateway
                if (in_array($api_status, ['SUCCESS', 'PAID', 'COMPLETED'])) {
                    $is_verified = true;
                }
            }

            if ($is_verified) {
                // Finalize Payment & Record Transaction ID
                $order->payment_complete($paylater_order_id);
                $order->add_order_note(sprintf(__('PayLater Pro: Payment Verified. Transaction ID: %s', 'paylater'), $paylater_order_id));

                WC()->cart->empty_cart();
                wp_redirect($order->get_checkout_order_received_url());
                exit;
            } else {
                // API check failed - suspected URL manipulation
                $order->update_status('on-hold', __('Payment callback received but API verification failed. Manual check required.', 'paylater'));
                wc_add_notice(__('Your payment is being verified. Please contact support if your order does not update shortly.', 'paylater'), 'notice');
                wp_redirect($order->get_checkout_order_received_url());
                exit;
            }
        }

        // 5. Handle Failure Callback ('f')
        else if ($status === 'f') {
            $order->update_status('failed', __('User returned from PayLater with failure status.', 'paylater'));
            wc_add_notice(__('Payment was declined or cancelled. Please try another method.', 'paylater'), 'error');
            wp_redirect(wc_get_checkout_url());
            exit;
        }

        // 6. Handle Unknown/Unexpected Status
        else {
            $order->add_order_note(__('Unknown payment status received from gateway callback.', 'paylater'));
            wp_redirect($order->get_cancel_order_url());
            exit;
        }

    } catch (Exception $e) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('PayLater Pro Response Error: ' . $e->getMessage());
        }
        wc_add_notice($e->getMessage(), 'error');
        wp_redirect(wc_get_checkout_url());
        exit;
    }
}