<?php
/**
 * PayLater Pro - Frontend Display Logic
 * Handles Product Page Widgets (PDP) and Shop List Widgets (PLP).
 */

defined( 'ABSPATH' ) || exit;

class WC_PayLater_Pro_Display {

    public function __construct() {
        // Correct settings key based on your dynamic gateway ID
        $settings = get_option('woocommerce_paylater_shop_now_pay_later_settings');

        // 1. PDP Widget Hook (Single Product Page)
        if (isset($settings['show_pdp_widget']) && $settings['show_pdp_widget'] === 'yes') {
            add_action('woocommerce_single_product_summary', array($this, 'render_pdp_widget'), 15);
        }

        // 2. PLP Widget Hook (Shop / Category / List Pages)
        if (isset($settings['show_plp_widget']) && $settings['show_plp_widget'] === 'yes') {
            add_action('woocommerce_after_shop_loop_item_title', array($this, 'render_plp_widget'), 11);
        }

        // 3. Checkout Benefits List Hook
        add_filter('woocommerce_gateway_description', array($this, 'add_checkout_benefits'), 10, 2);
    }

    /**
     * PDP Widget: Full Collapsible View with Monthly Installments
     */
    public function render_pdp_widget() {
        global $product;
        if ( ! is_a( $product, 'WC_Product' ) ) return;

        $settings = get_option('woocommerce_paylater_shop_now_pay_later_settings');
        $price    = $product->get_price();
        $min      = isset($settings['order_min']) ? $settings['order_min'] : 0;

        if ($price < $min) return;

        $monthly  = number_format($price / 4, 2);

        // Dynamically pull text from admin settings
        $main_msg = !empty($settings['pdp_main_message']) ? $settings['pdp_main_message'] : __('Pay with PayLater', 'paylater');
        $sub_msg  = !empty($settings['pdp_sub_message']) ? $settings['pdp_sub_message'] : __('Interest-free', 'paylater');

        // GENERATE DYNAMIC MONTHLY DATES (Starting from Jan 26, 2026)
        $installments = [];
        for ($i = 0; $i < 4; $i++) {
            if ($i === 0) {
                $installments[] = __('Today', 'paylater');
            } else {
                // Calculates: Today + 1 month, Today + 2 months, Today + 3 months
                // Result for Jan 26: 26 Feb, 26 Mar, 26 Apr
                $installments[] = date('d M', strtotime("+$i month"));
            }
        }
        ?>
        <div class="paylater-collapsible product-page-widget" id="pdp-widget">
            <div class="paylater-header-collapsed" onclick="this.parentElement.classList.toggle('expanded')">
                <div class="paylater-header-left">
                    <div class="paylater-logo-small">
                        <img src="https://paylaterapp.com/wp-content/uploads/2024/12/cropped-paylater-512x512-1-32x32.webp" alt="PayLater">
                    </div>
                    <div class="paylater-summary">
                        <div class="paylater-summary-text"><?php echo esc_html($main_msg); ?></div>
                        <div class="paylater-summary-amount">
                            Pay QAR <?php echo $monthly; ?> today
                            <span class="small-text"><?php echo esc_html($sub_msg); ?></span>
                        </div>
                    </div>
                </div>
                <div class="expand-icon">▼</div>
            </div>
            <div class="paylater-content">
                <div class="paylater-installments">
                    <?php foreach ($installments as $index => $date_label): ?>
                        <div class="installment-box <?php echo ($index === 0) ? 'today' : ''; ?>">
                            <div class="installment-label"><?php echo esc_html($date_label); ?></div>
                            <div class="installment-amount"><?php echo $monthly; ?></div>
                            <div class="installment-currency">QAR</div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="paylater-footer">✓ <?php _e('No interest', 'paylater'); ?>  ✓ <?php _e('No hidden fees', 'paylater'); ?></div>
            </div>
        </div>
        <?php
    }

    /**
     * PLP Widget: Simplified Bar for List Pages
     */
    public function render_plp_widget() {
        global $product;
        if ( ! is_a( $product, 'WC_Product' ) ) return;

        $settings = get_option('woocommerce_paylater_shop_now_pay_later_settings');
        $price    = $product->get_price();
        $min      = isset($settings['order_min']) ? $settings['order_min'] : 0;

        if ($price < $min) return;

        $monthly  = number_format($price / 4, 2);

        // Dynamically pull text from admin settings
        $main_msg = !empty($settings['plp_main_message']) ? $settings['plp_main_message'] : __('Pay with PayLater', 'paylater');
        $sub_msg  = !empty($settings['plp_sub_message']) ? $settings['plp_sub_message'] : __('Interest-free', 'paylater');

        ?>
        <div class="paylater-collapsible list-page-widget" style="margin-top: 10px; border-color: rgba(45, 33, 73, 0.1);">
            <div class="paylater-header-collapsed" style="padding: 8px 12px; cursor: default;">
                <div class="paylater-header-left">
                    <div class="paylater-logo-small plp-logo">
                        <img src="https://paylaterapp.com/wp-content/uploads/2024/12/cropped-paylater-512x512-1-32x32.webp" style="width: 24px;" alt="PayLater">
                    </div>
                    <div class="paylater-summary">
                        <div class="paylater-summary-text" style="font-size: 11px;"><?php echo esc_html($main_msg); ?></div>
                        <div class="paylater-summary-amount" style="font-size: 13px;">
                            Pay QAR <?php echo $monthly; ?> today
                            <span class="small-text" style="font-size: 10px;"><?php echo esc_html($sub_msg); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Checkout Benefits: Added to the gateway description
     */
    public function add_checkout_benefits($description, $gateway_id) {
        if ($gateway_id === 'paylater_shop_now_pay_later') {
            $list = '<ul class="paylater-benefits-list" style="margin-top:10px; padding:0; list-style:none;">';
            $list .= '<li>✅ ' . __('No hidden interest or fees', 'paylater') . '</li>';
            $list .= '<li>✅ ' . __('Instant approval in seconds', 'paylater') . '</li>';
            $list .= '<li>✅ ' . __('Split your total into 4 easy payments', 'paylater') . '</li>';
            $list .= '</ul>';
            return $description . $list;
        }
        return $description;
    }
}

// Instantiate the class
new WC_PayLater_Pro_Display();