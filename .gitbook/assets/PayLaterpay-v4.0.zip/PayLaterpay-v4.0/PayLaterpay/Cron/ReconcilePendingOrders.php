<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Cron;

use Exception;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use PayLater\PayLaterpay\Helper\Data as PayLaterHelper;
use PayLater\PayLaterpay\Model\SpotiiPay;

/**
 * Safety net for redirect-payment edge cases:
 */
class ReconcilePendingOrders
{
    /** Don't touch orders younger than this — let the Complete controller win the race. */
    const MIN_AGE_MINUTES = 3;

    /** Hard cap on how long a still-pending order can sit before being cancelled. */
    const ABANDONED_AFTER_HOURS = 24;

    /** Don't process more than this many per cron tick. */
    const BATCH_LIMIT = 50;

    const PAYMENT_METHOD = 'ppaylater';

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    /**
     * @var SpotiiPay
     */
    private $paymentMethod;

    /**
     * @var PayLaterHelper
     */
    private $helper;

    public function __construct(
        OrderRepositoryInterface $orderRepository,
        SearchCriteriaBuilder    $searchCriteriaBuilder,
        SpotiiPay                $paymentMethod,
        PayLaterHelper           $helper
    ) {
        $this->orderRepository = $orderRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->paymentMethod = $paymentMethod;
        $this->helper = $helper;
    }

    public function execute(): void
    {
        $reconcileBefore = gmdate('Y-m-d H:i:s', strtotime('-' . self::MIN_AGE_MINUTES . ' minutes'));
        $abandonedBefore = gmdate('Y-m-d H:i:s', strtotime('-' . self::ABANDONED_AFTER_HOURS . ' hours'));

        $criteria = $this->searchCriteriaBuilder
            ->addFilter(OrderInterface::STATE, Order::STATE_PENDING_PAYMENT)
            ->addFilter(OrderInterface::CREATED_AT, $reconcileBefore, 'lteq')
            ->setPageSize(self::BATCH_LIMIT)
            ->create();

        /** @var OrderInterface[] $orders */
        $orders = $this->orderRepository->getList($criteria)->getItems();

        foreach ($orders as $order) {
            // SearchCriteria can't easily filter on payment.method, so guard here.
            if ($order->getPayment()->getMethod() !== self::PAYMENT_METHOD) {
                continue;
            }
            $this->reconcile($order, $abandonedBefore);
        }
    }

    private function reconcile(OrderInterface $order, string $abandonedBefore): void
    {
        $reference = (string) $order->getPayment()
            ->getAdditionalInformation(SpotiiPay::ADDITIONAL_INFORMATION_KEY_ORDERID);
        if ($reference === '') {
            $reference = (string) $order->getIncrementId();
        }
        $incrementId = $order->getIncrementId();

        try {
            $info = $this->paymentMethod->getOrderInfo($reference);
            $status = isset($info['status']) ? (int) $info['status'] : null;

            if ($status === SpotiiPay::GATEWAY_STATUS_SUCCESS) {
                $gatewayTxnId = isset($info['payLaterOrderId']) ? (string) $info['payLaterOrderId'] : null;
                $this->paymentMethod->processSuccessfulPayment($order, $reference, $gatewayTxnId);
                $this->helper->logSpotiiActions(
                    "[cron] settled $incrementId as paid (txn=" . ($gatewayTxnId ?: 'n/a') . ')'
                );
                return;
            }

            if ($status === SpotiiPay::GATEWAY_STATUS_FAILED) {
                $this->paymentMethod->processFailedPayment($order, 'Gateway reported payment failed');
                $this->helper->logSpotiiActions("[cron] cancelled failed $incrementId");
                return;
            }

            if ($status === SpotiiPay::GATEWAY_STATUS_PENDING
                && $order->getCreatedAt() < $abandonedBefore) {
                $this->paymentMethod->processFailedPayment(
                    $order,
                    'Abandoned: pending > ' . self::ABANDONED_AFTER_HOURS . 'h'
                );
                $this->helper->logSpotiiActions("[cron] cancelled abandoned $incrementId");
                return;
            }

            $this->helper->logSpotiiActions(
                "[cron] $incrementId still pending (gateway status=" . ($status ?? 'null') . ')'
            );
        } catch (Exception $e) {
            $this->helper->logSpotiiActions(
                "[cron] error reconciling $incrementId: " . $e->getMessage()
            );
        }
    }
}
