<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Backend;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\ValidatorException;

/**
 * Admin-config validator for `payment/ppaylater/price_range`.
 */
class PriceRange extends Value
{
    const MIN_ALLOWED = 300;

    public function beforeSave()
    {
        $raw = $this->getValue();
        if ($raw === '' || $raw === null) {
            // Empty falls back to the config.xml default (300).
            return parent::beforeSave();
        }

        if (!is_numeric($raw)) {
            throw new ValidatorException(
                __('Minimum Order Amount must be a number.')
            );
        }

        if ((float) $raw < self::MIN_ALLOWED) {
            throw new ValidatorException(
                __('Minimum Order Amount cannot be less than %1.', self::MIN_ALLOWED)
            );
        }

        $this->setValue((string) (float) $raw);
        return parent::beforeSave();
    }
}
