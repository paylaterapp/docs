<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model;

use Exception;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\DataObject;
use Magento\Framework\DB\Transaction as DbTransaction;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Payment\Helper\Data;
use Magento\Payment\Model\InfoInterface;
use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Payment\Model\Method\Logger;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\Order\Invoice;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Sales\Model\Service\InvoiceService;
use PayLater\PayLaterpay\Helper\Data as PayLaterHelper;
use PayLater\PayLaterpay\Model\Api\PayloadBuilder;
use PayLater\PayLaterpay\Model\Api\ProcessorInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Zend_Log_Exception;

/**
 * PayLater payment method.
 */
class SpotiiPay extends AbstractMethod
{
    const PAYMENT_CODE = 'ppaylater';
    const ADDITIONAL_INFORMATION_KEY_ORDERID = 'ppaylater_order_id';
    const ADDITIONAL_INFORMATION_KEY_TXN_ID = 'paylater_transaction_id';

    /** Gateway status codes. */
    const GATEWAY_STATUS_PENDING = 1;
    const GATEWAY_STATUS_SUCCESS = 2;
    const GATEWAY_STATUS_FAILED = 3;

    /** Full-refund endpoint requires a transaction type; only DOWN_PAYMENT is supported. */
    const REFUND_TRANSACTION_TYPE = 'DOWN_PAYMENT';

    /**
     * @var string
     */
    protected $_code = self::PAYMENT_CODE;

    /**
     * @var bool
     */
    protected $_isGateway = true;

    /**
     * Initialize-needed flag
     *
     * @var bool
     */
    protected $_isInitializeNeeded = true;

    /**
     * @var bool
     */
    protected $_canOrder = true;

    /**
     * @var bool
     */
    protected $_canAuthorize = true;

    /**
     * @var bool
     */
    protected $_canCapture = true;

    /**
     * @var bool
     */
    protected $_canRefund = true;

    /**
     * @var bool
     */
    protected $_canRefundInvoicePartial = true;

    /**
     * @var bool
     */
    protected $_canUseInternal = false;

    /**
     * @var bool
     */
    protected $_canFetchTransactionInfo = true;

    /**
     * @var PayLaterHelper
     */
    protected $spotiiHelper;

    /**
     * @var PayloadBuilder
     */
    private $payloadBuilder;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * @var ProcessorInterface
     */
    private $apiProcessor;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var InvoiceService
     */
    private $invoiceService;

    /**
     * @var DbTransaction
     */
    private $dbTransaction;

    /**
     * @var OrderSender
     */
    private $orderSender;

    /**
     * @var InvoiceSender
     */
    private $invoiceSender;

    public function __construct(
        Context                             $context,
        SpotiiApiConfigInterface            $spotiiApiConfig,
        PayLaterHelper                      $spotiiHelper,
        PayloadBuilder                      $payloadBuilder,
        ProcessorInterface                  $apiProcessor,
        InvoiceService                      $invoiceService,
        DbTransaction                       $dbTransaction,
        OrderSender                         $orderSender,
        InvoiceSender                       $invoiceSender,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        Registry                            $registry,
        ExtensionAttributesFactory          $extensionFactory,
        AttributeValueFactory               $customAttributeFactory,
        Data                                $paymentData,
        ScopeConfigInterface                $scopeConfig,
        Logger                              $mageLogger
    ) {
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->spotiiHelper = $spotiiHelper;
        $this->payloadBuilder = $payloadBuilder;
        $this->apiProcessor = $apiProcessor;
        $this->invoiceService = $invoiceService;
        $this->dbTransaction = $dbTransaction;
        $this->orderSender = $orderSender;
        $this->invoiceSender = $invoiceSender;
        $this->jsonHelper = $jsonHelper;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $mageLogger
        );
    }

    /**
     * @param CartInterface|null $quote
     * @return bool
     */
    public function isAvailable(CartInterface $quote = null)
    {
        if (!$this->spotiiApiConfig->isEnabled()) {
            return false;
        }
        if (!$quote) {
            return false;
        }
        if (!$this->isTotalInAllowedRange((float) $quote->getGrandTotal())) {
            return false;
        }
        return parent::isAvailable($quote);
    }

    private function isTotalInAllowedRange(float $total): bool
    {
        if ($total < 300) {
            return false;
        }
        $range = (float) $this->_scopeConfig->getValue(
            'payment/ppaylater/price_range',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        return $total >= $range;
    }

    /**
     * @param int|null $storeId
     * @return bool
     */
    public function isActive($storeId = null)
    {
        return $this->spotiiApiConfig->isEnabled();
    }

    /**
     * @param string $paymentAction
     * @param object $stateObject
     * @return $this
     */
    public function initialize($paymentAction, $stateObject)
    {
        $stateObject->setState(Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus(Order::STATE_PENDING_PAYMENT);
        $stateObject->setIsNotified(false);
        return $this;
    }

    /**
     * @param OrderInterface $order
     * @return string
     * @throws Zend_Log_Exception
     */
    public function getCheckoutUrl(OrderInterface $order): string
    {
        $reference = $order->getIncrementId();
        $payment = $order->getPayment();
        $payment->setAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID, $reference);

        $this->spotiiHelper->logSpotiiActions("Building gateway checkout for order $reference");

        $url = $this->spotiiApiConfig->getSpotiiBaseUrl() . 'v2/web-checkout';
        $body = $this->payloadBuilder->buildCheckoutPayload($order, $reference);

        $response = $this->apiProcessor->call($url, $body, 'POST');
        $decoded = $this->jsonHelper->jsonDecode($response, true);

        // Tolerate both camelCase and snake_case to match whatever v2 returns.
        $paymentLinkUrl = is_array($decoded)
            ? ($decoded['paymentLinkUrl'] ?? $decoded['payment_link_url'] ?? null)
            : null;

        if (!$paymentLinkUrl) {
            $this->spotiiHelper->logSpotiiActions(
                'No payment link URL in response: ' . substr((string) $response, 0, 500)
            );
            throw new LocalizedException(__('PayLater did not return a payment link.'));
        }

        return $paymentLinkUrl;
    }

    /**
     * Query gateway for the status of a reference.
     *
     * @param string $reference
     * @return array
     * @throws LocalizedException
     */
    public function getOrderInfo(string $reference): array
    {
        $url = $this->spotiiApiConfig->getSpotiiBaseUrl()
            . 'v2/web-checkout/status?order_id=' . urlencode($reference);

        $raw = $this->apiProcessor->call($url, null, 'GET');
        $result = $this->jsonHelper->jsonDecode($raw, true);
        if (!is_array($result)) {
            throw new LocalizedException(__('Unexpected gateway response.'));
        }
        // Gateway error envelope: {"error": "Order ID is required"} on bad input.
        if (isset($result['error'])) {
            throw new LocalizedException(__('PayLater: %1', (string) $result['error']));
        }
        if (isset($result['status']) && (int) $result['status'] === ProcessorInterface::BAD_REQUEST) {
            throw new LocalizedException(__('Invalid checkout. Please retry again.'));
        }
        return $result;
    }

    /**
     * @param OrderInterface $order
     * @param string $reference Magento increment id (= merchantReference at gateway)
     * @param string|null $gatewayTransactionId payLaterOrderId from gateway
     * @return void
     * @throws LocalizedException
     */
    public function processSuccessfulPayment(
        OrderInterface $order,
        string $reference,
        ?string $gatewayTransactionId = null
    ): void {
        if ($order->getState() === Order::STATE_PROCESSING
            || $order->getState() === Order::STATE_COMPLETE) {
            $this->spotiiHelper->logSpotiiActions(
                "Order {$order->getIncrementId()} already settled (state={$order->getState()})"
            );
            return;
        }

        $transactionId = $gatewayTransactionId ?: $reference;

        $payment = $order->getPayment();
        $payment->setTransactionId($transactionId);
        $payment->setLastTransId($transactionId);
        $payment->setIsTransactionClosed(true);
        $payment->setAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID, $reference);
        if ($gatewayTransactionId) {
            $payment->setAdditionalInformation(
                self::ADDITIONAL_INFORMATION_KEY_TXN_ID,
                $gatewayTransactionId
            );
        }

        $payment->setIsTransactionPending(false);
        $payment->setShouldCloseParentTransaction(true);
        $payment->registerCaptureNotification($order->getGrandTotal(), true);

        $order->setState(Order::STATE_PROCESSING)
              ->setStatus(Order::STATE_PROCESSING)
              ->addCommentToStatusHistory(
                  __(
                      'PayLater payment confirmed. Transaction: %1 (merchant ref: %2)',
                      $transactionId,
                      $reference
                  )
              );
        $order->save();

        // Send invoice email
        $invoice = $payment->getCreatedInvoice();
        if ($invoice && !$invoice->getEmailSent()) {
            try {
                $this->invoiceSender->send($invoice);
            } catch (Exception $e) {
                $this->spotiiHelper->logSpotiiActions(
                    "Invoice email failed for {$order->getIncrementId()}: " . $e->getMessage()
                );
            }
        }

        try {
            $this->orderSender->send($order, true);
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions(
                "Order email failed for {$order->getIncrementId()}: " . $e->getMessage()
            );
        }

        $this->spotiiHelper->logSpotiiActions("Settled order {$order->getIncrementId()} as paid");
    }

    /**
     * Cancel a pending order. Idempotent.
     *
     * @param OrderInterface $order
     * @param string $reason
     * @return void
     */
    public function processFailedPayment(OrderInterface $order, string $reason = ''): void
    {
        if ($order->getState() === Order::STATE_CANCELED) {
            return;
        }
        if (!$order->canCancel()) {
            $this->spotiiHelper->logSpotiiActions(
                "Order {$order->getIncrementId()} cannot be canceled (state={$order->getState()})"
            );
            return;
        }
        $order->cancel();
        if ($reason !== '') {
            $order->addCommentToStatusHistory(__('PayLater: %1', $reason));
        }
        $order->save();
        $this->spotiiHelper->logSpotiiActions(
            "Canceled order {$order->getIncrementId()}: $reason"
        );
    }

    /**
     * @param InfoInterface $payment
     * @param float $amount
     * @return $this
     * @throws LocalizedException
     */
    public function refund(InfoInterface $payment, $amount)
    {
        $order = $payment->getOrder();
        $orderTotal = round((float) $order->getGrandTotal(), 2);
        $refundAmount = round((float) $amount, 2);
        $reference = (string) $payment->getAdditionalInformation(self::ADDITIONAL_INFORMATION_KEY_ORDERID)
            ?: (string) $order->getIncrementId();
        $isFull = abs($orderTotal - $refundAmount) <= 0.01;

        $this->spotiiHelper->logSpotiiActions(sprintf(
            '[refund] ENTER order=%s requested=%s grandTotal=%s currency=%s mode=%s',
            $reference,
            $refundAmount,
            $orderTotal,
            $order->getOrderCurrencyCode(),
            $isFull ? 'FULL' : 'PARTIAL'
        ));

        try {
            if ($isFull) {
                $result = $this->refundPayment($reference);
                $txnId = $reference . '-refund';
            } else {
                $result = $this->refundPartialPayment($reference, $refundAmount);
                $txnId = $reference . '-refund-' . sprintf('%.2f', $refundAmount);
            }
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions(
                "[refund] FAILED for $reference: " . $e->getMessage()
            );
            throw $e;
        }

        $message = $result['message'] ?? 'Refund accepted';
        $payment->setTransactionId($txnId);
        $payment->setIsTransactionClosed(true);
        $payment->setShouldCloseParentTransaction(false);
        $order->addCommentToStatusHistory(
            __('PayLater refund initiated. Gateway: %1', $message)
        );
        $this->spotiiHelper->logSpotiiActions("[refund] OK $reference: $message");
        return $this;
    }

    /**
     * @param string $merchantReference Magento increment id (= order_id)
     * @return array
     * @throws LocalizedException
     */
    public function refundPayment(string $merchantReference): array
    {
        $url = $this->spotiiApiConfig->getSpotiiBaseUrl() . 'v2/web-checkout/refund';
        $body = ['order_id' => $merchantReference];
        $raw = $this->apiProcessor->call($url, $body, 'POST');
        return $this->parseRefundResponse($raw);
    }

    /**
     * @param string $merchantReference Magento increment id (= order_id)
     * @param float $amount
     * @return array
     * @throws LocalizedException
     */
    public function refundPartialPayment(string $merchantReference, float $amount): array
    {
        $url = $this->spotiiApiConfig->getSpotiiBaseUrl() . 'v2/web-checkout/refund';
        $body = [
            'order_id' => $merchantReference,
            'amount'   => (string) round($amount, 2),
        ];
        $raw = $this->apiProcessor->call($url, $body, 'POST');
        return $this->parseRefundResponse($raw);
    }

    /**
     * @param mixed $raw
     * @return array
     * @throws LocalizedException
     */
    private function parseRefundResponse($raw): array
    {
        $result = $this->jsonHelper->jsonDecode($raw, true);
        if (!is_array($result)) {
            throw new LocalizedException(__('Unexpected gateway response.'));
        }
        if (isset($result['error'])) {
            $detail = !empty($result['message']) ? (string) $result['message'] : (string) $result['error'];
            throw new LocalizedException(__('PayLater refund failed: %1', $detail));
        }
        return $result;
    }
}
