<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Sales\Api\Data\OrderInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

class PayloadBuilder
{
    const PRECISION = 2;

    /** Default gateway-link expiry in minutes (used by /v2/web-checkout). */
    const DEFAULT_EXPIRY_MINUTES = 10;

    /**
     * @var SpotiiApiConfigInterface
     */
    protected $spotiiApiConfig;

    /**
     * @var ConfigInterface
     */
    protected $config;

    public function __construct(
        SpotiiApiConfigInterface $spotiiApiConfig,
        ConfigInterface          $config
    ) {
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->config = $config;
    }

    /**
     * Build the v2 /web-checkout payload
     */
    public function buildCheckoutPayload(OrderInterface $order, string $reference): array
    {
        return [
            'outlet_id'            => (int) $this->spotiiApiConfig->getOutletId(),
            'currency'             => $order->getOrderCurrencyCode(),
            'amount'               => round((float) $order->getGrandTotal(), self::PRECISION),
            'order_id'             => $reference,
            'success_redirect_url' => $this->config->getCompleteUrl($reference),
            'fail_redirect_url'    => $this->config->getCancelUrl(null, $reference),
            'expiry_duration'      => self::DEFAULT_EXPIRY_MINUTES,
        ];
    }
}
