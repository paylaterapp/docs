<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

interface ConfigInterface
{
    /**
     * @param string|null $reference
     * @return string
     */
    public function getCompleteUrl($reference = null);

    /**
     * Get failure-return URL.
     *
     * @param string|null $error
     * @param string|null $reference
     * @return string
     */
    public function getCancelUrl($error = null, $reference = null);
}
