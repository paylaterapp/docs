<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Controller\Standard;

use Exception;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;
use PayLater\PayLaterpay\Model\SpotiiPay as SpotiiPayModel;

class Complete extends SpotiiPay
{
    /**
     * Verify gateway status and settle the order
     */
    public function execute()
    {
        try {
            $reference = (string) $this->getRequest()->getParam('id');
            if ($reference === '') {
                $reference = (string) $this->checkoutSession->getLastRealOrderId();
            }
            if ($reference === '') {
                throw new LocalizedException(__('No order reference provided.'));
            }

            $order = $this->orderFactory->create()->loadByIncrementId($reference);
            if (!$order->getId()) {
                throw new LocalizedException(__('Order %1 not found.', $reference));
            }
            if ($order->getPayment()->getMethod() !== SpotiiPayModel::PAYMENT_CODE) {
                throw new LocalizedException(__('Order is not a PayLater order.'));
            }

            // Verify gateway status before changing anything.
            $info = $this->spotiipayModel->getOrderInfo($reference);
            $this->spotiiHelper->logSpotiiActions('OrderInfo : ' . json_encode($info));
            $status = isset($info['status']) ? (int) $info['status'] : null;

            if ($status !== SpotiiPayModel::GATEWAY_STATUS_SUCCESS) {
                $this->spotiipayModel->processFailedPayment(
                    $order,
                    'Gateway returned status ' . ($status ?? 'unknown')
                );
                $this->messageManager->addErrorMessage(__('Payment was not successful. Please try again.'));
                return $this->_redirect('checkout/cart');
            }

            $magentoTotal = round((float) $order->getGrandTotal(), 2);
            $gatewayTotal = isset($info['total']) ? (float) $info['total'] : null;
            $magentoCurr = $order->getOrderCurrencyCode();
            $gatewayCurr = $info['currency'] ?? null;
            if ($gatewayTotal !== null
                && ($magentoCurr !== $gatewayCurr
                    || abs($magentoTotal - $gatewayTotal) > 0.01)) {
                $this->spotiipayModel->processFailedPayment(
                    $order,
                    sprintf(
                        'Amount/currency mismatch: Magento=%s %s vs Gateway=%s %s',
                        $magentoTotal,
                        $magentoCurr,
                        $gatewayTotal,
                        $gatewayCurr
                    )
                );
                $this->messageManager->addErrorMessage(__('Order total mismatch with PayLater. Please retry.'));
                return $this->_redirect('checkout/cart');
            }

            // Settle the order with the gateway's own transaction id.
            $gatewayTxnId = isset($info['payLaterOrderId']) ? (string) $info['payLaterOrderId'] : null;
            $this->spotiipayModel->processSuccessfulPayment($order, $reference, $gatewayTxnId);

            $this->checkoutSession
                ->setLastOrderId($order->getId())
                ->setLastRealOrderId($order->getIncrementId())
                ->setLastOrderStatus($order->getStatus())
                ->setLastSuccessQuoteId($order->getQuoteId())
                ->setLastQuoteId($order->getQuoteId());

            $this->messageManager->addSuccessMessage(
                __('Success! Payment completed. Thank you for your payment, your order with PayLater has been placed.')
            );
            return $this->_redirect('checkout/onepage/success');

        } catch (LocalizedException $e) {
            $this->spotiiHelper->logSpotiiActions('Transaction Exception: ' . $e->getMessage());
            $this->messageManager->addErrorMessage($e->getMessage());
            return $this->_redirect('checkout/cart');
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions('Transaction Exception: ' . $e->getMessage());
            $this->messageManager->addErrorMessage(__('An error occurred while processing your payment. Please try again.'));
            return $this->_redirect('checkout/cart');
        }
    }
}
