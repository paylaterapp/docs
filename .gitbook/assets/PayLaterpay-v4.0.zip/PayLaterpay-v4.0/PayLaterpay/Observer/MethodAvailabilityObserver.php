<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use Psr\Log\LoggerInterface as Logger;

/**
 * Class MethodAvailabilityObserver
 * @package PayLater\PayLaterpay\Observer
 */
class MethodAvailabilityObserver implements ObserverInterface
{
    const PAYMENT_CODE = 'ppaylater';

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * MethodAvailabilityObserver constructor.
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param Logger $logger
     */
    public function __construct(
        SpotiiApiConfigInterface $spotiiApiConfig,
        Logger                   $logger
    )
    {
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->logger = $logger;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $result = $observer->getEvent()->getResult();
        $methodInstance = $observer->getEvent()->getMethodInstance();
        $methodCode = $methodInstance->getCode();

        $this->logger->info('PayLater Availability Check - Method Code: ' . $methodCode);

        if ($methodCode == self::PAYMENT_CODE) {
            $clientId = $this->spotiiApiConfig->getClientId();
            $clientSecret = $this->spotiiApiConfig->getClientSecret();
            $outletId = $this->spotiiApiConfig->getOutletId();

            if (!$clientId || !$clientSecret || !$outletId) {
                $result->setData('is_available', false);
                $this->logger->info(sprintf(
                    'PayLater availability: DISABLED (client_id=%s client_secret=%s outlet_id=%s)',
                    $clientId ? 'set' : 'EMPTY',
                    $clientSecret ? 'set' : 'EMPTY',
                    $outletId ? $outletId : 'EMPTY'
                ));
            }
        }
    }
}
