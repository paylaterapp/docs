<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Exception;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\LocalizedException;
use PayLater\PayLaterpay\Helper\Data as PayLaterHelper;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

/**
 * OAuth2 access-token life-cycle management for the PayLater v2 API.
 *
 *   1st call           → grant_type=client_credentials  → access_token + (maybe) refresh_token
 *   Before each call:
 *     now < expiry-60s → reuse cached access_token                            (no network call)
 *     refresh valid    → grant_type=refresh_token       → fresh access_token  (no creds re-sent)
 *     otherwise        → grant_type=client_credentials  → full re-auth
 *
 * Per PayLater guidance: cache one token per merchant (not per outlet — outlet_id
 * is sent in the body of API calls, not encoded in the token). Use refresh_token
 * grant to avoid re-sending client credentials on every renewal; fall through to
 * client_credentials only when the refresh token has also expired.
 *
 * Cache value is a JSON envelope:
 *   { access_token, expires_at, refresh_token|null, refresh_expires_at|0 }
 * `expires_at` and `refresh_expires_at` are absolute epoch seconds. Cache TTL
 * is set to the longer of the two so the refresh_token survives past the
 * access_token's expiry.
 */
class AccessTokenManager
{
    /** Treat the access token as needing renewal this many seconds before its real expiry. */
    const ACCESS_REFRESH_BUFFER_SECONDS = 60;

    /** Magento's file cache caps very long TTLs — clamp ours to 30 days. */
    const MAX_CACHE_TTL_SECONDS = 30 * 24 * 3600;

    const CACHE_PREFIX = 'paylater_access_token_';
    const HTTP_TIMEOUT_SECONDS = 30;

    const GRANT_CLIENT_CREDENTIALS = 'client_credentials';
    const GRANT_REFRESH_TOKEN = 'refresh_token';

    /**
     * @var CacheInterface
     */
    private $cache;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $apiConfig;

    /**
     * @var PayLaterHelper
     */
    private $helper;

    public function __construct(
        CacheInterface $cache,
        SpotiiApiConfigInterface $apiConfig,
        PayLaterHelper $helper
    ) {
        $this->cache = $cache;
        $this->apiConfig = $apiConfig;
        $this->helper = $helper;
    }

    /**
     * Returns a valid bearer token. The decision tree (in order):
     *   1. cached access_token valid for > 60s  → reuse
     *   2. cached refresh_token still valid     → refresh_token grant
     *   3. fall back to client_credentials grant
     *
     * @throws LocalizedException
     */
    public function getToken(bool $forceRefresh = false): string
    {
        $now = time();
        $cached = $forceRefresh ? null : $this->loadCached();

        if ($cached && $now < ($cached['expires_at'] - self::ACCESS_REFRESH_BUFFER_SECONDS)) {
            return (string) $cached['access_token'];
        }

        if ($cached && !empty($cached['refresh_token']) && $this->refreshStillValid($cached, $now)) {
            try {
                $fresh = $this->fetchByRefreshToken((string) $cached['refresh_token']);
                $this->saveCached($fresh);
                return $fresh['access_token'];
            } catch (LocalizedException $e) {
                $this->helper->logSpotiiActions(
                    '[auth] refresh_token grant failed, falling back to client_credentials: '
                    . $e->getMessage()
                );
            }
        }

        $fresh = $this->fetchByClientCredentials();
        $this->saveCached($fresh);
        return $fresh['access_token'];
    }

    /**
     * Drop the cached token. Called by Processor after a 401 response so the
     * next call goes through the decision tree from the top.
     */
    public function invalidate(): void
    {
        $this->cache->remove($this->cacheKey());
    }

    /**
     * @throws LocalizedException
     */
    private function fetchByClientCredentials(): array
    {
        $clientId = (string) $this->apiConfig->getClientId();
        $clientSecret = (string) $this->apiConfig->getClientSecret();
        if ($clientId === '' || $clientSecret === '') {
            throw new LocalizedException(__('PayLater Client ID / Client Secret not configured.'));
        }
        $body = http_build_query([
            'grant_type'    => self::GRANT_CLIENT_CREDENTIALS,
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
        ]);
        return $this->postTokenRequest($body, self::GRANT_CLIENT_CREDENTIALS);
    }

    /**
     * @throws LocalizedException
     */
    private function fetchByRefreshToken(string $refreshToken): array
    {
        $body = http_build_query([
            'grant_type'    => self::GRANT_REFRESH_TOKEN,
            'refresh_token' => $refreshToken,
            'client_id'     => (string) $this->apiConfig->getClientId(),
            'client_secret' => (string) $this->apiConfig->getClientSecret(),
        ]);
        return $this->postTokenRequest($body, self::GRANT_REFRESH_TOKEN);
    }

    /**
     * @throws LocalizedException
     */
    private function postTokenRequest(string $formBody, string $grantType): array
    {
        $url = $this->apiConfig->getAuthUrl();
        $this->helper->logSpotiiActions("[auth] → POST $url grant=$grantType");

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $formBody,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT        => self::HTTP_TIMEOUT_SECONDS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            $this->helper->logSpotiiActions("[auth] ← curl_error grant=$grantType: $curlError");
            throw new LocalizedException(__('PayLater auth connection failed: %1', $curlError));
        }

        $decoded = json_decode((string) $response, true);
        if (!is_array($decoded)) {
            $this->helper->logSpotiiActions("[auth] ← $httpCode grant=$grantType (unparseable body)");
            throw new LocalizedException(__('Unexpected PayLater auth response.'));
        }

        if (isset($decoded['error'])) {
            $detail = $decoded['error_description'] ?? $decoded['error'];
            $this->helper->logSpotiiActions("[auth] ← $httpCode grant=$grantType error=$detail");
            throw new LocalizedException(__('PayLater auth failed: %1', $detail));
        }

        if (empty($decoded['access_token'])) {
            $this->helper->logSpotiiActions("[auth] ← $httpCode grant=$grantType (no access_token)");
            throw new LocalizedException(__('PayLater auth: no access_token in response.'));
        }

        $envelope = $this->normalizeResponse($decoded);
        $this->helper->logSpotiiActions(sprintf(
            '[auth] ← %d grant=%s token acquired (expires_in=%ds, refresh_expires_in=%ds)',
            $httpCode,
            $grantType,
            isset($decoded['expires_in']) ? (int) $decoded['expires_in'] : 0,
            isset($decoded['refresh_expires_in']) ? (int) $decoded['refresh_expires_in'] : 0
        ));
        return $envelope;
    }

    /**
     * Normalise the gateway response into the canonical cache envelope.
     */
    private function normalizeResponse(array $decoded): array
    {
        $now = time();
        $expiresIn = isset($decoded['expires_in']) ? (int) $decoded['expires_in'] : 3600;
        $refreshExpiresIn = isset($decoded['refresh_expires_in']) ? (int) $decoded['refresh_expires_in'] : 0;

        return [
            'access_token'       => (string) $decoded['access_token'],
            'expires_at'         => $now + $expiresIn,
            'refresh_token'      => isset($decoded['refresh_token']) ? (string) $decoded['refresh_token'] : null,
            'refresh_expires_at' => $refreshExpiresIn > 0 ? $now + $refreshExpiresIn : 0,
        ];
    }

    private function refreshStillValid(array $cached, int $now): bool
    {
        // refresh_expires_at = 0 → gateway didn't tell us; assume usable until proven otherwise.
        return $cached['refresh_expires_at'] === 0
            || $now < ($cached['refresh_expires_at'] - self::ACCESS_REFRESH_BUFFER_SECONDS);
    }

    private function saveCached(array $envelope): void
    {
        $now = time();
        // Hold the envelope long enough that the refresh_token survives access expiry.
        $ttl = max($envelope['expires_at'], $envelope['refresh_expires_at']) - $now;
        if ($ttl <= 0) {
            $ttl = 60;
        }
        $ttl = min($ttl, self::MAX_CACHE_TTL_SECONDS);
        $this->cache->save(json_encode($envelope), $this->cacheKey(), [], $ttl);
    }

    private function loadCached(): ?array
    {
        $raw = $this->cache->load($this->cacheKey());
        if (!$raw) {
            return null;
        }
        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded) || empty($decoded['access_token']) || !isset($decoded['expires_at'])) {
            return null;
        }
        return $decoded;
    }

    private function cacheKey(): string
    {
        return self::CACHE_PREFIX . md5(
            (string) $this->apiConfig->getAuthUrl()
            . '|'
            . (string) $this->apiConfig->getClientId()
        );
    }
}
