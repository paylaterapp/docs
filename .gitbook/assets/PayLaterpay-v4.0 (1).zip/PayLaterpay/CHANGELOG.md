# Changelog

## 2.3.1 — 2026-06-02 — Dead-code purge

### 🗑 Removed (32 files + 14 empty dirs)

The v1-era Spotii marketing-widget infrastructure was still bundled even though it was no longer loaded by any layout or referenced by any active code path. Cleaned out:

**Block files** (3rd-party JS widget loaders for PDP/PLP/cart):
- `Block/SpotiiWidget/Cart.php`
- `Block/SpotiiWidget/Catalogue.php`
- `Block/SpotiiWidget/ProductView.php`

**Admin onboarding widget** (linked to the old `dashboard.paylaterapp.com/signup` register page):
- `Block/Adminhtml/System/Config/SpotiiRegisterAdmin.php`
- `Block/Adminhtml/System/Config/Form/SpotiiRegisterConfig.php`
- `Model/System/Config.php`
- `Model/System/Config/Source/MerchantCountry.php`
- `view/adminhtml/templates/system/config/spotii_register_admin.phtml`
- `view/adminhtml/web/js/config.js`

**Widget config container classes** (for the deleted block files):
- `Model/Config/Container/CartWidgetConfigInterface.php`
- `Model/Config/Container/CartWidgetIdentity.php`
- `Model/Config/Container/CatalogWidgetConfigInterface.php`
- `Model/Config/Container/CatalogWidgetIdentity.php`
- `Model/Config/Container/ProductWidgetConfigInterface.php`
- `Model/Config/Container/ProductWidgetIdentity.php`

**Widget config source models** (for never-active widget alignment/theme dropdowns):
- `Model/Config/Source/Product/ThemeAlignment.php`
- `Model/Config/Source/Product/WidgetAlignment.php`
- `Model/Config/Source/Product/WidthAlignment.php`

**Duplicate / orphan source models**:
- `Model/Config/Source/Payment/Mode.php` (duplicate of `PaymentMode.php`)
- `Model/Config/Source/Payment/PaymentAction.php` (only referenced from commented-out admin field)

**Orphaned observer**:
- `Observer/SetCaptureExpiryObserver.php` (referenced removed `PAYLATER_CAPTURE_EXPIRY` constant)

**Frontend widget templates + JS** (already neutered in earlier release):
- `view/frontend/templates/cart.phtml`, `catalog.phtml`, `product.phtml`
- `view/frontend/web/js/catalog-widget.js`, `paylater-widget.js`, `product-widget.js`
- `view/frontend/layout/catalog_category_view.xml`, `catalog_product_view.xml`, `checkout_cart_index.xml`
- `view/frontend/requirejs-config.js` (mapped to deleted JS aliases)

**Admin order template override** (last reference to the removed `SpotiiPay::PAYMENT_CODE` legacy constant pattern):
- `view/adminhtml/templates/order/invoice/create/items.phtml`

### 🔧 Config cleanup

- `etc/di.xml` — removed 3 dead widget interface preferences
- `etc/frontend/di.xml` — removed 1 dead widget preference
- `etc/frontend/events.xml` — removed `set_spotii_capture_expiry` observer registration (file is now just the empty config tag)
- `etc/adminhtml/system.xml` — removed:
  - `simplepath` field (Spotii register-link widget)
  - `merchant_id` field (no longer needed in v2 — derived from OAuth token)
  - commented-out `payment_action` field and its dead PaymentAction source reference
  - commented-out `xpath` / `renderXPath` legacy product-widget fields

### 🧹 Interface cleanup

- `SpotiiApiConfigInterface::getApiKey()` — **removed** (v1 X-Api-Key auth gone; no callers remain)
- `SpotiiApiConfigInterface::getMerchantId()` — **removed** (v2 derives merchant from OAuth token; no callers after widget purge)
- `SpotiiApiIdentity::XML_PATH_API_KEY` constant — removed
- `SpotiiApiIdentity::XML_PATH_MERCHANT_ID` constant — removed
- `SpotiiApiIdentity::getApiKey()` / `getMerchantId()` method bodies — removed

### 📊 Result

- File count: **89 → 57** (32 fewer files)
- Empty directories: **14 pruned**
- Module tree is now strictly v2 code paths + the user's PDP/PLP price renderers + checkout/webhook/refund/cron flow

### ⚠️ Migration notes

- Existing `payment/ppaylater/api_key` and `payment/ppaylater/merchant_id` rows in `core_config_data` are now orphaned (no code reads them, admin form no longer shows them). They cause no harm but can be cleaned up if desired:
  ```sql
  DELETE FROM core_config_data
  WHERE path IN ('payment/ppaylater/api_key', 'payment/ppaylater/merchant_id');
  ```
- The `set_spotii_capture_expiry` observer was already broken before this release (referenced removed class), so removing its registration changes no behaviour.

### ✅ What was kept (deliberately)

- `Block/Adminhtml/System/Config/Fieldset/Payment.php` — admin fieldset header styling for the PayLater payment config (still in use by `system.xml`)
- `Pricing/Render/{Catalog,ConfigurableProduct,Bundle}/PayLaterConfiguration.php` + `PayLaterConfigTrait.php` — used by your PDP/PLP price-render phtml (`view/base/templates/product/price/*/final_price.phtml`)
- `view/adminhtml/web/css/ppaylater.less` + `view/adminhtml/layout/adminhtml_system_config_edit.xml` — admin payment-method styling
- `view/adminhtml/web/images/spotiipay_logo.png` — admin payment-method logo
- All flow-critical files (Controllers, Cron, Webhook, Helper, Observer/MethodAvailabilityObserver, Observer/SalesOrderPlaceBefore)

---

## 2.3.0 — 2026-05-18 — **API v2 migration**

⚠️ **Breaking change** for the integration contract with PayLater. Auth scheme and all endpoints have moved.

### 🔐 Auth

- **OAuth2 client credentials** replace the static `X-Api-Key` header.
- New `Model\Api\AccessTokenManager` fetches access tokens from `<host>/auth/realms/api/protocol/openid-connect/token` and caches them for 3500s (just under the gateway's 3599s expiry).
- Tokens are stored in Magento's `CacheInterface`; cache key includes a hash of `auth_url + client_id` so switching environment or rotating credentials invalidates automatically.
- `Authorization: Bearer <token>` is now added to every API call.
- On 401 from any downstream call, `Processor` invalidates the cached token, refreshes once, and retries exactly once — handles token rotation transparently.
- Auth flow is logged with the `[auth]` prefix; the token value itself is never logged.

### 🌐 Endpoint changes (all moved to `/v2/`)

| Action | v1 (old) | v2 (new) |
|---|---|---|
| Generate payment link | `POST .../web-checkout/` | `POST .../v2/web-checkout` |
| Check status | `GET .../web-checkout/status?orderId=&merchantId=` | `GET .../v2/web-checkout/status?order_id=` |
| Full refund | `GET .../web-checkout/refund?merchantId=&transactionReference=&transactionType=DOWN_PAYMENT` | `POST .../v2/web-checkout/refund` with `{order_id}` |
| Partial refund | `POST .../web-checkout/refund/partial?merchantId=&transactionReference=` body `{amount}` | `POST .../v2/web-checkout/refund` with `{order_id, amount}` |

Note: full and partial refunds now hit the same endpoint; presence of `amount` makes it partial.

### 📦 Payload changes (snake_case + reshape)

`buildCheckoutPayload()` now produces:
```json
{
  "outlet_id": 1000000594,
  "currency": "QAR",
  "amount": 350.00,
  "order_id": "57-3446",
  "success_redirect_url": "https://...",
  "fail_redirect_url": "https://...",
  "expiry_duration": 10
}
```
- All field names changed from `camelCase` to `snake_case`
- `merchantId` removed — derived from the OAuth client at the gateway
- New `expiry_duration` field (minutes) controls how long the payment link is valid; default is 10

### ⚙️ Admin config changes

- **Removed**: `API Key` field (v1, no longer used).
- **Added**: `Client ID` (text, required when active) — OAuth2 client identifier such as `merchant-815`.
- **Added**: `Client Secret` (obscure/encrypted, required when active).
- `Merchant ID` field is now **informational only** — kept on the form for reference but no longer required (the v2 API derives merchant from the OAuth token).
- `Outlet ID` still required when active.
- `Webhook Secret` unchanged.

### 🛠 Internal

- `ProcessorInterface::call($url, $apiKey, $body, $method)` simplified to `call($url, $body, $method)` — auth is handled internally by `AccessTokenManager`.
- `Observer\MethodAvailabilityObserver` now checks `client_id` + `client_secret` + `outlet_id` (instead of `api_key` + `merchant_id` + `outlet_id`). If any of the three is missing, the payment method is hidden at checkout.
- `SpotiiApiConfigInterface` gains `getClientId()`, `getClientSecret()`, `getAuthUrl()`. Old `getApiKey()` and `getMerchantId()` kept for backward compatibility (return whatever value is in the legacy DB rows, including empty).

### 🚀 Deploy + migration

```bash
unzip PayLater_PayLaterpay-2.3.0.zip -d <magento_root>/app/code/PayLater/
cd <magento_root>
bin/magento setup:upgrade
bin/magento setup:di:compile         # AccessTokenManager added; Processor/ProcessorInterface signatures changed
bin/magento setup:static-content:deploy -f
bin/magento cache:flush
sudo systemctl reload php-fpm        # bytecode cache
```

After deploy, admin:
1. *Stores → Configuration → Sales → Payment Methods → PayLater*
2. Fill **Client ID** and **Client Secret** (issued by PayLater)
3. **Save Config**, `bin/magento cache:flush`
4. Place a UAT order → tail `var/log/ppaylater.log`:
   ```
   [auth] → POST .../auth/realms/api/protocol/openid-connect/token client_id=merchant-815
   [auth] ← 200 token acquired (expires_in=3599s)
   [gw] → POST .../v2/web-checkout body={...}
   [gw] ← 200 {"paymentLinkUrl":"..."}
   ```

### 🧪 Test plan additions

1. **Token caching**: place two orders within a minute; first triggers `[auth]` call, second doesn't (token cached).
2. **Token refresh on 401**: force-invalidate the token cache (clear cache) — next call shows `[auth]` call before `[gw] →`.
3. **Wrong credentials**: enter a bogus `Client Secret`, place an order → `[auth] ← 401 error=invalid_client...` and the order is created in pending_payment then cancelled by `processFailedPayment` (gateway start fails).
4. **Full refund**: works as before; verify request is `POST .../v2/web-checkout/refund` with body `{"order_id":"..."}`.
5. **Partial refund**: works as before; verify request body is `{"order_id":"...","amount":"39.00"}`.

⚠️ **Compliance check**: OAuth2 client credentials and bearer token caching change the auth threat model. Worth a quick InfoSec sign-off on the token cache (location, encryption, TTL). Magento's default file cache stores the token in plaintext on disk under `var/cache/`; if your environment requires at-rest encryption for OAuth tokens, swap to Redis with encryption-at-rest or wrap the `CacheInterface` save/load in `EncryptorInterface`.

---

## 2.2.3 — 2026-05-13

### 🪵 Logging slimmed down

The old `Model\Api\Processor` dumped full curl_info, response headers, TLS verbose output, and a reconstructable curl command for every gateway call — useful once for integration, pure noise after. The new format is two lines per call:

```
[gw] → POST https://connect.uat.paylaterapp.com/.../web-checkout/ body={"merchantId":"815","amount":329.20,...}
[gw] ← 200 {"paymentLinkUrl":"https://payments.uat.paylaterapp.com/paylink/..."}
```

That's it. Status code, URL, request body, response body. Enough to investigate any issue, nothing more.

- **Removed**: `****API KEY****` + plaintext key line (security/PDPL), `****Request Info****` block, `****CURL Request Details****` reconstructable curl command, `****Response Info****` block with response headers + curl_info + verbose_log dump.
- **Added**: single-line `[gw] →` request log, single-line `[gw] ←` response log (response body truncated to 1000 chars).
- **Removed duplicate**: `[refund] FULL/PARTIAL → / ←` lines in `SpotiiPay::refundPayment` and `refundPartialPayment` — the new `[gw]` lines cover request/response uniformly. The high-level `[refund] ENTER` / `[refund] OK` / `[refund] FAILED` markers remain.

### 🔒 Security / privacy

- API key value is no longer logged. Previously `Processor::call()` wrote *"Using API Key: c9bd9b8c-af46-4a03-9089-50eb6378968e"* in plaintext to `var/log/ppaylater.log`. The X-Api-Key header is set on every request (implicit) but never logged.
- Log entries are now significantly shorter — easier to scan, less expensive to ship to log aggregators, less to redact if logs ever leave the merchant's infrastructure.

### How to grep

| To find | grep pattern |
|---|---|
| All gateway HTTP traffic | `grep '\[gw\]' var/log/ppaylater.log` |
| Just gateway failures | `grep '\[gw\] ← [45]' var/log/ppaylater.log` |
| Refund flow markers | `grep '\[refund\]' var/log/ppaylater.log` |
| Webhook activity | `grep '\[webhook\]' var/log/ppaylater.log` |
| Cron activity | `grep '\[cron\]' var/log/ppaylater.log` |
| Order settlements | `grep 'Settled order' var/log/ppaylater.log` |

---

## 2.2.2 — 2026-05-13

### 🛠 Fixes — admin credential validation

**`API Key`, `Merchant ID`, `Outlet ID` are now required when PayLater is active.**
- Admin can no longer save *Stores → Configuration → Sales → Payment Methods → PayLater* with `active = Yes` and any of these three fields blank. Save is rejected with a clear error: *"&lt;Field Label&gt; is required when PayLater is enabled."*
- Validation only runs when the payment method is being saved as active. Admin can still disable the method (`active = No`) without being forced to fill credentials.
- Two new backend validators:
  - `Model\Config\Backend\RequiredWhenActive` — plain text fields (`merchant_id`, `outlet_id`).
  - `Model\Config\Backend\RequiredEncryptedWhenActive` — extends `Magento\Config\Model\Config\Backend\Encrypted`, used for `api_key`. Preserves the standard "asterisks placeholder = no change" behaviour so admin doesn't have to re-paste the secret on every save.
- Together with the `price_range >= 300` validator from 2.2.1, the admin form now refuses any configuration that would lead to a broken runtime state.

### 📋 Admin field validation summary

| Field | Behaviour |
|---|---|
| `API Key` | Required when active; encrypted; "***" placeholder preserves old value |
| `Merchant ID` | Required when active |
| `Outlet ID` | Required when active |
| `Minimum Order Amount` (price_range) | Must be ≥ 300; non-numeric rejected; empty falls back to default 300 |
| `Webhook Secret` | Optional; webhook receiver returns 403 if missing |
| `Sort Order` | `validate-number` (frontend) |

---

## 2.2.1 — 2026-05-13

### 🛠 Fixes

**Admin-side enforcement of the QAR 300 minimum order amount**
- New backend validator `PayLater\PayLaterpay\Model\Config\Backend\PriceRange` runs when admin saves *Stores → Configuration → Sales → Payment Methods → PayLater → Minimum Order Amount*.
- Values below 300 are now rejected at save time with a clear error: *"Minimum Order Amount cannot be less than 300."*
- Non-numeric values are rejected as *"Minimum Order Amount must be a number."*
- Empty input is allowed and falls back to the config.xml default (300).
- The runtime check in `isAvailable()` is unchanged (still hard-coded floor of 300) — the admin validator is belt-and-braces so the admin UI never shows a misleading value lower than the runtime floor.
- Frontend HTML5 validation added (`validate-number validate-greater-than-zero`) for immediate browser-side feedback before the post.

---

## 2.2.0 — 2026-05-04

### 🆕 Features

**Online refunds**
- Admins can now issue online refunds from the credit memo screen. Magento calls PayLater's gateway directly — no manual reversal needed.
- Both **full** and **partial** refunds supported; routing is automatic based on the credit memo amount:
  - Full (amount equals order total) → `GET <base>/web-checkout/refund?merchantId=&transactionReference=&transactionType=DOWN_PAYMENT`
  - Partial (amount less than order total) → `POST <base>/web-checkout/refund/partial?merchantId=&transactionReference=` with `{"amount":<n>}`
- `transactionReference` for both endpoints is the Magento order increment id.
- Multiple partial refunds per order are allowed up to the original total. Magento's framework prevents over-refunding.
- The gateway's response message is recorded as a status history comment on the order ("PayLater refund initiated. Gateway: …").

**Webhook receiver**
- New public endpoint `POST <base>/ppaylater/webhook/notify` for PayLater's server-to-server callbacks. Settles or cancels orders within seconds of payment, instead of waiting for the browser redirect or the cron.
- New admin field **Stores → Configuration → Sales → Payment Methods → PayLater → Webhook Secret** (stored encrypted, same as the API key).
- Signature validation per PayLater's spec: `md5(strtoupper(merchantId+orderId+status+timestamp+comments))` must match `txHash`, then `hmac_sha256(txHash, secret)` must match `signature`. Both checks use timing-safe `hash_equals`.
- CSRF-exempt endpoint (server-to-server contract; no Magento form key available to the gateway).
- Rejects bad signature with `403 Invalid signature`. Logs both successful and rejected attempts under `[webhook]` prefix.

### 🛠 Fixes

**"Refund Online" button now appears on credit memos** (was: only "Refund Offline" was shown)
- `processSuccessfulPayment()` now calls `Payment::registerCaptureNotification()` instead of building the invoice with `CAPTURE_OFFLINE`. This writes a proper `TYPE_CAPTURE` row in `sales_payment_transaction` and populates the invoice's `transaction_id` field — exactly what Magento's credit memo screen checks before showing the online refund button.
- Note: the fix only affects orders settled **after** deploy. Orders settled before this release have the old offline-only invoice; refund those manually via PayLater's dashboard if needed.

**Removed legacy `SavePlugin` causing fatal exceptions**
- The old `Plugin/Sales/Controller/Adminhtml/Order/Invoice/SavePlugin.php` referenced constants and methods (`PAYLATER_CAPTURE_EXPIRY`, `spotiiCapture()`) that were removed in 2.1.0's order-flow refactor. It was throwing `Undefined constant` on every admin invoice save.
- The plugin re-implemented Magento's invoice-save controller for an authorize-then-capture-later flow that this module no longer uses. With `_isInitializeNeeded = true` and `registerCaptureNotification`, the gateway captures up-front and Magento settles via webhook / Complete / cron — no admin-driven gateway capture is needed.
- Plugin file, its `addCaptureErrorMessage` template and renderer config, and the dead `view/adminhtml/templates/order/view/info.phtml` capture-expiry override have all been deleted.

### 🪵 Logging improvements
- Refund flow now logs every step explicitly under the `[refund]` prefix:
  - `[refund] ENTER order=… requested=… grandTotal=… mode=FULL|PARTIAL`
  - `[refund] FULL  → GET <url>` / `[refund] PARTIAL → POST <url> body=…`
  - `[refund] FULL  ← <response>` / `[refund] PARTIAL ← <response>`
  - `[refund] OK <ref>: <gateway message>` on success
  - `[refund] FAILED for <ref>: <error>` on gateway error
- Webhook flow logs under `[webhook]` prefix:
  - `[webhook] received orderId=… status=… paylaterRef=…`
  - `[webhook] signature mismatch for orderId=…`
  - `[webhook] no webhook secret configured — refusing`

### 🗑 Deleted
- `Plugin/Sales/Controller/Adminhtml/Order/Invoice/SavePlugin.php` and the now-empty `Plugin/` directory tree.
- `view/adminhtml/templates/messages/addCaptureErrorMessage.phtml`.
- `view/adminhtml/templates/order/view/info.phtml`.
- Plugin and message-renderer config from `etc/adminhtml/di.xml`.

### 📦 Compatibility
- No DB schema changes. `setup_version` unchanged at `2.0.0`.
- `Model\SpotiiPay` constructor signature unchanged from 2.1.0.
- New methods added to `SpotiiApiConfigInterface` (`getWebhookSecret()`) — implementing classes need to add the method. Stock implementation (`SpotiiApiIdentity`) is updated.

### 🚀 Deploy
```bash
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento setup:static-content:deploy -f
bin/magento cache:flush
sudo systemctl reload php-fpm   # (or restart Apache) — clears OPcache so new code is picked up
```

### 🧪 Test plan additions
1. **Online refund (full)**: place fresh order ≥ QAR 300, complete payment, wait 10 minutes, admin → invoice → Credit Memo → **Refund Online** with full quantities. Expect `[refund] FULL` log block and gateway response.
2. **Online refund (partial)**: same flow but adjust Qty to Refund / Update Qty's so amount is less than total → click **Refund Online** → expect `[refund] PARTIAL → POST … body={"amount":…}`.
3. **Webhook self-test**: with a valid secret in admin and an existing pending order, POST a properly-signed payload to `/ppaylater/webhook/notify` (sample script in this conversation history). Expect `200` and `[webhook] received` line.
4. **Tampered webhook**: POST with wrong signature → expect `403` and `[webhook] signature mismatch`.
5. **Old order regression**: confirm orders settled before 2.2.0 still show "Refund Offline" only (expected — they don't have a TYPE_CAPTURE record).

### 🔁 Migration notes for existing 2.1.0 stores
- After deploy, existing pending_payment orders are still cleaned up by the cron the same way.
- Existing fully-settled orders from 2.1.0 keep their offline-only credit memo behaviour. New orders going forward get the online-refund-capable flow.
- If you provide PayLater with the new webhook URL + secret, paste the secret into the new admin field and flush cache. Until then, the redirect + cron continue to handle settlement (no functional gap).

⚠️ **Compliance flag**: this release introduces a server-to-server webhook receiving order data and an automated refund call to a PayLater endpoint. Worth a quick review by InfoSec on the webhook signature scheme and by Legal/DPO on the refund automation flow (especially for partial refunds — confirm with PayLater Compliance that issuing a partial refund mid-installments is acceptable behaviour under the BNPL contract).

---

## 2.1.0 — 2026-04-27

### Environment
- **UAT endpoint**: `payment_mode = uat` now points to `https://connect.uat.paylaterapp.com/api/paylater/merchant-portal/` (was `connect-sandbox.paylaterapp.com`). Existing stores with the old saved value need to re-pick "UAT" in admin or run:
  ```sql
  UPDATE core_config_data
  SET value = 'uat'
  WHERE path = 'payment/ppaylater/payment_mode' AND value = 'sandbox';
  ```

### Order flow refactor (redirect-payment pattern)
- Order is now created in `pending_payment` state **before** the shopper is sent to the gateway, then settled (or cancelled) on return.
- `Model\SpotiiPay`: `$_isInitializeNeeded = true`; new `initialize()` pins state to pending_payment so submit() doesn't auto-authorize.
- New idempotent helpers `processSuccessfulPayment(Order, $reference, $gatewayTxnId)` and `processFailedPayment(Order, $reason)` — safe to call from the Complete controller, the Cancel controller, and the reconcile cron.

### Reconciliation cron (safety net)
- New `Cron\ReconcilePendingOrders` runs every 10 minutes.
- For each `pending_payment` ppaylater order older than 3 minutes, calls `web-checkout/status?orderId=<incrementId>` and acts on the response:
  - `status = 2` (success) → settle
  - `status = 3` (failed) → cancel
  - `status = 1` (pending) and order older than 24 h → cancel as abandoned
- Removed the old broken cron jobs that referenced missing `MerchantData` and `InventoryWorker` classes.

### Transaction id
- Magento's `transaction_id` (and invoice transaction id, last_trans_id) is now set to PayLater's own `payLaterOrderId` (e.g. `PL1744792493935483`) instead of the local Magento increment id. The increment id is preserved separately as `ppaylater_order_id` on payment additional info for reconciliation lookups.
- Order status history comment now reads: *"PayLater payment confirmed. Transaction: PL... (merchant ref: 000072152)"*.

### Bug fixes
- **Success message**: `Complete.php` was using PHP backticks (`shell_exec`) for the success message — replaced with `__('...')`. Success message now actually displays.
- **Amount precision**: gateway payload was casting grand total to `int` before rounding, dropping cents (QAR 19.99 → 19). Now `(float)`.
- **Status comparison**: strict-compare `!== 2` would fail if the gateway returned `"2"` as a string. Now casts to `int` first.
- **Amount tampering check**: `isOrderAmountMatched()` was a no-op `return true`. Now does a real currency match plus 0.01-tolerance amount comparison.
- **Inventory check**: `CheckInventory.php` had no input validation and double-encoded its JSON response (Magento's `Json::setData()` re-encodes its argument). Now validates input and returns clean JSON.
- **Email validation**: guest checkout in `Redirect.php` was setting customer email without `filter_var(..., FILTER_VALIDATE_EMAIL)`. Now validates.
- **Gateway error envelope**: `getOrderInfo()` now detects `{"error": "Order ID is required"}` responses and throws a clean `LocalizedException` instead of treating them as "still pending".
- **Observer string match**: `SalesOrderPlaceBefore` was comparing against `"spotiipay"` instead of `"ppaylater"`, so the observer never fired and order-confirmation emails weren't suppressed at order creation. Fixed; emails are now sent only after payment success.

### Security / privacy
- **Removed all 3rd-party JS loads** from the checkout page:
  - `widget.spotii.me/v1/javascript/iframe-lightbox.{js,css}` (was loaded by the payment renderer)
  - `mindmup.github.io/3rdpartycookiecheck/start.html` (was used as a 3rd-party cookie probe)
  - `widget.spotii.me/v1/javascript/spotii-catalog-widget.js` (was loaded by `catalog-widget.js`)
- The checkout JS is now ~50 lines instead of ~480, and uses a simple top-level `window.location.assign()` redirect — no iframe, no popup, no globals on `window`.
- **PII in logs**: removed `logSpotiiActions(json_encode($quote))` which was writing full quote objects (customer email, addresses) to `/var/log/ppaylater.log`. Relevant under PDPL.
- **Hardcoded inconsistent threshold**: removed the JS-side `isTotalValid()` (200 USD / 20 BHD/OMR/KWD with hardcoded FX `total * 3.6730`). The server-side QAR 300 floor is now the single source of truth.

### Cleanup
- Removed `.DS_Store` files (25 of them).
- Removed obsolete `.git` directory from the production zip.
- Removed dead progress-bar HTML and inline base-64 SVG payload from the checkout template.

### Compatibility
- No DB schema changes. `setup_version` unchanged at `2.0.0`.
- Constructor signature changed on `Model\SpotiiPay` (drops several unused dependencies, adds `InvoiceService`, `DbTransaction`, `OrderSender`, `InvoiceSender`). **`bin/magento setup:di:compile` is required** after deploy.

### Deploy
```
bin/magento module:enable PayLater_PayLaterpay
bin/magento setup:upgrade
bin/magento setup:di:compile
bin/magento setup:static-content:deploy -f
bin/magento cache:flush
```
