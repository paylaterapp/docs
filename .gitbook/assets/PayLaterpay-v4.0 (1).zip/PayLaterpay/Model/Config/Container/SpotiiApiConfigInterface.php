<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Container;

use Magento\Store\Model\Store;

/**
 * Interface IdentityInterface
 * @package PayLater\PayLaterpay\Model\Config\Container
 */
interface SpotiiApiConfigInterface
{
    /**
     * Check if payment method is enabled
     * @return bool
     */
    public function isEnabled();

    /**
     * Get OAuth2 Client ID
     * @return string|null
     */
    public function getClientId();

    /**
     * Get OAuth2 Client Secret
     * @return string|null
     */
    public function getClientSecret();

    /**
     * Get OAuth2 token endpoint URL
     * @return string
     */
    public function getAuthUrl();

    /**
     * Get Webhook Secret used to verify PayLater webhook signatures.
     * @return string|null
     */
    public function getWebhookSecret();

    /**
     * Get Outlet ID
     * @return string
     */
    public function getOutletId();

    /**
     * Get Payment Mode (uat/live)
     * @return string
     */
    public function getPaymentMode();

    /**
     * Get Base URL for API (e.g. https://connect.uat.paylaterapp.com/api/paylater/merchant-portal/).
     * @return string
     */
    public function getSpotiiBaseUrl();

    /**
     * Get if logging is enabled
     * @return bool
     */
    public function isLogEnabled();
}
