<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Container;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class SpotiiApiIdentity
 * @package PayLater\PayLaterpay\Model\Config\Container
 */
class SpotiiApiIdentity extends Container implements SpotiiApiConfigInterface
{
    const XML_PATH_PAYMENT_ACTIVE = 'payment/ppaylater/active';
    const XML_PATH_CLIENT_ID = 'payment/ppaylater/client_id';
    const XML_PATH_CLIENT_SECRET = 'payment/ppaylater/client_secret';
    const XML_PATH_PAYMENT_MODE = 'payment/ppaylater/payment_mode';
    const XML_PATH_OUTLET_ID = 'payment/ppaylater/outlet_id';
    const XML_PATH_LOG_ENABLED = 'payment/ppaylater/log_tracker';
    const XML_PATH_WEBHOOK_SECRET = 'payment/ppaylater/webhook_secret';

    private $apiUrlLive  = 'https://connect.paylaterapp.com/api/paylater/merchant-portal/';
    private $apiUrlUat   = 'https://connect.uat.paylaterapp.com/api/paylater/merchant-portal/';
    private $authUrlLive = 'https://connect.paylaterapp.com/auth/realms/api/protocol/openid-connect/token';
    private $authUrlUat  = 'https://connect.uat.paylaterapp.com/auth/realms/api/protocol/openid-connect/token';

    /**
     * @var EncryptorInterface
     */
    private $encryptor;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param EncryptorInterface $encryptor
     */
    public function __construct(
        ScopeConfigInterface  $scopeConfig,
        StoreManagerInterface $storeManager,
        EncryptorInterface    $encryptor
    ) {
        $this->encryptor = $encryptor;
        parent::__construct($scopeConfig, $storeManager);
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_PAYMENT_ACTIVE,
            ScopeInterface::SCOPE_STORE,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getWebhookSecret()
    {
        $encrypted = $this->getConfigValue(
            self::XML_PATH_WEBHOOK_SECRET,
            $this->getStore()->getStoreId()
        );
        return $encrypted ? $this->encryptor->decrypt($encrypted) : null;
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getOutletId()
    {
        return $this->getConfigValue(
            self::XML_PATH_OUTLET_ID,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getClientId()
    {
        return $this->getConfigValue(
            self::XML_PATH_CLIENT_ID,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getClientSecret()
    {
        $encrypted = $this->getConfigValue(
            self::XML_PATH_CLIENT_SECRET,
            $this->getStore()->getStoreId()
        );
        return $encrypted ? $this->encryptor->decrypt($encrypted) : null;
    }

    /**
     * @inheritdoc
     */
    public function getAuthUrl()
    {
        return $this->getPaymentMode() === 'uat'
            ? $this->authUrlUat
            : $this->authUrlLive;
    }

    /**
     * @inheritdoc
     */
    public function getSpotiiBaseUrl()
    {
        return $this->getPaymentMode() === 'uat'
            ? $this->apiUrlUat
            : $this->apiUrlLive;
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function getPaymentMode()
    {
        return $this->getConfigValue(
            self::XML_PATH_PAYMENT_MODE,
            $this->getStore()->getStoreId()
        );
    }

    /**
     * @inheritdoc
     * @throws NoSuchEntityException
     */
    public function isLogEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_LOG_ENABLED,
            ScopeInterface::SCOPE_STORE,
            $this->getStore()->getStoreId()
        );
    }
}
