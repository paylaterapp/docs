<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Framework\Exception\LocalizedException;
use PayLater\PayLaterpay\Helper\Data as SpotiiHelper;

/**
 * Authenticated HTTP client for PayLater v2 API.
 *
 * Logging policy (when "Enable Logging" is on):
 *   [gw] → POST <url> body=<json>
 *   [gw] ← <httpCode> <body>
 *
 * Auth: bearer token fetched and cached by AccessTokenManager. On a 401
 * response, we invalidate the cached token, refresh once, and retry the
 * call exactly one more time. Failures still raise LocalizedException so
 * the caller sees the gateway's error message.
 */
class Processor implements ProcessorInterface
{
    const RESPONSE_LOG_LIMIT = 1000;
    const HTTP_TIMEOUT_SECONDS = 80;

    /**
     * @var SpotiiHelper
     */
    protected $spotiiHelper;

    /**
     * @var AccessTokenManager
     */
    protected $tokenManager;

    public function __construct(
        SpotiiHelper $spotiiHelper,
        AccessTokenManager $tokenManager
    ) {
        $this->spotiiHelper = $spotiiHelper;
        $this->tokenManager = $tokenManager;
    }

    /**
     * @inheritdoc
     */
    public function call($url, $body = null, $method = 'GET')
    {
        return $this->doCall((string) $url, $body, (string) $method, false);
    }

    /**
     * @throws LocalizedException
     */
    private function doCall(string $url, $body, string $method, bool $isRetry)
    {
        $encodedBody = (is_array($body) && $body !== []) ? json_encode($body, JSON_UNESCAPED_SLASHES) : null;
        $token = $this->tokenManager->getToken();

        if ($this->spotiiHelper->isLogEnabled()) {
            $this->spotiiHelper->logSpotiiActions(sprintf(
                '[gw] → %s %s%s',
                strtoupper($method),
                $url,
                $encodedBody !== null ? ' body=' . $encodedBody : ''
            ));
        }

        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Bearer ' . $token,
            'User-Agent: PayLater-Magento/1.0',
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => self::HTTP_TIMEOUT_SECONDS,
            CURLOPT_USERAGENT      => 'PayLater-Magento/1.0',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        if (strtoupper($method) === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($encodedBody !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedBody);
            }
        }

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($this->spotiiHelper->isLogEnabled()) {
            $shown = $response === false
                ? 'curl_error=' . $curlError
                : substr((string) $response, 0, self::RESPONSE_LOG_LIMIT);
            $this->spotiiHelper->logSpotiiActions(sprintf('[gw] ← %d %s', $httpCode, $shown));
        }

        if ($response === false) {
            throw new LocalizedException(__('Gateway connection error: %1', $curlError));
        }

        // 401 → token expired/rotated. Refresh once and retry exactly once.
        if ($httpCode === self::UNAUTHORIZED && !$isRetry) {
            $this->spotiiHelper->logSpotiiActions('[gw] 401 — refreshing token and retrying');
            $this->tokenManager->invalidate();
            return $this->doCall($url, $body, $method, true);
        }

        if ($httpCode >= 400) {
            $decoded = json_decode((string) $response, true);
            $errorMessage = is_array($decoded) && isset($decoded['error'])
                ? (string) $decoded['error']
                : (string) $response;
            throw new LocalizedException(__('%1', $errorMessage));
        }

        return $response;
    }
}
