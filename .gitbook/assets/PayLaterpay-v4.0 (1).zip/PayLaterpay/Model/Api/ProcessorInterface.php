<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

interface ProcessorInterface
{
    const BAD_REQUEST = 400;
    const UNAUTHORIZED = 401;

    /**
     * Make an authenticated call to the PayLater gateway. The bearer token is
     * fetched and managed internally by AccessTokenManager.
     *
     * @param string $url
     * @param array|null $body
     * @param string $method GET|POST
     * @return string Response body
     */
    public function call($url, $body = null, $method = 'GET');
}
