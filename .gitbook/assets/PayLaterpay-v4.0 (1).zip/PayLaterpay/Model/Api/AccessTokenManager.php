<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Exception;
use Magento\Framework\App\CacheInterface;
use Magento\Framework\Exception\LocalizedException;
use PayLater\PayLaterpay\Helper\Data as PayLaterHelper;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

/**
 * Fetches and caches OAuth2 access tokens for the PayLater API.
 *
 * Token endpoint: POST <host>/auth/realms/api/protocol/openid-connect/token
 *   Content-Type: application/x-www-form-urlencoded
 *   Body: grant_type=client_credentials&client_id=<id>&client_secret=<secret>
 *
 * Response (success): {"access_token":"ey...","expires_in":3599,"token_type":"Bearer",...}
 * Response (failure): {"error":"invalid_client","error_description":"..."}
 *
 * Tokens live ~1 hour; we cache for slightly less (CACHE_LIFETIME) to avoid
 * a race against expiry. On 401 from a downstream API call, Processor calls
 * invalidate() and re-fetches.
 */
class AccessTokenManager
{
    const CACHE_PREFIX = 'paylater_access_token_';
    const CACHE_LIFETIME = 3500;    // a touch under the gateway's 3599 default
    const HTTP_TIMEOUT_SECONDS = 30;

    /**
     * @var CacheInterface
     */
    private $cache;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $apiConfig;

    /**
     * @var PayLaterHelper
     */
    private $helper;

    public function __construct(
        CacheInterface $cache,
        SpotiiApiConfigInterface $apiConfig,
        PayLaterHelper $helper
    ) {
        $this->cache = $cache;
        $this->apiConfig = $apiConfig;
        $this->helper = $helper;
    }

    /**
     * Returns a valid bearer token. Reads cache first; only hits the gateway
     * on cache miss or when $forceRefresh is true (used after a 401).
     *
     * @throws LocalizedException
     */
    public function getToken(bool $forceRefresh = false): string
    {
        $cacheKey = $this->cacheKey();
        if (!$forceRefresh) {
            $cached = $this->cache->load($cacheKey);
            if ($cached) {
                return (string) $cached;
            }
        }

        $token = $this->fetchToken();
        $this->cache->save($token, $cacheKey, [], self::CACHE_LIFETIME);
        return $token;
    }

    /**
     * Drop the cached token. Called by Processor after a 401 so the next
     * call refreshes.
     */
    public function invalidate(): void
    {
        $this->cache->remove($this->cacheKey());
    }

    /**
     * @throws LocalizedException
     */
    private function fetchToken(): string
    {
        $clientId = (string) $this->apiConfig->getClientId();
        $clientSecret = (string) $this->apiConfig->getClientSecret();
        if ($clientId === '' || $clientSecret === '') {
            throw new LocalizedException(
                __('PayLater Client ID / Client Secret not configured.')
            );
        }

        $url = $this->apiConfig->getAuthUrl();
        $body = http_build_query([
            'grant_type'    => 'client_credentials',
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
        ]);

        $this->helper->logSpotiiActions("[auth] → POST $url client_id=$clientId");

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT        => self::HTTP_TIMEOUT_SECONDS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            $this->helper->logSpotiiActions("[auth] ← curl_error=$curlError");
            throw new LocalizedException(__('PayLater auth connection failed: %1', $curlError));
        }

        $decoded = json_decode((string) $response, true);
        if (!is_array($decoded)) {
            $this->helper->logSpotiiActions("[auth] ← $httpCode (unparseable body)");
            throw new LocalizedException(__('Unexpected PayLater auth response.'));
        }

        if (isset($decoded['error'])) {
            $detail = $decoded['error_description'] ?? $decoded['error'];
            $this->helper->logSpotiiActions("[auth] ← $httpCode error=$detail");
            throw new LocalizedException(__('PayLater auth failed: %1', $detail));
        }

        if (empty($decoded['access_token'])) {
            $this->helper->logSpotiiActions("[auth] ← $httpCode (no access_token)");
            throw new LocalizedException(__('PayLater auth: no access_token in response.'));
        }

        $expires = isset($decoded['expires_in']) ? (int) $decoded['expires_in'] : self::CACHE_LIFETIME;
        $this->helper->logSpotiiActions("[auth] ← $httpCode token acquired (expires_in={$expires}s)");
        return (string) $decoded['access_token'];
    }

    private function cacheKey(): string
    {
        return self::CACHE_PREFIX . md5(
            (string) $this->apiConfig->getAuthUrl()
            . '|'
            . (string) $this->apiConfig->getClientId()
        );
    }
}
