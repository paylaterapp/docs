<?php
/**
 * PayLater Pro - Process Payment (v2)
 *
 * Posts to the v2 web-checkout endpoint using a Bearer access token.
 * On a 401 response the cached token is invalidated and the call retried once.
 */

defined( 'ABSPATH' ) || exit;

function processPaylaterPayment( $order_id, $th, $addon ) {
    $order = wc_get_order( $order_id );

    if ( ! $order ) {
        return array(
            'result'   => 'failure',
            'messages' => __( 'Invalid Order ID.', 'paylater' ),
        );
    }

    $currency = $order->get_currency();
    $total    = (float) $order->get_total();
    $min      = (float) $th->order_min;

    try {
        if ( $total < $min ) {
            throw new Exception( sprintf(
                __( 'The minimum order amount for PayLater is %1$s %2$s.', 'paylater' ),
                $min,
                $currency
            ) );
        }

        // Unique transaction reference for this attempt. The time() suffix prevents
        // the gateway from rejecting the same orderId on a retry after a failure.
        $unique_ref = $order_id . '_' . time();

        $payload = array(
            'outlet_id'            => is_numeric( $th->outletId ) ? (int) $th->outletId : (string) $th->outletId,
            'currency'             => $currency,
            'amount'               => $total,
            'order_id'             => $unique_ref,
            'success_redirect_url' => add_query_arg(
                array(
                    'wc-api'  => $addon,
                    'o'       => $order_id,
                    's'       => 's',
                    'orderId' => $unique_ref,
                ),
                home_url( '/' )
            ),
            'fail_redirect_url'    => add_query_arg(
                array(
                    'wc-api'  => $addon,
                    'o'       => $order_id,
                    's'       => 'f',
                    'orderId' => $unique_ref,
                ),
                home_url( '/' )
            ),
            'expiry_duration'      => (int) $th->paymentExpiryMinutes,
        );

        $order->update_meta_data( '_paylater_unique_ref', $unique_ref );
        $order->save();

        $response = paylater_post_with_bearer( $th, $th->api, $payload );

        if ( is_wp_error( $response ) ) {
            throw new Exception( $response->get_error_message() );
        }

        $response_body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( is_array( $response_body ) && ! empty( $response_body['paymentLinkUrl'] ) ) {
            $order->update_meta_data( '_paylater_link', $response_body['paymentLinkUrl'] );
            $order->update_status( 'pending', __( 'Customer redirected to PayLater portal.', 'paylater' ) );
            $order->save();

            return array(
                'result'   => 'success',
                'redirect' => $response_body['paymentLinkUrl'],
            );
        }

        $error = '';
        if ( is_array( $response_body ) ) {
            if ( ! empty( $response_body['error'] ) ) {
                $error = (string) $response_body['error'];
            } elseif ( ! empty( $response_body['message'] ) ) {
                $error = (string) $response_body['message'];
            }
        }
        if ( $error === '' ) {
            $error = __( 'Gateway handshake failed. Please try again.', 'paylater' );
        }
        throw new Exception( $error );

    } catch ( Exception $e ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'PayLater Exception: ' . $e->getMessage() );
        }

        wc_add_notice( $e->getMessage(), 'error' );

        return array(
            'result'   => 'failure',
            'redirect' => '',
        );
    }
}

/**
 * Helper that POSTs a JSON body with a Bearer token and transparently retries
 * once after refreshing the token if the gateway returns 401.
 */
function paylater_post_with_bearer( $th, $url, $payload ) {
    $token = paylater_get_access_token( $th );

    $args = array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ),
        'body'    => wp_json_encode( $payload ),
        'timeout' => 45,
    );

    $response = wp_remote_post( $url, $args );

    if ( ! is_wp_error( $response ) && (int) wp_remote_retrieve_response_code( $response ) === 401 ) {
        paylater_invalidate_token( $th );
        $token                       = paylater_get_access_token( $th, true );
        $args['headers']['Authorization'] = 'Bearer ' . $token;
        $response                    = wp_remote_post( $url, $args );
    }

    return $response;
}

/**
 * Helper that performs a GET with a Bearer token and transparently retries
 * once after refreshing the token if the gateway returns 401.
 */
function paylater_get_with_bearer( $th, $url ) {
    $token = paylater_get_access_token( $th );

    $args = array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $token,
            'Accept'        => 'application/json',
        ),
        'timeout' => 30,
    );

    $response = wp_remote_get( $url, $args );

    if ( ! is_wp_error( $response ) && (int) wp_remote_retrieve_response_code( $response ) === 401 ) {
        paylater_invalidate_token( $th );
        $token                       = paylater_get_access_token( $th, true );
        $args['headers']['Authorization'] = 'Bearer ' . $token;
        $response                    = wp_remote_get( $url, $args );
    }

    return $response;
}
