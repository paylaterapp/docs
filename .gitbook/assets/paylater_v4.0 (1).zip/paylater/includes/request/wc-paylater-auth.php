<?php
/**
 * PayLater Pro - OAuth2 Token Manager
 *
 * Fetches and caches a Bearer access token using the client_credentials grant.
 * Tokens are stored in WP transients per environment (test / live) and reused
 * until shortly before their declared expiry.
 */

defined( 'ABSPATH' ) || exit;

function paylater_token_endpoint( $test_mode ) {
    return $test_mode
        ? 'https://connect.uat.paylaterapp.com/auth/realms/api/protocol/openid-connect/token'
        : 'https://connect.paylaterapp.com/auth/realms/api/protocol/openid-connect/token';
}

function paylater_token_transient_key( $test_mode ) {
    return $test_mode ? 'paylater_token_test' : 'paylater_token_live';
}

/**
 * Returns a Bearer access token, fetching a new one if the cache is empty or expired.
 *
 * @param object $th             Gateway instance (provides clientId, clientSecret, testMode).
 * @param bool   $force_refresh  Ignore the cached value and fetch a fresh token.
 * @throws Exception when credentials are missing or the auth server rejects the request.
 */
function paylater_get_access_token( $th, $force_refresh = false ) {
    $test_mode = ! empty( $th->testMode );
    $cache_key = paylater_token_transient_key( $test_mode );

    if ( ! $force_refresh ) {
        $cached = get_transient( $cache_key );
        if ( is_string( $cached ) && $cached !== '' ) {
            return $cached;
        }
    }

    $client_id     = isset( $th->clientId ) ? trim( (string) $th->clientId ) : '';
    $client_secret = isset( $th->clientSecret ) ? trim( (string) $th->clientSecret ) : '';

    if ( $client_id === '' || $client_secret === '' ) {
        throw new Exception( __( 'PayLater client ID or client secret is not configured.', 'paylater' ) );
    }

    $response = wp_remote_post( paylater_token_endpoint( $test_mode ), array(
        'headers' => array(
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept'       => 'application/json',
        ),
        'body'    => array(
            'grant_type'    => 'client_credentials',
            'client_id'     => $client_id,
            'client_secret' => $client_secret,
        ),
        'timeout' => 30,
    ) );

    if ( is_wp_error( $response ) ) {
        throw new Exception( $response->get_error_message() );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );

    if ( ! is_array( $body ) || empty( $body['access_token'] ) ) {
        $error = '';
        if ( is_array( $body ) ) {
            if ( ! empty( $body['error_description'] ) ) {
                $error = (string) $body['error_description'];
            } elseif ( ! empty( $body['error'] ) ) {
                $error = (string) $body['error'];
            }
        }
        throw new Exception(
            $error !== ''
                ? sprintf( __( 'PayLater auth failed: %s', 'paylater' ), $error )
                : __( 'PayLater auth failed: no access token in response.', 'paylater' )
        );
    }

    $token      = (string) $body['access_token'];
    $expires_in = isset( $body['expires_in'] ) ? (int) $body['expires_in'] : 3600;

    // Leave a 60-second safety margin to avoid edge-of-expiry races.
    $ttl = max( 60, $expires_in - 60 );
    set_transient( $cache_key, $token, $ttl );

    return $token;
}

/**
 * Drop the cached token, forcing the next API call to re-authenticate.
 */
function paylater_invalidate_token( $th ) {
    $test_mode = ! empty( $th->testMode );
    delete_transient( paylater_token_transient_key( $test_mode ) );
}
