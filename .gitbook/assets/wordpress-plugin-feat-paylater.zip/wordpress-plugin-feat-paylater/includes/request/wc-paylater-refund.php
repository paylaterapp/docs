<?php
/**
 * Process refunds
 */
function processPaylaterRefund($order_id, $amount = null, $reason = '', $th) {
    try {
    $order = wc_get_order($order_id);
        if (!$order) {
            throw new Exception(__('Order not found', 'paylater'));
        }

        // Get the payment link from order meta
        $payment_link = $order->get_meta('_paylater_payment_link');
        if (!$payment_link) {
            throw new Exception(__('Payment link not found', 'paylater'));
        }

        // Extract payment ID from the payment link
        $payment_id = basename(parse_url($payment_link, PHP_URL_PATH));

        // Prepare refund request
        $refund_url = $th->api . 'refund';
        $headers = array(
            'x-api-key' => $th->apiKey,
            'Content-Type' => 'application/json'
        );

    $payload = array(
            'merchantId' => $th->merchantId,
            'orderId' => $order_id,
            'amount' => $amount,
            'reason' => $reason
    );

        $response = wp_remote_post($refund_url, array(
            'headers' => $headers,
            'body' => json_encode($payload),
            'timeout' => 30
        ));

    if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
    }

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['status']) && $response_data['status'] === 'REFUNDED') {
            $order->add_order_note(sprintf(
                __('Refunded %s - Reason: %s', 'paylater'),
                wc_price($amount),
                $reason
            ));
        return true;
    } else {
            $error_message = isset($response_data['error']) ? 
                $response_data['error'] : 
                __('Refund failed', 'paylater');
            throw new Exception($error_message);
        }
    } catch (Exception $e) {
        $order->add_order_note(sprintf(
            __('Refund failed: %s', 'paylater'),
            $e->getMessage()
        ));
        return new WP_Error('refund_failed', $e->getMessage());
    }
}