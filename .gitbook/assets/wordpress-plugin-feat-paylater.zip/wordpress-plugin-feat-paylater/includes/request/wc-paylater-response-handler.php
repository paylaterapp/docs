<?php
/*
* Handle PayLater response
 */
function paylaterResponseHandler($th) {
    try {
        // Get the order ID from the request
        $order_id = isset($_GET['orderId']) ? sanitize_text_field($_GET['orderId']) : null;
        
        if (!$order_id) {
            throw new Exception(__('Order ID not found', 'paylater'));
        }

    $order = wc_get_order($order_id);
        if (!$order) {
            throw new Exception(__('Order not found', 'paylater'));
        }

        // Check payment status
        $status_url = $th->api . 'status?orderId=' . $order_id . '&merchantId=' . $th->merchantId;
            $headers = array(
            'x-api-key' => $th->apiKey,
            'Content-Type' => 'application/json'
        );

        $response = wp_remote_get($status_url, array(
                'headers' => $headers,
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }

        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['status'])) {
            switch ($response_data['status']) {
                case 'ORDER_COMPLETED':
            $order->payment_complete();
                    $order->add_order_note(__('Payment completed via PayLater', 'paylater'));
                    wp_redirect($order->get_checkout_order_received_url());
                    exit;
                    break;
                
                case 'ORDER_FAILED':
                    $order->update_status('failed', __('Payment failed via PayLater', 'paylater'));
                    wc_add_notice(__('Payment failed. Please try again.', 'paylater'), 'error');
                    wp_redirect($order->get_cancel_order_url());
                    exit;
                    break;
                
                default:
                    $order->update_status('on-hold', sprintf(__('Payment status: %s', 'paylater'), $response_data['status']));
                    wp_redirect($order->get_checkout_order_received_url());
            exit;
            }
        } else {
            throw new Exception(__('Invalid response from PayLater', 'paylater'));
    }
    } catch (Exception $e) {
        wc_add_notice($e->getMessage(), 'error');
        wp_redirect(wc_get_checkout_url());
    exit;
    }
}