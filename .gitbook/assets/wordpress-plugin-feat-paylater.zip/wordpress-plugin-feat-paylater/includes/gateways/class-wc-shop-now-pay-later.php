<?php
/*
/* Shop Now Pay Later
*/
class WC_PayLater_Gateway_Shop_Now_Pay_Later extends WC_Payment_Gateway{

    public function __construct(){

        add_action('woocommerce_api_wc_paylater_gateway_shop_now_pay_later', array($this, 'paylater_response_handler'));
        gatewayPaylaterParameters($this, "Shop Now Pay Later");
    }
    /**
     * Define fields and labels in Admin Panel
     */
    public function init_form_fields(){
        paylater_form_fields($this);
    }
    /*
    * Process payments: magic begins here
    */
    public function process_payment($order_id){

        return processPaylaterPayment($order_id, $this, "Shop Now Pay Later", "wc_paylater_gateway_shop_now_pay_later");
    }
    /**
	 * Called when PayLater checkout page redirects back to merchant page
	 */
	public function paylater_response_handler(){
		return paylaterResponseHandler($this);
	}
    /**
	 * Process refunds
	 */
	public function process_refund($order_id, $amount = null, $reason = ''){
		return processPaylaterRefund($order_id, $amount, $reason, $this);
	}
}
