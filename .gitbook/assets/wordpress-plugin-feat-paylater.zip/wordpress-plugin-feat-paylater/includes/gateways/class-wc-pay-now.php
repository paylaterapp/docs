<?php
/*
/* Pay Now with paylater 
*/
class WC_PayLater_Gateway_Pay_Now extends WC_Payment_Gateway{

	public function __construct(){
		add_action('woocommerce_api_wc_paylater_gateway_pay_now', array($this, 'paylater_response_handler'));
		gatewayPaylaterParameters($this, "Pay Now");
	}
	/**
	 * Define fields and labels in Admin Panel
	 */
	public function init_form_fields(){
		paylater_form_fields($this, "Pay Now");
	}
	/*
	* Process payments: magic begins here
	*/
	public function process_payment($order_id){
		return processPaylaterPayment($order_id, $this, "Pay Now", "wc_paylater_gateway_pay_now");
	}
	/**
	 * Called when PayLater checkout page redirects back to merchant page
	 */
	public function paylater_response_handler(){
		return paylaterResponseHandler($this);
	}
	/**
	 * Process refunds
	 */
	public function process_refund($order_id, $amount = null, $reason = ''){
		return processPaylaterRefund($order_id, $amount, $reason, $this);
	}
}
