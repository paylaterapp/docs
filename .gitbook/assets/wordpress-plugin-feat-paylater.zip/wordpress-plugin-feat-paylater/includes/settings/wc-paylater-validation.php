<?php
/*
/* Currency Converter
*/

function paylater_check_amount($paylater_amount, $paylater_currency, $merchant_amount, $merchant_currency){
    $lang = get_locale();
    try {

        if ($paylater_currency != $merchant_currency) {
            if ($paylater_currency == "QAR") {
                switch ($merchant_currency) {
                    case "USD":
                        $merchant_amount = $merchant_amount * 3.6730;
                        break;
                    case "SAR":
                        $merchant_amount = $merchant_amount * 0.9604;
                        break;
                    case "OMR":
                        $merchant_amount = $merchant_amount * 9.55;
                        break;
                    case "BHD":
                        $merchant_amount = $merchant_amount * 9.75;
                        break;
                    case "AED":
                        $merchant_amount = $merchant_amount * 1;
                        break;
                }
            }
            if (abs(($paylater_amount - $merchant_amount)) < 5) {
                return true;
            }
        } else if ($paylater_amount == $merchant_amount) {
            return true;
        } else {
            return false;
        }
    } catch (Exception $e) {
        $error = $lang == 'ar' ? "المبلغ الاجمالي لا يطابق المبلغ الاجمالي من البائع. حاول مرة اخرى لاحقاً" : "Amount from Paylater doesn't match amount from merchant. Please try again";
        $errorChe = $lang == 'ar' ? 'خطأ في تأكيد الطلب: ' : 'Checkout Error: ' ;
        wc_add_notice(__($errorChe, 'woothemes') . $error , 'error');
        error_log("Error on amount match " . $e->getMessage());
    }
}
/*
/* validate Currency
*/
function paylater_validate_curr($curr){

    if ($curr == "AED" || $curr == "SAR" || $curr == "USD"|| $curr == "BHD" || $curr == "OMR"|| $curr == "QAR") {
        return true;
    } else {
        return false;
    }
}