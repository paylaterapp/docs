<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Observer;

use Exception;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;
use PayLater\PayLaterpay\Helper\Data;
use PayLater\PayLaterpay\Model\SpotiiPay;

/**
 * Class SetCaptureExpiryObserver
 * @package PayLater\PayLaterpay\Observer
 */
class SetCaptureExpiryObserver implements ObserverInterface
{
    const PAYMENT_CODE = 'ppaylater';

    /**
     * @var SpotiiPay
     */
    private $spotiiPayModel;

    /**
     * @var Data
     */
    private $spotiiHelper;

    /**
     * @var ManagerInterface
     */
    private $messageManager;

    /**
     * Construct
     *
     * @param SpotiiPay $spotiiPayModel
     * @param Data $spotiiHelper
     * @param ManagerInterface $messageManager
     */
    public function __construct(
        SpotiiPay        $spotiiPayModel,
        Data             $spotiiHelper,
        ManagerInterface $messageManager
    ) {
        $this->spotiiPayModel = $spotiiPayModel;
        $this->spotiiHelper = $spotiiHelper;
        $this->messageManager = $messageManager;
    }

    /**
     * Set PayLater Capture Expiry for Authorize Only payment action
     *
     * @param Observer $observer
     * @return void
     * @throws Exception
     */
    public function execute(Observer $observer)
    {
        try {
            $this->spotiiHelper->logSpotiiActions('****PayLater capture time setting start****');
            $order = $observer->getEvent()->getOrder();
            $reference = $order->getPayment()->getAdditionalInformation(SpotiiPay::ADDITIONAL_INFORMATION_KEY_ORDERID);
            $this->spotiiHelper->logSpotiiActions("PayLater Reference : $reference");
            $paymentAction = $order->getPayment()->getAdditionalInformation('payment_type');
            $this->spotiiHelper->logSpotiiActions("Payment Type : $paymentAction");
            switch ($paymentAction) {
                case SpotiiPay::ACTION_AUTHORIZE:
                    $this->spotiiPayModel->setSpotiiCaptureExpiry($reference, $order->getPayment());
                    $this->spotiiHelper->logSpotiiActions('****PayLater capture time setting end****');
                    break;
                default:
                    break;
            }
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions('Unable to set capture time : ' . $e->getMessage());
            $this->messageManager->addExceptionMessage(
                $e,
                __('Unable to set capture time.')
            );
        }
    }
}
