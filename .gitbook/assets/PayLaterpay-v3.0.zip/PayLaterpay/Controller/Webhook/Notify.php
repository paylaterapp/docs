<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Controller\Webhook;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Sales\Model\OrderFactory;
use PayLater\PayLaterpay\Helper\Data as PayLaterHelper;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;
use PayLater\PayLaterpay\Model\SpotiiPay;

/**
 * PayLater webhook receiver.
 *
 * Public endpoint at {base_url}/ppaylater/webhook/notify. Configure the matching
 * URL on PayLater's side; they'll issue a webhook secret which goes into the
 * admin config (Stores → Configuration → Sales → Payment Methods → PayLater →
 * Webhook Secret).
 *
 * Inbound payload (JSON, POST):
 *   {merchantId, orderId, paylaterRef, status, timestamp, signature, txHash, comments}
 *
 * Validation per PayLater spec:
 *   1. dataString = strtoupper(merchantId + orderId + status + timestamp + comments)
 *   2. expected txHash       = md5(dataString)                — must match payload.txHash
 *   3. expected signature    = hmac_sha256(txHash, secret)    — must match payload.signature
 *   Both checks must pass; otherwise return 403.
 */
class Notify extends Action implements HttpPostActionInterface, CsrfAwareActionInterface
{
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var OrderFactory
     */
    private $orderFactory;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $apiConfig;

    /**
     * @var SpotiiPay
     */
    private $paymentMethod;

    /**
     * @var PayLaterHelper
     */
    private $helper;

    public function __construct(
        Context                  $context,
        JsonFactory              $resultJsonFactory,
        OrderFactory             $orderFactory,
        SpotiiApiConfigInterface $apiConfig,
        SpotiiPay                $paymentMethod,
        PayLaterHelper           $helper
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->orderFactory = $orderFactory;
        $this->apiConfig = $apiConfig;
        $this->paymentMethod = $paymentMethod;
        $this->helper = $helper;
        parent::__construct($context);
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    public function execute()
    {
        $jsonResult = $this->resultJsonFactory->create();

        try {
            $raw = (string) $this->getRequest()->getContent();
            $payload = json_decode($raw, true);
            if (!is_array($payload)) {
                $this->helper->logSpotiiActions('[webhook] rejected: payload is not valid JSON');
                return $jsonResult->setHttpResponseCode(400)->setData(['message' => 'Invalid JSON']);
            }

            $orderId = (string) ($payload['orderId'] ?? '');
            $status = strtolower((string) ($payload['status'] ?? ''));
            $payLaterRef = isset($payload['paylaterRef']) ? (string) $payload['paylaterRef'] : null;

            $this->helper->logSpotiiActions(
                "[webhook] received orderId=$orderId status=$status paylaterRef=" . ($payLaterRef ?: 'n/a')
            );

            if (!$this->verifySignature($payload)) {
                $this->helper->logSpotiiActions("[webhook] signature mismatch for orderId=$orderId");
                return $jsonResult->setHttpResponseCode(403)->setData(['message' => 'Invalid signature']);
            }

            if ($orderId === '') {
                return $jsonResult->setHttpResponseCode(400)->setData(['message' => 'orderId missing']);
            }

            $order = $this->orderFactory->create()->loadByIncrementId($orderId);
            if (!$order->getId()) {
                $this->helper->logSpotiiActions("[webhook] order $orderId not found");
                return $jsonResult->setHttpResponseCode(404)->setData(['message' => 'Order not found']);
            }
            if ($order->getPayment()->getMethod() !== SpotiiPay::PAYMENT_CODE) {
                return $jsonResult->setHttpResponseCode(409)->setData(['message' => 'Order is not a PayLater order']);
            }

            switch ($status) {
                case 'success':
                    $this->paymentMethod->processSuccessfulPayment($order, $orderId, $payLaterRef);
                    break;
                case 'failed':
                case 'failure':
                case 'cancelled':
                case 'canceled':
                    $this->paymentMethod->processFailedPayment(
                        $order,
                        'Webhook reported payment ' . $status
                    );
                    break;
                case 'pending':
                    // Acknowledge but don't change order state.
                    break;
                default:
                    $this->helper->logSpotiiActions("[webhook] unknown status '$status' for orderId=$orderId");
                    return $jsonResult->setHttpResponseCode(202)->setData(['message' => 'Status not handled']);
            }

            return $jsonResult->setData(['message' => 'Webhook received successfully']);

        } catch (Exception $e) {
            $this->helper->logSpotiiActions('[webhook] error: ' . $e->getMessage());
            return $jsonResult->setHttpResponseCode(500)->setData(['message' => 'Internal error']);
        }
    }

    /**
     * @param array $payload
     * @return bool
     */
    private function verifySignature(array $payload): bool
    {
        foreach (['merchantId', 'orderId', 'status', 'timestamp', 'txHash', 'signature'] as $required) {
            if (!isset($payload[$required]) || $payload[$required] === '') {
                return false;
            }
        }

        $secret = (string) ($this->apiConfig->getWebhookSecret() ?? '');
        if ($secret === '') {
            $this->helper->logSpotiiActions('[webhook] no webhook secret configured — refusing');
            return false;
        }

        $comments = (string) ($payload['comments'] ?? '');
        $dataString = strtoupper(
            $payload['merchantId']
            . $payload['orderId']
            . $payload['status']
            . $payload['timestamp']
            . $comments
        );

        $expectedTxHash = md5($dataString);
        if (!hash_equals($expectedTxHash, (string) $payload['txHash'])) {
            return false;
        }

        $expectedSignature = hash_hmac('sha256', $expectedTxHash, $secret);
        return hash_equals($expectedSignature, (string) $payload['signature']);
    }
}
