<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Controller\Standard;

use Exception;
use Magento\Customer\Api\Data\GroupInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

class Redirect extends SpotiiPay
{
    /**
     * Submit the quote (creates the order in pending_payment state via the
     * payment method's initialize()), then call the gateway for a checkout
     * link. If the gateway call fails we cancel the freshly created order.
     *
     * @return mixed
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function execute()
    {
        $this->spotiiHelper->logSpotiiActions('****Starting PayLater****');
        $jsonResult = $this->resultJsonFactory->create();

        try {
            $quote = $this->checkoutSession->getQuote();
            $this->spotiiHelper->logSpotiiActions('Quote Id : ' . $quote->getId());

            // 1. Make sure customer/billing/email is set up before submit.
            if ($this->customerSession->isLoggedIn()) {
                $customer = $this->customerRepository->getById(
                    $this->customerSession->getCustomer()->getId()
                );
                $quote->setCustomer($customer);
                $billing = $quote->getBillingAddress();
                $shipping = $quote->getShippingAddress();
                if ((empty($shipping) || empty($shipping->getStreetLine(1)))
                    && (empty($billing) || empty($billing->getStreetLine(1)))) {
                    return $jsonResult->setData(['message' => 'Please select an address']);
                }
                if (empty($billing) || empty($billing->getStreetLine(1)) || empty($billing->getFirstname())) {
                    $quote->setBillingAddress($shipping);
                }
            } else {
                $post = $this->getRequest()->getPostValue();
                $email = $post['email'] ?? null;
                if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    return $jsonResult->setData(['message' => 'Invalid email address']);
                }
                if (!empty($email)) {
                    $quote->setCustomerEmail($email)
                          ->setCustomerIsGuest(true)
                          ->setCustomerGroupId(GroupInterface::NOT_LOGGED_IN_ID);
                }
            }

            // 2. Set payment method, refresh totals, save.
            $quote->getPayment()->setMethod('ppaylater');
            $quote->collectTotals();
            $quote->save();

            // 3. Submit creates the order; SpotiiPay::initialize() pins it to pending_payment.
            $order = $this->quoteManagement->submit($quote);
            if (!$order || !$order->getId()) {
                throw new LocalizedException(__('Could not create order.'));
            }

            // 4. Persist enough on the session that Complete/Cancel can find the order.
            $this->checkoutSession
                ->setLastQuoteId($quote->getId())
                ->setLastOrderId($order->getId())
                ->setLastRealOrderId($order->getIncrementId())
                ->setLastOrderStatus($order->getStatus());

            // 5. Get the gateway redirect URL. If this fails we cancel the order.
            try {
                $checkoutUrl = $this->spotiipayModel->getCheckoutUrl($order);
                $order->getPayment()->save();
                $order->save();
            } catch (Exception $gatewayError) {
                $this->spotiipayModel->processFailedPayment(
                    $order,
                    'Gateway start failed: ' . $gatewayError->getMessage()
                );
                throw $gatewayError;
            }

            $this->spotiiHelper->logSpotiiActions("Checkout Url : $checkoutUrl");
            return $jsonResult->setData(['redirectURL' => $checkoutUrl]);

        } catch (LocalizedException|Exception $e) {
            $this->spotiiHelper->logSpotiiActions('Redirect Exception: ' . $e->getMessage());
            $this->messageManager->addErrorMessage($e->getMessage());
            return $jsonResult->setData(['message' => $e->getMessage()]);
        }
    }
}
