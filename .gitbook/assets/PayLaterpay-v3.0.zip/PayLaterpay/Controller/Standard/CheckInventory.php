<?php

namespace PayLater\PayLaterpay\Controller\Standard;

use Magento\Framework\Exception\NoSuchEntityException;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;
use Zend_Log_Exception;

class CheckInventory extends SpotiiPay
{
    /**
     * @throws NoSuchEntityException
     * @throws Zend_Log_Exception
     */
    public function execute()
    {
        $jsonResult = $this->resultJsonFactory->create();
        $post = $this->getRequest()->getPostValue();

        if (empty($post['items'])) {
            return $jsonResult->setData(['isInStock' => false, 'error' => 'No items provided']);
        }

        try {
            $items = $this->jsonHelper->jsonDecode($post['items']);
        } catch (\Exception $e) {
            return $jsonResult->setData(['isInStock' => false, 'error' => 'Invalid items data']);
        }

        if (!is_array($items)) {
            return $jsonResult->setData(['isInStock' => false, 'error' => 'Invalid items data']);
        }

        foreach ($items as $item) {
            $sku = $item['sku'] ?? null;
            $qtyOrdered = (float) ($item['qty'] ?? 0);
            if (!$sku) {
                continue;
            }
            $this->spotiiHelper->logSpotiiActions("checking ... " . $sku);
            $stockItem = $this->stockRegistry->getStockItemBySku($sku);
            if ((float) $stockItem->getQty() < $qtyOrdered) {
                return $jsonResult->setData(['isInStock' => false]);
            }
        }

        return $jsonResult->setData(['isInStock' => true]);
    }
}
