<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Controller\Standard;

use Exception;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order;
use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;
use PayLater\PayLaterpay\Model\SpotiiPay as SpotiiPayModel;

class Cancel extends SpotiiPay
{
    /**
     * Called when the gateway redirects the shopper back via failRedirectUrl.
     *
     * Asks PayLater for the authoritative status before deciding:
     *   - status = 2 (success): rare race — shopper actually completed payment
     *     between gateway approval and the redirect back. Settle the order.
     *   - status = 1 / 3 / error / unreachable: cancel the pending order so
     *     the shopper can retry without an orphan in pending_payment.
     */
    public function execute()
    {
        try {
            $reference = (string) $this->getRequest()->getParam('id');
            if ($reference === '') {
                $reference = (string) $this->checkoutSession->getLastRealOrderId();
            }

            if ($reference !== '') {
                $order = $this->orderFactory->create()->loadByIncrementId($reference);
                if ($order->getId()
                    && $order->getPayment()->getMethod() === SpotiiPayModel::PAYMENT_CODE
                    && $order->getState() === Order::STATE_PENDING_PAYMENT) {
                    $this->resolvePendingOrder($order, $reference);
                }
            }

            $this->checkoutSession->restoreQuote();

            $error = $this->getRequest()->getParam('error');
            if ($error) {
                $this->messageManager->addErrorMessage((string) $error);
                $this->spotiiHelper->logSpotiiActions('PayLater Error: ' . $error);
            } else {
                $this->messageManager->addErrorMessage(__('Transaction was not completed.'));
                $this->spotiiHelper->logSpotiiActions('Returned from PayLater without completing payment.');
            }

        } catch (LocalizedException $e) {
            $this->spotiiHelper->logSpotiiActions('Cancel Exception: ' . $e->getMessage());
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (Exception $e) {
            $this->spotiiHelper->logSpotiiActions('Cancel Exception: ' . $e->getMessage());
        }

        return $this->_redirect('checkout/cart');
    }

    /**
     * Ask the gateway what really happened, then settle or cancel accordingly.
     */
    private function resolvePendingOrder($order, string $reference): void
    {
        try {
            $info = $this->spotiipayModel->getOrderInfo($reference);
        } catch (Exception $e) {
            $this->spotiipayModel->processFailedPayment(
                $order,
                'Gateway status unavailable: ' . $e->getMessage()
            );
            return;
        }

        $status = isset($info['status']) ? (int) $info['status'] : null;
        if ($status === SpotiiPayModel::GATEWAY_STATUS_SUCCESS) {
            $gatewayTxnId = isset($info['payLaterOrderId']) ? (string) $info['payLaterOrderId'] : null;
            $this->spotiipayModel->processSuccessfulPayment($order, $reference, $gatewayTxnId);
            return;
        }

        $reason = $status === SpotiiPayModel::GATEWAY_STATUS_FAILED
            ? 'Gateway reported payment failed'
            : 'Shopper returned without completing payment';
        $this->spotiipayModel->processFailedPayment($order, $reason);
    }
}
