<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Exception;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\ZendClient;
use PayLater\PayLaterpay\Helper\Data as SpotiiHelper;

/**
 * HTTP client for PayLater gateway calls.
 *
 * Logging policy (when "Enable Logging" is on):
 *   [gw] → POST <url> body=<json>           (request — one line)
 *   [gw] ← <httpCode> <body>                (response — one line)
 *
 * On error: the response line still fires so failures are diagnosable; the
 * caller receives a LocalizedException with the gateway's error message.
 *
 * Intentionally NOT logged (security / signal-to-noise):
 *   - API key value (the X-Api-Key header is implicit on every call)
 *   - Response headers, TLS handshake, curl_info timing breakdown
 *   - Reconstructable curl command
 */
class Processor implements ProcessorInterface
{
    /** Max response-body length captured into the log line. */
    const RESPONSE_LOG_LIMIT = 1000;

    /**
     * @var SpotiiHelper
     */
    protected $spotiiHelper;

    public function __construct(SpotiiHelper $spotiiHelper)
    {
        $this->spotiiHelper = $spotiiHelper;
    }

    /**
     * @param string $url
     * @param string $apiKey
     * @param array|null $body
     * @param string $method
     * @return string
     * @throws LocalizedException
     */
    public function call($url, $apiKey, $body = false, $method = ZendClient::GET)
    {
        $body = $body ?: null;
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Api-Key: ' . (string) $apiKey,
            'User-Agent: PayLater-Magento/1.0',
        ];

        $encodedBody = is_array($body) ? json_encode($body, JSON_UNESCAPED_SLASHES) : null;

        if ($this->spotiiHelper->isLogEnabled()) {
            $this->spotiiHelper->logSpotiiActions(sprintf(
                '[gw] → %s %s%s',
                strtoupper($method),
                $url,
                $encodedBody !== null ? ' body=' . $encodedBody : ''
            ));
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => ApiParamsInterface::TIMEOUT,
            CURLOPT_USERAGENT      => 'PayLater-Magento/1.0',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        if (strtoupper((string) $method) === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($encodedBody !== null) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedBody);
            }
        }

        $response = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($this->spotiiHelper->isLogEnabled()) {
            $shown = $response === false
                ? 'curl_error=' . $curlError
                : substr((string) $response, 0, self::RESPONSE_LOG_LIMIT);
            $this->spotiiHelper->logSpotiiActions(sprintf('[gw] ← %d %s', $httpCode, $shown));
        }

        if ($response === false) {
            throw new LocalizedException(__('Gateway connection error: %1', $curlError));
        }

        if ($httpCode >= 400) {
            $decoded = json_decode((string) $response, true);
            $errorMessage = is_array($decoded) && isset($decoded['error'])
                ? (string) $decoded['error']
                : (string) $response;
            throw new LocalizedException(__('%1', $errorMessage));
        }

        return $response;
    }
}
