<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

interface ConfigInterface
{
    /**
     * Get success-return URL. Optional reference is included as the `id` route
     * parameter so the Complete controller can find the order even if the
     * shopper's session is lost.
     *
     * @param string|null $reference
     * @return string
     */
    public function getCompleteUrl($reference = null);

    /**
     * Get failure-return URL.
     *
     * @param string|null $error
     * @param string|null $reference
     * @return string
     */
    public function getCancelUrl($error = null, $reference = null);
}
