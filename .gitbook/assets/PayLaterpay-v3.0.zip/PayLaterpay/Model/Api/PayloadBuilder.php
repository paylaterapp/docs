<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Sales\Api\Data\OrderInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

class PayloadBuilder
{
    const PRECISION = 2;

    /**
     * @var SpotiiApiConfigInterface
     */
    protected $spotiiApiConfig;

    /**
     * @var ConfigInterface
     */
    protected $config;

    public function __construct(
        SpotiiApiConfigInterface $spotiiApiConfig,
        ConfigInterface          $config
    ) {
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->config = $config;
    }

    /**
     * Build the web-checkout payload sent to PayLater. Reference equals the
     * Magento order increment id so we can match returns and reconcile orphans.
     */
    public function buildCheckoutPayload(OrderInterface $order, string $reference): array
    {
        return [
            'merchantId' => $this->spotiiApiConfig->getMerchantId(),
            'outletId' => $this->spotiiApiConfig->getOutletId(),
            'currency' => $order->getOrderCurrencyCode(),
            'amount' => round((float) $order->getGrandTotal(), self::PRECISION),
            'orderId' => $reference,
            'successRedirectUrl' => $this->config->getCompleteUrl($reference),
            'failRedirectUrl' => $this->config->getCancelUrl(null, $reference),
        ];
    }
}
