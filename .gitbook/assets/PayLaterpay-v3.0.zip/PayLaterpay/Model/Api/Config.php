<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Api;

use Magento\Framework\UrlInterface;

class Config implements ConfigInterface
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    public function __construct(UrlInterface $urlBuilder)
    {
        $this->urlBuilder = $urlBuilder;
    }

    public function getCompleteUrl($reference = null)
    {
        $params = ['_secure' => true];
        if ($reference) {
            $params['id'] = $reference;
        }
        return $this->urlBuilder->getUrl('ppaylater/standard/complete', $params);
    }

    public function getCancelUrl($error = null, $reference = null)
    {
        $params = ['_secure' => true];
        if ($error !== null) {
            $params['error'] = $error;
        }
        if ($reference) {
            $params['id'] = $reference;
        }
        return $this->urlBuilder->getUrl('ppaylater/standard/cancel', $params);
    }
}
