<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class PaymentMode implements OptionSourceInterface
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'uat', 'label' => __('UAT')],
            ['value' => 'live', 'label' => __('Live')]
        ];
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
            'uat' => __('UAT'),
            'live' => __('Live')
        ];
    }
}
