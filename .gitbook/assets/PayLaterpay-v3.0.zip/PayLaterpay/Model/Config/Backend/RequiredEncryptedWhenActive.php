<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Backend;

use Magento\Config\Model\Config\Backend\Encrypted;
use Magento\Framework\Exception\ValidatorException;

/**
 * Encrypted backend that also enforces "required when active". Lets the
 * placeholder asterisks (admin didn't change the value) pass through; the
 * already-encrypted value in DB is assumed non-empty.
 */
class RequiredEncryptedWhenActive extends Encrypted
{
    public function beforeSave()
    {
        $value = (string) $this->getValue();
        $isPlaceholder = $value !== '' && preg_match('/^\*+$/', $value) === 1;

        if (!$isPlaceholder && trim($value) === '' && $this->isPayLaterActive()) {
            throw new ValidatorException(
                __('%1 is required when PayLater is enabled.', $this->resolveFieldLabel())
            );
        }
        return parent::beforeSave();
    }

    protected function isPayLaterActive(): bool
    {
        $active = $this->getFieldsetDataValue('active');
        return $active === '1' || $active === 1 || $active === true;
    }

    protected function resolveFieldLabel(): string
    {
        $label = $this->getFieldConfig()['label'] ?? 'This field';
        return is_object($label) ? (string) $label : (string) $label;
    }
}
