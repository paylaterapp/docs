<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Model\Config\Backend;

use Magento\Framework\App\Config\Value;
use Magento\Framework\Exception\ValidatorException;

/**
 * Reject save if this admin field is empty AND the PayLater payment method
 * is being saved as active. Disabling the method lets admin leave fields
 * empty without friction.
 */
class RequiredWhenActive extends Value
{
    public function beforeSave()
    {
        if (trim((string) $this->getValue()) === '' && $this->isPayLaterActive()) {
            throw new ValidatorException(
                __('%1 is required when PayLater is enabled.', $this->resolveFieldLabel())
            );
        }
        return parent::beforeSave();
    }

    protected function isPayLaterActive(): bool
    {
        $active = $this->getFieldsetDataValue('active');
        return $active === '1' || $active === 1 || $active === true;
    }

    protected function resolveFieldLabel(): string
    {
        $label = $this->getFieldConfig()['label'] ?? 'This field';
        return is_object($label) ? (string) $label : (string) $label;
    }
}
