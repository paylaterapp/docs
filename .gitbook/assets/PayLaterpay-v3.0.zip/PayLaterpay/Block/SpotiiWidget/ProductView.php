<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Block\SpotiiWidget;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
use PayLater\PayLaterpay\Model\Config\Container\ProductWidgetConfigInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

/**
 * Class ProductView
 * @package PayLater\PayLaterpay\Block\SpotiiWidget
 */
class ProductView extends Template
{
    const MIN_PRICE = 0;
    const MAX_PRICE = 100000;
    const WIDGET_TYPE = "product_page";

    /**
     * @var ProductWidgetConfigInterface
     */
    private $productWidgetConfig;

    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * ProductWidget constructor.
     *
     * @param Context $context
     * @param ProductWidgetConfigInterface $productWidgetConfig
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param StoreManagerInterface $storeManager
     * @param array $data
     */
    public function __construct(
        Template\Context             $context,
        ProductWidgetConfigInterface $productWidgetConfig,
        SpotiiApiConfigInterface     $spotiiApiConfig,
        StoreManagerInterface        $storeManager,
        array                        $data
    ) {
        $this->productWidgetConfig = $productWidgetConfig;
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->storeManager = $storeManager;
        parent::__construct($context, $data);
    }

    /**
     * Get JS Config
     *
     * @return array
     * @throws NoSuchEntityException
     */
    public function getJsConfig()
    {
        $result = [
            'targetXPath' => $this->productWidgetConfig->getTargetXPath(),
            'renderToPath' => $this->productWidgetConfig->getRenderToPath(),
            'forcedShow' => $this->productWidgetConfig->getForcedShow(),
            'alignment' => $this->productWidgetConfig->getAlignment(),
            'merchantID' => $this->spotiiApiConfig->getMerchantId(),
            'theme' => $this->productWidgetConfig->getTheme(),
            'widthType' => $this->productWidgetConfig->getWidthType(),
            'widgetType' => self::WIDGET_TYPE,
            'minPrice' => self::MIN_PRICE,
            'maxPrice' => self::MAX_PRICE,
            'imageUrl' => $this->productWidgetConfig->getImageUrl(),
            'hideClasses' => $this->productWidgetConfig->getHideClass(),
            'currency' => $this->storeManager->getStore()->getCurrentCurrencyCode()
        ];

        foreach ($result as $key => $value) {
            if (is_null($result[$key]) || $result[$key] == '') {
                unset($result[$key]);
            }
        }
        return $result;
    }
}
