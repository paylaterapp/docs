<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
declare(strict_types=1);

namespace PayLater\PayLaterpay\Block\SpotiiWidget;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\StoreManagerInterface;
use PayLater\PayLaterpay\Model\Config\Container\CatalogWidgetConfigInterface;
use PayLater\PayLaterpay\Model\Config\Container\SpotiiApiConfigInterface;

/**
 * Class ProductView
 * @package PayLater\PayLaterpay\Block\SpotiiWidget
 */
class Catalogue extends Template
{
    const MIN_PRICE = 0;
    const MAX_PRICE = 100000;
    const WIDGET_TYPE = "catalogue_page";

    /**
     * @var CatalogWidgetConfigInterface
     */
    private $catalogWidgetConfig;
    /**
     * @var SpotiiApiConfigInterface
     */
    private $spotiiApiConfig;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * ProductWidget constructor.
     *
     * @param Context $context
     * @param CatalogWidgetConfigInterface $catalogWidgetConfig
     * @param SpotiiApiConfigInterface $spotiiApiConfig
     * @param StoreManagerInterface $storeManager
     * @param array $data
     */
    public function __construct(
        Template\Context             $context,
        CatalogWidgetConfigInterface $catalogWidgetConfig,
        SpotiiApiConfigInterface     $spotiiApiConfig,
        StoreManagerInterface        $storeManager,
        array                        $data
    ) {
        $this->catalogWidgetConfig = $catalogWidgetConfig;
        $this->spotiiApiConfig = $spotiiApiConfig;
        $this->storeManager = $storeManager;
        parent::__construct($context, $data);
    }

    /**
     * Get JS Config
     *
     * @return array
     * @throws NoSuchEntityException
     */
    public function getJsConfig()
    {
        $result = [
            'targetXPath' => $this->catalogWidgetConfig->getTargetXPath(),
            'renderToPath' => $this->catalogWidgetConfig->getRenderToPath(),
            'forcedShow' => $this->catalogWidgetConfig->getForcedShow(),
            'alignment' => $this->catalogWidgetConfig->getAlignment(),
            'merchantID' => $this->spotiiApiConfig->getMerchantId(),
            'theme' => $this->catalogWidgetConfig->getTheme(),
            'widthType' => $this->catalogWidgetConfig->getWidthType(),
            'widgetType' => self::WIDGET_TYPE,
            'minPrice' => self::MIN_PRICE,
            'maxPrice' => self::MAX_PRICE,
            'imageUrl' => $this->catalogWidgetConfig->getImageUrl(),
            'hideClasses' => $this->catalogWidgetConfig->getHideClass(),
            'currency' => $this->storeManager->getStore()->getCurrentCurrencyCode()
        ];

        foreach ($result as $key => $value) {
            if (is_null($result[$key]) || $result[$key] == '') {
                unset($result[$key]);
            }
        }
        return $result;
    }
}
