/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 *
 * Previously loaded https://widget.spotii.me/v1/javascript/spotii-catalog-widget.js
 * (3rd-party domain, supply-chain risk for a payment method). The PLP "Split into 4"
 * widget is now rendered server-side by view/base/templates/product/price/Catalog/final_price.phtml,
 * so this client-side loader is intentionally a no-op.
 */
define(['jquery', 'ko', 'uiComponent', 'domReady!'], function ($, ko, Component) {
    'use strict';
    return Component.extend({
        initialize: function () {
            this._super();
        }
    });
});
