/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
define([
    'jquery',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Checkout/js/model/quote',
    'Magento_Ui/js/model/messageList',
    'mage/url',
    'mage/translate'
], function (
    $,
    customer,
    Component,
    additionalValidators,
    quote,
    globalMessageList,
    urlBuilder,
    $t
) {
    'use strict';

    var inFlight = false;

    var PAYLATER_LOGO = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB2aWV3Qm94PSIzMTguMzEgMTYxLjkgODAzLjI0IDE5OC4xMyI+PGRlZnM+PHN0eWxlPi5jbHMtMXtjbGlwLXBhdGg6dXJsKCNjbGlwcGF0aCl9LmNscy0ye2ZpbGw6bm9uZX0uY2xzLTIsLmNscy0zLC5jbHMtNCwuY2xzLTUsLmNscy02LC5jbHMtNywuY2xzLTgsLmNscy05e3N0cm9rZS13aWR0aDowcHh9LmNscy0ze2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQpfS5jbHMtNHtmaWxsOiM0MTM3OTZ9LmNscy0xMHtjbGlwLXBhdGg6dXJsKCNjbGlwcGF0aC0xKX0uY2xzLTExe2NsaXAtcGF0aDp1cmwoI2NsaXBwYXRoLTIpfS5jbHMtNXtmaWxsOiMyN2M1ZDF9LmNscy02e2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQtMil9LmNscy03e2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQtMyl9LmNscy04e2ZpbGw6dXJsKCNyYWRpYWwtZ3JhZGllbnQtNCl9LmNscy05e2ZpbGw6IzgzNjlmMH08L3N0eWxlPjxjbGlwUGF0aCBpZD0iY2xpcHBhdGgiPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTM5NC41MSwzMTEuN2MtMjMuOTItLjgyLTQzLjE2LTIwLjA3LTQzLjk2LTQ0bC0zLjc4LDI2LjkyYy0zLjk5LDI4LjM5LDE1Ljc5LDUxLjQsNDQuMTcsNTEuNGgxOS4yN2MzLjU1LDAsNi44My0yLjg4LDcuMzMtNi40MmwzLjkxLTI3Ljg0aC0yNS43Yy0uNDIsMC0uODQtLjAyLTEuMjQtLjA1WiIvPjwvY2xpcFBhdGg+PHJhZGlhbEdyYWRpZW50IGlkPSJyYWRpYWwtZ3JhZGllbnQiIGN4PSIzNzEuNjgiIGN5PSIyODQuMjQiIGZ4PSIzNzEuNjgiIGZ5PSIyODQuMjQiIHI9IjUzLjM3IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjYThlNWQxIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMjdjNWQxIi8+PC9yYWRpYWxHcmFkaWVudD48Y2xpcFBhdGggaWQ9ImNsaXBwYXRoLTEiPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ2Ni40MSwxNzQuNjloLTUxLjRjLTI4LjM5LDAtNTQuNjMsMjMuMDEtNTguNjIsNTEuNGwtNS44NSw0MS42MWMuOCwyMy45MywyMC4wNCw0My4xOCw0My45Niw0NC04Ljc5LS42NC0xNC43NS04LjA0LTEzLjQ4LTE3LjA4bDkuNjMtNjguNTNjMS4zMy05LjQ2LDEwLjA4LTE3LjEzLDE5LjU0LTE3LjEzaDUxLjRjLjM5LDAsLjc2LjAyLDEuMTQuMDQsMjQuMjEuODYsNDMuNjEsMjAuNTksNDMuOTQsNDQuOTNsMy45MS0yNy44NGMzLjk5LTI4LjM5LTE1Ljc5LTUxLjQtNDQuMTctNTEuNFoiLz48L2NsaXBQYXRoPjxyYWRpYWxHcmFkaWVudCBpZD0icmFkaWFsLWdyYWRpZW50LTIiIGN4PSIzODAuNTMiIGN5PSIzMDYuNjYiIGZ4PSIzODAuNTMiIGZ5PSIzMDYuNjYiIHI9IjUzLjM3IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjNDEzNzk2Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjODM2OWYwIi8+PC9yYWRpYWxHcmFkaWVudD48cmFkaWFsR3JhZGllbnQgaWQ9InJhZGlhbC1ncmFkaWVudC0zIiBjeD0iNDc2Ljc4IiBjeT0iMjM4LjYxIiBmeD0iNDc2Ljc4IiBmeT0iMjM4LjYxIiByPSI0Mi43IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjYjJhMmY2Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjODM2OWYwIi8+PC9yYWRpYWxHcmFkaWVudD48Y2xpcFBhdGggaWQ9ImNsaXBwYXRoLTIiPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTQ2Mi43NCwyMDljOC44NC41OSwxNC44Niw4LjAxLDEzLjU5LDE3LjA5bC00LjgyLDM0LjI3Yy0xLjMzLDkuNDYtMTAuMDgsMTcuMTMtMTkuNTQsMTcuMTNoLTE5LjI3Yy0zLjU1LDAtNi44MywyLjg4LTcuMzMsNi40MmwtMy45MSwyNy44NGgyNS43YzI4LjM5LDAsNTQuNjMtMjMuMDEsNTguNjItNTEuNGwuOS02LjQzYy0uMzMtMjQuMzQtMTkuNzMtNDQuMDctNDMuOTQtNDQuOTNaIi8+PC9jbGlwUGF0aD48cmFkaWFsR3JhZGllbnQgaWQ9InJhZGlhbC1ncmFkaWVudC00IiBjeD0iNDgzLjk2IiBjeT0iMjIxLjkiIGZ4PSI0ODMuOTYiIGZ5PSIyMjEuOSIgcj0iNDYuMDMiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiMyMTE3NDciLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiM0MTM3OTYiLz48L3JhZGlhbEdyYWRpZW50PjwvZGVmcz48Zz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik02MTYuMjEsMjE3Ljk4Yy01LjUtNi4xNy0xMy43LTkuMjYtMjQuNi05LjI2aC0zOC43N2MtMi4yMiwwLTMuODIuNDMtNC44MSwxLjMtLjk5Ljg3LTEuNjQsMi40MS0xLjk1LDQuNjNsLTEyLjc3LDkwLjg2Yy0uMzEsMi4yMi0uMDksMy43Ni42NSw0LjYzLjc1Ljg3LDIuMjMsMS4zLDQuNDUsMS4zaDExLjcyYzIuMjIsMCwzLjgyLS40Myw0LjgxLTEuMy45OS0uODcsMS42NC0yLjQxLDEuOTUtNC42M2wzLjg2LTI3LjQ5aDIxLjEyYzExLDAsMjAuMDgtMy4wNiwyNy4yNi05LjE5LDcuMTgtNi4xMiwxMS41My0xNC41OSwxMy4wNS0yNS4zOSwxLjUyLTEwLjgtLjQ3LTE5LjI5LTUuOTctMjUuNDZaTTU5Ny43MywyNDMuNDVjLS41OCw0LjE1LTIuMjIsNy4zNi00LjksOS42Mi0yLjY4LDIuMjctNi4xNSwzLjQtMTAuMzksMy40aC0xOC42NmwzLjctMjYuMzNoMTguNjZjNC4yNCwwLDcuMzgsMS4xOCw5LjQxLDMuNTQsMi4wMywyLjM2LDIuNzYsNS42MiwyLjE3LDkuNzdaIi8+PHBhdGggY2xhc3M9ImNscy00IiBkPSJNNjYyLjA0LDIzNC4wNGMtNy43MiwwLTE0LjM0LDEuMy0xOS44NiwzLjkxLTUuNTMsMi42LTkuOTMsNi4zMi0xMy4yMSwxMS4xNC0uODUsMS4yNS0xLjM1LDIuMzYtMS40OCwzLjMzLS4yNiwxLjgzLjg0LDMuMjgsMy4zLDQuMzRsNy41MSwzLjE4YzEuMjcuNTgsMi4yOS44NywzLjA2Ljg3Ljg3LDAsMS42My0uMjQsMi4yNy0uNzIuNjUtLjQ4LDEuNDQtMS4zLDIuMzctMi40NiwzLjItMy41Nyw3LjQ2LTUuMzUsMTIuNzYtNS4zNSwzLjk1LDAsNi42Ny44OSw4LjE2LDIuNjgsMS40OSwxLjc5LDEuOTcsNC41MSwxLjQ2LDguMTdsLS40OSwzLjQ3Yy00LjMtLjI5LTcuNy0uNDMtMTAuMjEtLjQzLTguMiwwLTE0LjgxLjcyLTE5Ljg0LDIuMTctNS4wMywxLjQ1LTguOTQsMy44OC0xMS43Myw3LjMxLTIuOCwzLjQyLTQuNjIsOC4xMy01LjQ2LDE0LjExLS43Niw1LjQtLjQyLDkuODQsMS4wMiwxMy4zMSwxLjQ0LDMuNDcsNC40Nyw2LjEsOS4wOSw3Ljg5LDQuNjIsMS43OCwxMS4xNywyLjY4LDE5LjY2LDIuNjgsMTIuNDQsMCwyMS43NC0xLjMsMjcuODktMy45MSwyLjI0LS44NywzLjgtMS44Niw0LjY4LTIuOTcuODgtMS4xMSwxLjQ5LTIuOTIsMS44NS01LjQzbDUuMTYtMzYuNzVjMS4zNi05LjY0LS4wNy0xNy4xNC00LjI5LTIyLjUtNC4yMi01LjM1LTEyLjExLTguMDMtMjMuNjgtOC4wM1pNNjYzLjg3LDI5NS4xYy0uMDcuNDgtLjQ1LjgyLTEuMTYsMS4wMS0yLjk2LjQ4LTYuODEuNzItMTEuNTMuNzItMy43NiwwLTYuMjMtLjYzLTcuNC0xLjg4LTEuMTctMS4yNS0xLjYtMy4wNC0xLjI3LTUuMzUuMzMtMi4zMiwxLjI3LTQuMSwyLjg1LTUuMzUsMS41Ny0xLjI1LDQuMjktMS44OCw4LjE1LTEuODgsMi42MSwwLDYuNjQuMTQsMTIuMDkuNDNsLTEuNzMsMTIuM1oiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik03NjYuNywyMzYuMjFoLTExLjI5Yy0xLjkzLDAtMy4zNi4zOS00LjI5LDEuMTYtLjkzLjc3LTEuNTMsMi4xNy0xLjgyLDQuMmwtNi43MSw0Ny43M2MtMy42Ny42OC03LjIzLDEuMDEtMTAuNzEsMS4wMS00LjE1LDAtNy4xMS0uODctOC44OS0yLjYtMS43OC0xLjc0LTIuNDEtNC40OS0xLjg4LTguMjVsNS4zMy0zNy45Yy4yOC0yLjAzLjEtMy40Mi0uNTctNC4yLS42Ni0uNzctMi4wMS0xLjE2LTQuMDMtMS4xNmgtMTEuMTRjLTIuMDMsMC0zLjQ4LjM5LTQuMzYsMS4xNi0uODguNzctMS40NiwyLjE3LTEuNzUsNC4ybC01LjQzLDM4LjYyYy0xLjM2LDkuNjUuMTgsMTcuMDUsNC42MiwyMi4yMSw0LjQzLDUuMTYsMTEuOTEsNy43NCwyMi40Miw3Ljc0LDUuNSwwLDEwLjAzLS4zNCwxMy42LTEuMDFsLS44Myw1LjkzYy0uNTQsMy44Ni0xLjk1LDYuOC00LjIxLDguODItMi4yNiwyLjAzLTUuMjMsMy4wNC04Ljg5LDMuMDQtMi44OSwwLTUuMTktLjQ2LTYuOS0xLjM3LTEuNy0uOTItMy4xLTIuMjktNC4xOS00LjEyLTEuMjUtMi4xMi0yLjY0LTMuMTgtNC4xOC0zLjE4LTEuMDYsMC0yLjM3LjM4LTMuOTIsMS4xNmwtOC44NCw0LjE5Yy0yLjU5LDEuMjUtNC4wMSwyLjgtNC4yNyw0LjYzLS4xOCwxLjI1LjEyLDIuNTUuOSwzLjkxLDQuNDIsOS4wNywxNC4xLDEzLjYsMjkuMDUsMTMuNiwxMS4zOCwwLDIwLjEzLTIuODcsMjYuMjQtOC42MSw2LjExLTUuNzQsOS44Ny0xMy42MywxMS4yOC0yMy42NmwxMC4xLTcxLjljLjI4LTIuMDMuMDktMy40Mi0uNTctNC4yLS42Ni0uNzctMS45Ni0xLjE2LTMuODktMS4xNloiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik04NDEuOTMsMjkwLjAzaC0zNy4zM2wxMC41OS03NS4zOGMuMzEtMi4yMi4wOS0zLjc2LS42NS00LjYzLS43NS0uODctMi4yMy0xLjMtNC40NS0xLjNoLTExLjcyYy0yLjIyLDAtMy44Mi40My00LjgxLDEuMy0uOTkuODctMS42NCwyLjQxLTEuOTUsNC42M2wtMTIuNzcsOTAuODZjLS4zMSwyLjIyLS4wOSwzLjc2LjY1LDQuNjMuNzUuODcsMi4yMywxLjMsNC40NSwxLjNoNTQuOThjMi4yMiwwLDMuODItLjQzLDQuODEtMS4zLjk5LS44NywxLjY0LTIuNDEsMS45NS00LjYzbDEuMzYtOS42OWMuMzEtMi4yMi4wOS0zLjc0LS42Ni00LjU2LS43NS0uODItMi4yNC0xLjIzLTQuNDYtMS4yM1oiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik04OTcuMDgsMjM0LjA0Yy03LjcyLDAtMTQuMzQsMS4zLTE5Ljg2LDMuOTEtNS41MywyLjYtOS45Myw2LjMyLTEzLjIxLDExLjE0LS44NSwxLjI1LTEuMzUsMi4zNi0xLjQ4LDMuMzMtLjI2LDEuODMuODQsMy4yOCwzLjMsNC4zNGw3LjUxLDMuMThjMS4yNy41OCwyLjI5Ljg3LDMuMDYuODcuODcsMCwxLjYzLS4yNCwyLjI3LS43Mi42NS0uNDgsMS40NC0xLjMsMi4zNy0yLjQ2LDMuMi0zLjU3LDcuNDYtNS4zNSwxMi43Ni01LjM1LDMuOTUsMCw2LjY3Ljg5LDguMTYsMi42OCwxLjQ5LDEuNzksMS45Nyw0LjUxLDEuNDYsOC4xN2wtLjQ5LDMuNDdjLTQuMy0uMjktNy43LS40My0xMC4yMS0uNDMtOC4yLDAtMTQuODEuNzItMTkuODQsMi4xNy01LjAzLDEuNDUtOC45NCwzLjg4LTExLjczLDcuMzEtMi44LDMuNDItNC42Miw4LjEzLTUuNDYsMTQuMTEtLjc2LDUuNC0uNDIsOS44NCwxLjAyLDEzLjMxLDEuNDQsMy40Nyw0LjQ3LDYuMSw5LjA5LDcuODksNC42MiwxLjc4LDExLjE3LDIuNjgsMTkuNjYsMi42OCwxMi40NCwwLDIxLjc0LTEuMywyNy44OS0zLjkxLDIuMjQtLjg3LDMuOC0xLjg2LDQuNjgtMi45Ny44OC0xLjExLDEuNS0yLjkyLDEuODUtNS40M2w1LjE2LTM2Ljc1YzEuMzYtOS42NC0uMDctMTcuMTQtNC4yOS0yMi41LTQuMjItNS4zNS0xMi4xMS04LjAzLTIzLjY4LTguMDNaTTg5OC45MSwyOTUuMWMtLjA3LjQ4LS40NS44Mi0xLjE2LDEuMDEtMi45Ni40OC02LjgxLjcyLTExLjUzLjcyLTMuNzYsMC02LjIzLS42My03LjQtMS44OC0xLjE3LTEuMjUtMS42LTMuMDQtMS4yNy01LjM1LjMzLTIuMzIsMS4yNy00LjEsMi44NS01LjM1LDEuNTctMS4yNSw0LjI5LTEuODgsOC4xNS0xLjg4LDIuNjEsMCw2LjY0LjE0LDEyLjA5LjQzbC0xLjczLDEyLjNaIi8+PHBhdGggY2xhc3M9ImNscy00IiBkPSJNOTgzLjUsMjM2LjIxaC0xMy40NmwxLjY5LTEyLjAxYy4yOC0yLjAzLjA5LTMuNDItLjU3LTQuMi0uNjYtLjc3LTEuOTYtMS4xNi0zLjg5LTEuMTZoLTExLjI4Yy0xLjkzLDAtMy4zNi4zOS00LjI5LDEuMTYtLjkzLjc3LTEuNTQsMi4xNy0xLjgyLDQuMmwtMS42OSwxMi4wMWgtNy42N2MtMi4wMywwLTMuNDguMzktNC4zNiwxLjE2LS44OC43Ny0xLjQ2LDIuMTctMS43NSw0LjJsLTEuMjIsOC42OGMtLjI3LDEuOTMtLjA4LDMuMy41OCw0LjEyLjY2LjgyLDIsMS4yMyw0LjAyLDEuMjNoNy42N2wtMy4yMywyM2MtMS4xOSw4LjQ5LS45NiwxNS4xLjY5LDE5LjgyLDEuNjUsNC43Myw0Ljg3LDguMDgsOS42NSwxMC4wNiw0Ljc5LDEuOTgsMTEuNTIsMi45NywyMC4yLDIuOTcsMi4wMywwLDMuNDgtLjQxLDQuMzctMS4yMy44OS0uODIsMS40OC0yLjI5LDEuNzgtNC40MWwxLjI4LTkuMTFjLjMtMi4xMi4xMi0zLjU3LS41NS00LjM0LS42Ni0uNzctMi4wMS0xLjE2LTQuMDMtMS4xNi0zLjQ3LDAtNi4wOC0uMzQtNy44Mi0xLjAxLTEuNzQtLjY3LTIuOS0xLjk4LTMuNS0zLjkxLS42LTEuOTMtLjYzLTQuNzctLjEtOC41NGwzLjExLTIyLjE0aDEzLjQ2YzEuOTMsMCwzLjM0LS40MSw0LjIyLTEuMjMuODktLjgyLDEuNDctMi4xOSwxLjc0LTQuMTJsMS4yMi04LjY4Yy4yOC0yLjAzLjEtMy40Mi0uNTctNC4yLS42Ni0uNzctMS45Ni0xLjE2LTMuODktMS4xNloiLz48cGF0aCBjbGFzcz0iY2xzLTQiIGQ9Ik0xMTIwLjg3LDIzNy4zN2MtLjY2LS43Ny0yLjAxLTEuMTYtNC4wMy0xLjE2aC00LjYzYy0xMSwwLTIwLjUyLDEuNS0yOC41NSw0LjQ5LTIuNDQuODctNC4xMiwxLjg4LTUuMDYsMy4wNC0uOTQsMS4xNi0xLjU3LDIuOTQtMS45MSw1LjM1bC04LjAxLDU3Yy0uMjgsMi4wMy0uMDcsMy40Mi42NCw0LjIuNzEuNzcsMi4wMywxLjE2LDMuOTYsMS4xNmgxMS4yOGMxLjkzLDAsMy4zMy0uMzgsNC4yMS0xLjE2Ljg4LS43NywxLjQ2LTIuMTcsMS43NS00LjJsNi43OS00OC4zMmMuMDgtLjU4LjQyLS45MiwxLjAxLTEuMDEsMy4wOC0uNjcsNi41Ni0xLjAxLDEwLjQxLTEuMDFoNS4zNWMyLjAzLDAsMy40OC0uMzgsNC4zNi0xLjE2Ljg4LS43NywxLjQ2LTIuMTIsMS43My00LjA1bDEuMjYtOC45N2MuMjgtMi4wMy4wOS0zLjQyLS41Ny00LjJaIi8+PHBhdGggY2xhc3M9ImNscy00IiBkPSJNMTA1NS4wOSwyMzkuOTVjLTUuNDktNC0xMi44Ny02LTIyLjEzLTYtMTEuMTksMC0yMC4xNCwyLjU2LTI2Ljg2LDcuNjctNi43Miw1LjExLTEwLjc4LDEyLjQ0LTEyLjE4LDIxLjk5bC0yLjQ4LDE2LjA2Yy0uMzgsMy4wOS0uNTIsNS43NC0uNDUsNy45Ni4yNyw3LjgxLDIuOSwxNC4wOCw3Ljg5LDE4LjgxLDQuOTksNC43MywxMi41LDcuMDksMjIuNTMsNy4wOSwxNi4xMSwwLDI3LjQzLTQuMzksMzMuOTgtMTMuMTcsMS4yOS0xLjY0LDEuOTEtMy4xOCwxLjg2LTQuNjMtLjA1LTEuNDUtMS4wMS0yLjc1LTIuODgtMy45MWwtNi41LTMuNzZjLTEuNTgtLjk2LTIuODUtMS40NS0zLjgxLTEuNDUtLjc3LDAtMS41My4yNy0yLjI5LjgtLjc1LjUzLTEuNjQsMS4zMy0yLjY2LDIuMzktMy40NCwzLjg2LTguNDgsNS43OS0xNS4xMyw1Ljc5LTcuNDMsMC0xMS4yNC0yLjg0LTExLjQ0LTguNTQtLjAyLS41OC4wNC0xLjU0LjE5LTIuODlsLjM2LTIuMDNjNS4wMi4xOSw4Ljc0LjI5LDExLjE1LjI5LDExLjQ4LDAsMjAuNjMtMS41OSwyNy40Ny00Ljc3LDYuODMtMy4xOCwxMC43NC04LjY4LDExLjcyLTE2LjQ5LjIzLTEuNjQuMzItMy4xOC4yNy00LjYzLS4yNS03LjA0LTMuMTItMTIuNTYtOC42MS0xNi41NlpNMTA0Mi4wOSwyNTguOTdjLS40NywyLjk5LTIuMzgsNS4wNC01LjcyLDYuMTUtMy4zNCwxLjExLTguMDQsMS42Ni0xNC4xMiwxLjY2LTMuMDksMC01LjQxLS4wOS02Ljk1LS4yOWwuNDUtMy42MmMuNjUtMy41NywyLjI4LTYuMzksNC45MS04LjQ2LDIuNjMtMi4wNyw2LjAxLTMuMTEsMTAuMTYtMy4xMXM3LjAyLjY1LDguODksMS45NWMxLjg4LDEuMywyLjY3LDMuMjEsMi4zNyw1LjcyWiIvPjwvZz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik00MzIuNjksMjc3LjQ4aDE5LjI3YzkuNDYsMCwxOC4yMS03LjY3LDE5LjU0LTE3LjEzbDQuODItMzQuMjdjMS4yOC05LjA4LTQuNzQtMTYuNS0xMy41OS0xNy4wOS0uNTUtLjAyLTEuMDktLjA0LTEuNjQtLjA0LjU1LDAsMS4xLjAyLDEuNjQuMDQtLjM4LS4wMy0uNzUtLjA0LTEuMTQtLjA0aC01MS40Yy05LjQ2LDAtMTguMjEsNy42Ny0xOS41NCwxNy4xM2wtOS42Myw2OC41M2MtMS4yNyw5LjA0LDQuNjksMTYuNDQsMTMuNDgsMTcuMDguNTMuMDIsMS4wNi4wNCwxLjYuMDQtLjU0LDAtMS4wNy0uMDItMS42LS4wNC40MS4wMy44Mi4wNSwxLjI0LjA1aDI1LjdsMy45MS0yNy44NGMuNS0zLjU1LDMuNzgtNi40Miw3LjMzLTYuNDJaIi8+PGcgY2xhc3M9ImNscy0xIj48cmVjdCBjbGFzcz0iY2xzLTUiIHg9IjM0Ny44MyIgeT0iMjk3LjU3IiB3aWR0aD0iODcuMDciIGhlaWdodD0iNTguNDQiLz48Y2lyY2xlIGNsYXNzPSJjbHMtMyIgY3g9IjM3MS42OCIgY3k9IjI4NC4yNCIgcj0iNTMuMzciLz48L2c+PGcgY2xhc3M9ImNscy0xMCI+PHJlY3QgY2xhc3M9ImNscy05IiB4PSIzNDIuNDciIHk9IjE2MS45IiB3aWR0aD0iMTgzLjM1IiBoZWlnaHQ9IjE1OS42MiIvPjxjaXJjbGUgY2xhc3M9ImNscy02IiBjeD0iMzgwLjUzIiBjeT0iMzA2LjY2IiByPSI1My4zNyIvPjxjaXJjbGUgY2xhc3M9ImNscy03IiBjeD0iNDc2Ljc4IiBjeT0iMjM4LjYxIiByPSI0Mi43Ii8+PC9nPjxnIGNsYXNzPSJjbHMtMTEiPjxyZWN0IGNsYXNzPSJjbHMtNCIgeD0iNDEyLjg0IiB5PSIyMTIuMjkiIHdpZHRoPSIxMTAuMDMiIGhlaWdodD0iMTE4LjA4Ii8+PGNpcmNsZSBjbGFzcz0iY2xzLTgiIGN4PSI0ODMuOTYiIGN5PSIyMjEuOSIgcj0iNDYuMDMiLz48L2c+PC9zdmc+';

    return Component.extend({
        defaults: {
            template: 'PayLater_PayLaterpay/payment/ppaylater'
        },

        getSpotiipayImgSrc: function () {
            return PAYLATER_LOGO;
        },

        showError: function (message) {
            globalMessageList.addErrorMessage({
                message: message || $t('Unable to start PayLater checkout. Please try again or pick a different payment method.')
            });
        },

        checkInventory: function () {
            var url = urlBuilder.build('ppaylater/standard/checkinventory');
            var items = (window.checkoutConfig.quoteItemData || []).map(function (item) {
                return { sku: item.sku, qty: item.qty };
            });
            return $.ajax({
                url: url,
                method: 'POST',
                data: { items: JSON.stringify(items) },
                dataType: 'json'
            });
        },

        startCheckout: function () {
            var self = this;
            var url = urlBuilder.build('ppaylater/standard/redirect');
            var formData = $('#co-shipping-form').serialize();
            if (!customer.isLoggedIn() && quote.guestEmail) {
                formData += '&email=' + encodeURIComponent(quote.guestEmail);
            }

            $.ajax({
                url: url,
                method: 'POST',
                data: formData,
                dataType: 'json',
                showLoader: true
            }).done(function (response) {
                if (response && response.redirectURL) {
                    window.location.assign(response.redirectURL);
                    return;
                }
                inFlight = false;
                self.showError(response && response.message);
            }).fail(function () {
                inFlight = false;
                self.showError();
            });
        },

        continueToSpotiipay: function () {
            var self = this;
            if (inFlight) {
                return;
            }
            if (!this.validate() || !additionalValidators.validate()) {
                return;
            }

            inFlight = true;
            this.checkInventory()
                .done(function (stockResponse) {
                    if (!stockResponse || stockResponse.isInStock !== true) {
                        inFlight = false;
                        self.showError(
                            (stockResponse && stockResponse.error)
                            || $t('One or more items in your cart are out of stock.')
                        );
                        return;
                    }
                    self.startCheckout();
                })
                .fail(function () {
                    inFlight = false;
                    self.showError($t('Could not verify stock availability. Please try again.'));
                });
        },

        placeOrder: function () {
            this.continueToSpotiipay();
        }
    });
});
