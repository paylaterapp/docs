<?php
/**
 * PayLater Pro Gateway Class
 * Handles the core payment logic and administrative interface.
 */

defined( 'ABSPATH' ) || exit;

class WC_PayLater_Gateway_Shop_Now_Pay_Later extends WC_Payment_Gateway {

    /**
     * Constructor for the gateway.
     */
    public function __construct() {
        // 1. Fundamental Identity (Must match 'section' in URL)
        $this->id = 'paylater_shop_now_pay_later';
        $this->icon = apply_filters('woocommerce_paylater_icon', 'https://paylaterapp.com/wp-content/uploads/2024/12/paylater-logo.svg');
        $this->has_fields = false;
        $this->method_title = __('PayLater', 'paylater');
        $this->method_description = __('Advanced PayLater module with Product List (PLP) and Product Detail (PDP) widgets.', 'paylater');

        // 2. Initialize Settings (Required for Admin UI)
        $this->init_form_fields();
        $this->init_settings();

        // 3. Load Global Parameters (API URLs, Merchant IDs, etc.)
        if ( function_exists('gatewayPaylaterParameters') ) {
            gatewayPaylaterParameters($this, "PayLater");
        }

        // 4. Map settings to object properties
        $this->title       = $this->get_option('title', 'PayLater');
        $this->description = $this->get_option('description', 'Pay in 4 interest-free installments.');
        $this->enabled     = $this->get_option('enabled', 'yes');

        // 5. Hooks
        // Fixed: Use process_admin_options for saving, NOT admin_options
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

        // Callback listener for gateway redirects
        add_action('woocommerce_api_wc_paylater_gateway_shop_now_pay_later', array($this, 'paylater_response_handler'));
    }

    /**
     * Loads the Form Fields from our separate settings file.
     */
    public function init_form_fields() {
        $section = isset( $_GET['sub-section'] ) ? sanitize_text_field( $_GET['sub-section'] ) : '';

        if ( function_exists( 'paylater_form_fields' ) ) {
            paylater_form_fields( $this, $section );
        }
    }

    /**
     * Enforce the 300 floor server-side; the HTML min attribute alone is bypassable.
     */
    public function validate_order_min_field( $key, $value ) {
        $value = absint( $value );
        if ( $value < 300 ) {
            WC_Admin_Settings::add_error( __( 'PayLater minimum order amount cannot be less than 300.', 'paylater' ) );
            $value = 300;
        }
        return (string) $value;
    }

    /**
     * Renders the custom Admin UI with tabs.
     */
    public function admin_options() {
        $current_section = isset( $_GET['sub-section'] ) ? sanitize_text_field( $_GET['sub-section'] ) : '';

        // Render Navigation Tabs
        echo '<nav class="nav-tab-wrapper woo-nav-tab-wrapper" style="margin-bottom:20px;">';
        echo '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $this->id ) . '" class="nav-tab ' . ($current_section == '' ? 'nav-tab-active' : '') . '">' . __('General', 'paylater') . '</a>';
        echo '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $this->id . '&sub-section=api' ) . '" class="nav-tab ' . ($current_section == 'api' ? 'nav-tab-active' : '') . '">' . __('API Configuration', 'paylater') . '</a>';
        echo '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $this->id . '&sub-section=display' ) . '" class="nav-tab ' . ($current_section == 'display' ? 'nav-tab-active' : '') . '">' . __('Widget Settings', 'paylater') . '</a>';
        echo '</nav>';

        echo '<div id="paylater-pro-settings">';
        echo '<table class="form-table">';
        $this->generate_settings_html();
        echo '</table>';
        echo '</div>';
    }

    /**
     * Handles the "Place Order" process.
     */
    public function process_payment($order_id) {
        return processPaylaterPayment($order_id, $this, "PayLater", "wc_paylater_gateway_shop_now_pay_later");
    }

    /**
     * Handles the verification return from the portal.
     */
    public function paylater_response_handler() {
        return paylaterResponseHandler($this);
    }
}