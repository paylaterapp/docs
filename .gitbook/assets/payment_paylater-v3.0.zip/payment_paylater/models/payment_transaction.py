import logging
import time
import requests
from urllib.parse import urlsplit, parse_qs, urlunsplit
from werkzeug.urls import url_encode

from odoo import _, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

WEBHOOK_STATUS_DONE = {'success', 'paid', 'completed', 'approved', 'refunded', 'partially_refunded'}
WEBHOOK_STATUS_PENDING = {'pending', 'processing', 'in_progress'}
WEBHOOK_STATUS_FAILED = {'failed', 'declined', 'cancelled', 'canceled', 'rejected', 'refund_failed'}


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _paylater_request(self, method, path, *, params=None, json=None, retry_on_401=True):
        """Wrapper for PayLater v2 API calls with auto-token-refresh on 401."""
        self.ensure_one()
        provider = self.provider_id
        api_base = provider._paylater_get_api_url()
        url = f'{api_base}{path}'

        try:
            response = requests.request(
                method, url,
                params=params,
                json=json,
                headers=provider._paylater_auth_headers(),
                timeout=30,
            )
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Request error %s %s: %s", method, url, e)
            raise

        # If token expired mid-call, refresh once and retry.
        if response.status_code == 401 and retry_on_401:
            _logger.info("PayLater: 401 received, refreshing token and retrying")
            provider._paylater_get_access_token(force_refresh=True)
            return self._paylater_request(method, path, params=params, json=json, retry_on_401=False)

        return response

    # ------------------------------------------------------------------
    # Create payment link
    # ------------------------------------------------------------------
    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'paylater':
            return res

        provider = self.provider_id
        base_url = provider.get_base_url()

        return_params = url_encode({'ref': self.reference})
        return_url = f'{base_url}/payment/paylater/return?{return_params}'

        unique_order_id = f'{self.reference}-{int(time.time())}'

        payload = {
            'outlet_id': provider.sudo().paylater_outlet_id or 1,
            'currency': 'QAR',
            'amount': processing_values['amount'],
            'order_id': unique_order_id,
            'success_redirect_url': return_url,
            'fail_redirect_url': return_url,
            'expiry_duration': 10,
        }

        _logger.info(
            "PayLater [%s]: Creating payment — order=%s order_id=%s amount=%s",
            provider.paylater_environment, self.reference, unique_order_id,
            processing_values['amount'],
        )

        try:
            response = self._paylater_request(
                'POST', '/api/paylater/merchant-portal/v2/web-checkout',
                json=payload,
            )
            _logger.info(
                "PayLater: Create response — order=%s http_status=%s body=%s",
                self.reference, response.status_code, response.text,
            )
        except requests.exceptions.Timeout:
            raise UserError(_("PayLater payment gateway timed out. Please try again."))
        except requests.exceptions.ConnectionError:
            raise UserError(_("Could not connect to PayLater. Please try again."))
        except requests.exceptions.RequestException as e:
            raise UserError(_("Could not connect to PayLater: %s", e))

        try:
            data = response.json()
        except ValueError:
            _logger.error("PayLater: Non-JSON response: %s", response.text)
            raise UserError(_("PayLater returned an invalid response."))

        if response.status_code >= 400 or 'error' in data:
            err = data.get('error') or f'HTTP {response.status_code}'
            msg = data.get('message') or data.get('error_description') or ''
            _logger.error("PayLater: API error for order=%s: %s %s", self.reference, err, msg)
            raise UserError(_("PayLater error: %s %s", err, msg))

        payment_url = data.get('paymentLinkUrl') or data.get('payment_link_url')
        if not payment_url:
            _logger.error("PayLater: No payment link in response for order=%s: %s", self.reference, data)
            raise UserError(_("PayLater did not return a valid payment link."))

        self.provider_reference = unique_order_id

        _logger.info(
            "PayLater: Redirecting order=%s (order_id=%s) to %s",
            self.reference, unique_order_id, payment_url,
        )

        # Preserve URL query params across the redirect form.
        parsed = urlsplit(payment_url)
        base_url_clean = urlunsplit((parsed.scheme, parsed.netloc, parsed.path, '', ''))
        url_params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        return {
            'api_url': base_url_clean,
            'url_params': url_params,
        }

    # ------------------------------------------------------------------
    # Notification dispatch
    # ------------------------------------------------------------------
    def _get_tx_from_notification_data(self, provider_code, notification_data):
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'paylater' or len(tx) == 1:
            return tx

        # Browser return uses 'ref' (Odoo reference). Webhook uses 'orderId' (provider_reference).
        reference = notification_data.get('ref')
        order_id = notification_data.get('orderId') or notification_data.get('order_id')

        if reference:
            tx = self.search([
                ('reference', '=', reference),
                ('provider_code', '=', 'paylater'),
            ])
        elif order_id:
            tx = self.search([
                ('provider_reference', '=', order_id),
                ('provider_code', '=', 'paylater'),
            ])
        else:
            _logger.error("PayLater: Missing identifiers in data: %s", notification_data)
            raise ValidationError("PayLater: " + _("Received data with no identifier."))

        if not tx:
            _logger.error("PayLater: No transaction matching data: %s", notification_data)
            raise ValidationError("PayLater: " + _("No transaction found matching the notification."))

        _logger.info(
            "PayLater: Found tx id=%s for ref=%s order_id=%s",
            tx.id, tx.reference, tx.provider_reference,
        )
        return tx

    def _process_notification_data(self, notification_data):
        super()._process_notification_data(notification_data)
        if self.provider_code != 'paylater':
            return

        if 'signature' in notification_data:
            self._paylater_apply_webhook_status(notification_data)
            return

        self._paylater_apply_status_from_api()

    # ------------------------------------------------------------------
    # Webhook handling
    # ------------------------------------------------------------------
    def _paylater_apply_webhook_status(self, data):
        self.ensure_one()
        status = (data.get('status') or '').lower()
        comments = data.get('comments') or ''
        paylater_ref = data.get('paylaterRef')

        _logger.info(
            "PayLater webhook: ref=%s order_id=%s status=%s paylaterRef=%s comments=%s",
            self.reference, self.provider_reference, status, paylater_ref, comments,
        )

        if status in WEBHOOK_STATUS_DONE:
            if self.state != 'done':
                self._set_done()
            refunds = self.child_transaction_ids.filtered(
                lambda t: t.operation == 'refund' and t.state not in ('done', 'cancel', 'error')
            )
            for r in refunds:
                r._set_done()
        elif status in WEBHOOK_STATUS_PENDING:
            if self.state not in ('done', 'cancel', 'error'):
                self._set_pending()
        elif status in WEBHOOK_STATUS_FAILED:
            if self.operation == 'refund':
                self._set_error(state_message=_("Refund failed on PayLater. %s", comments))
            elif self.state != 'done':
                self._set_canceled(state_message=_("Payment failed on PayLater. %s", comments))
        else:
            _logger.warning("PayLater: unknown webhook status=%s for ref=%s", status, self.reference)

    # ------------------------------------------------------------------
    # Status check (browser return)
    # ------------------------------------------------------------------
    def _paylater_apply_status_from_api(self):
        self.ensure_one()
        order_id = self.provider_reference

        _logger.info("PayLater: Checking status — ref=%s order_id=%s", self.reference, order_id)

        try:
            response = self._paylater_request(
                'GET', '/api/paylater/merchant-portal/v2/web-checkout/status',
                params={'order_id': order_id},
            )
            _logger.info(
                "PayLater: Status response — ref=%s http_status=%s body=%s",
                self.reference, response.status_code, response.text,
            )
            data = response.json()
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Status check failed for ref=%s: %s", self.reference, e)
            raise ValidationError(_("Could not verify payment status with PayLater."))
        except ValueError:
            raise ValidationError(_("PayLater status response is not valid JSON."))

        if response.status_code >= 400 or 'error' in data:
            err = data.get('error') or f'HTTP {response.status_code}'
            _logger.error("PayLater: Status error for ref=%s: %s", self.reference, err)
            raise ValidationError(_("PayLater status error: %s", err))

        status = data.get('status')
        message = data.get('message', '')

        _logger.info("PayLater: ref=%s status=%s message=%s", self.reference, status, message)

        # Accept both numeric (legacy) and string status values.
        if status == 2 or (isinstance(status, str) and status.lower() in WEBHOOK_STATUS_DONE):
            self._set_done()
        elif status == 1 or (isinstance(status, str) and status.lower() in WEBHOOK_STATUS_PENDING):
            self._set_pending()
        elif status == 3 or (isinstance(status, str) and status.lower() in WEBHOOK_STATUS_FAILED):
            self._set_canceled(state_message=_("Payment failed on PayLater."))
        else:
            _logger.error("PayLater: ref=%s — UNKNOWN status=%s", self.reference, status)
            self._set_error(state_message=_("Unknown payment status from PayLater: %s", message))

    # ------------------------------------------------------------------
    # Refunds
    # ------------------------------------------------------------------
    def _send_refund_request(self, amount_to_refund=None):
        """Trigger a full or partial refund. v2 endpoint: same URL for both —
        omit `amount` for a full refund, include it for partial."""
        refund_tx = super()._send_refund_request(amount_to_refund=amount_to_refund)
        if self.provider_code != 'paylater':
            return refund_tx

        order_ref = self.provider_reference
        is_full = abs(refund_tx.amount) >= abs(self.amount)

        body = {'order_id': order_ref}
        if not is_full:
            body['amount'] = abs(refund_tx.amount)

        _logger.info(
            "PayLater: Refund (%s) — ref=%s order_id=%s amount=%s",
            'full' if is_full else 'partial',
            self.reference, order_ref, abs(refund_tx.amount),
        )

        try:
            response = self._paylater_request(
                'POST', '/api/paylater/merchant-portal/v2/web-checkout/refund',
                json=body,
            )
            _logger.info(
                "PayLater: Refund response — ref=%s http_status=%s body=%s",
                self.reference, response.status_code, response.text,
            )
            data = response.json()
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Refund request failed for ref=%s: %s", self.reference, e)
            refund_tx._set_error(state_message=_("Could not contact PayLater to refund: %s", e))
            return refund_tx
        except ValueError:
            refund_tx._set_error(state_message=_("PayLater refund response is not valid JSON."))
            return refund_tx

        if response.status_code >= 400 or 'error' in data:
            err = data.get('error') or f'HTTP {response.status_code}'
            msg = data.get('message', '')
            _logger.error("PayLater: Refund API error for ref=%s: %s %s", self.reference, err, msg)
            refund_tx._set_error(state_message=_("PayLater refund error: %s %s", err, msg))
            return refund_tx

        # Accepted — final state arrives via webhook.
        refund_tx._set_pending()
        return refund_tx
