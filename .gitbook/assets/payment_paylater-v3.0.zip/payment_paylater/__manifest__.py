{
    'name': 'Payment Provider: PayLater',
    'version': '18.0.2.1.0',
    'category': 'Accounting/Payment Providers',
    'author': 'PayLater',
    'maintainer': 'PayLater',
    'website': 'https://paylaterapp.com',
    'support': 'support@paylaterapp.com',
    'summary': 'Accept payments via PayLater — split payments into 4 interest-free installments.',
    'description': """
PayLater Payment Provider
=========================

Accept PayLater Buy-Now-Pay-Later payments on your Odoo eCommerce store.
Customers can split their purchase into 4 interest-free installments.

Features
--------
* Integrate PayLater checkout on your Odoo Website Sale.
* PLP widget: compact split-price badge under each product on the shop page.
* PDP widget: collapsible installment breakdown on the product detail page.
* Configurable minimum order amount.
* Configurable heading, sub-heading, and terms text.
* UAT and Live environments.
* Server-side webhook and return URL handling.

Setup
-----
1. Install the module.
2. Go to Website > Configuration > Payment Providers > PayLater.
3. Enter your API Key, Merchant ID, and Outlet ID.
4. Set Environment (UAT or Live) and enable the provider.
5. Configure the widget display under Settings > PayLater.
    """,
    'depends': ['payment', 'website_sale'],
    'data': [
        'security/ir.model.access.csv',
        'views/redirect_form.xml',
        'data/payment_method_data.xml',
        'data/payment_provider_data.xml',
        'views/payment_provider_views.xml',
        'views/res_config_settings_views.xml',
        'views/templates.xml',
    ],
    'assets': {
        'web.assets_frontend': [
            'payment_paylater/static/src/css/paylater_widget.css',
            'payment_paylater/static/src/js/paylater_widget.js',
        ],
    },
    'images': ['static/description/icon.png'],
    'post_init_hook': '_post_init_hook',
    'uninstall_hook': '_uninstall_hook',
    'application': False,
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
