import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)

PAYLATER_URLS = {
    'uat': 'https://connect.uat.paylaterapp.com',
    'live': 'https://connect.paylaterapp.com',
}


class PaymentProvider(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(
        selection_add=[('paylater', 'PayLater')],
        ondelete={'paylater': 'set default'},
    )

    paylater_environment = fields.Selection(
        string="Environment",
        selection=[('uat', 'UAT (Testing)'), ('live', 'Live (Production)')],
        default='uat',
        required_if_provider='paylater',
    )
    paylater_api_key = fields.Char(
        string="API Key",
        required_if_provider='paylater',
        groups='base.group_system',
    )
    paylater_merchant_id = fields.Char(
        string="Merchant ID",
        required_if_provider='paylater',
        groups='base.group_system',
    )
    paylater_outlet_id = fields.Integer(
        string="Outlet ID",
        required_if_provider='paylater',
        groups='base.group_system',
    )
    paylater_webhook_secret = fields.Char(
        string="Webhook Secret",
        groups='base.group_system',
        help="The secret provided by PayLater for your webhook endpoint, used to verify HMAC SHA-256 signatures on incoming webhook events.",
    )
    paylater_minimum_amount = fields.Float(
        string="Minimum Order Amount",
        default=300.0,
        help="Minimum order amount required to offer PayLater at checkout. Orders below this amount will not see PayLater as a payment option.",
    )

    def _paylater_get_api_url(self):
        self.ensure_one()
        url = PAYLATER_URLS.get(self.paylater_environment, PAYLATER_URLS['uat'])
        _logger.debug("PayLater: API URL=%s env=%s", url, self.paylater_environment)
        return url

    def _get_default_payment_method_codes(self):
        self.ensure_one()
        if self.code != 'paylater':
            return super()._get_default_payment_method_codes()
        return {'paylater'}

    def _compute_feature_support_fields(self):
        super()._compute_feature_support_fields()
        self.filtered(lambda p: p.code == 'paylater').update({
            'support_refund': 'partial',
        })

    @api.model
    def _get_compatible_providers(self, company_id, partner_id, amount, **kwargs):
        providers = super()._get_compatible_providers(
            company_id, partner_id, amount, **kwargs
        )
        providers = providers.filtered(
            lambda p: p.code != 'paylater'
            or not p.paylater_minimum_amount
            or amount >= p.paylater_minimum_amount
        )
        return providers
