import logging
import time
import requests
from urllib.parse import urlsplit, parse_qs, urlunsplit
from werkzeug.urls import url_encode

from odoo import _, models
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

# Map PayLater webhook status strings to a normalised internal action.
WEBHOOK_STATUS_DONE = {'success', 'paid', 'completed', 'approved', 'refunded', 'partially_refunded'}
WEBHOOK_STATUS_PENDING = {'pending', 'processing', 'in_progress'}
WEBHOOK_STATUS_FAILED = {'failed', 'declined', 'cancelled', 'canceled', 'rejected', 'refund_failed'}


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_rendering_values(self, processing_values):
        """Call PayLater web-checkout API to create a payment and get a redirect URL."""
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'paylater':
            return res

        provider = self.provider_id
        base_url = provider.get_base_url()
        api_base = provider._paylater_get_api_url()

        return_params = url_encode({'ref': self.reference})
        return_url = f'{base_url}/payment/paylater/return?{return_params}'

        unique_order_id = f'{self.reference}-{int(time.time())}'

        payload = {
            'merchantId': provider.paylater_merchant_id or '1',
            'outletId': provider.paylater_outlet_id or 1,
            'currency': 'QAR',
            'amount': processing_values['amount'],
            'orderId': unique_order_id,
            'successRedirectUrl': return_url,
            'failRedirectUrl': return_url,
        }
        headers = {
            'x-api-key': provider.paylater_api_key or '',
            'Content-Type': 'application/json',
        }
        api_url = f'{api_base}/api/paylater/merchant-portal/web-checkout/'

        _logger.info(
            "PayLater [%s]: Creating payment — order=%s orderId=%s amount=%s",
            provider.paylater_environment, self.reference, unique_order_id,
            processing_values['amount'],
        )

        try:
            response = requests.post(api_url, json=payload, headers=headers, timeout=30)
            _logger.info(
                "PayLater [%s]: Response — order=%s http_status=%s body=%s",
                provider.paylater_environment, self.reference,
                response.status_code, response.text,
            )
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.Timeout:
            _logger.error("PayLater: Timeout for order=%s", self.reference)
            raise UserError(_("PayLater payment gateway timed out. Please try again."))
        except requests.exceptions.ConnectionError:
            _logger.error("PayLater: Connection failed for order=%s", self.reference)
            raise UserError(_("Could not connect to PayLater. Please try again."))
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Request error for order=%s: %s", self.reference, e)
            raise UserError(_("Could not connect to PayLater. Please try again."))

        if 'error' in data:
            _logger.error("PayLater: API error for order=%s: %s", self.reference, data['error'])
            raise UserError(_("PayLater error: %s", data['error']))

        payment_url = data.get('paymentLinkUrl')
        if not payment_url:
            _logger.error("PayLater: No paymentLinkUrl for order=%s — response: %s", self.reference, data)
            raise UserError(_("PayLater did not return a valid payment link."))

        self.provider_reference = unique_order_id

        _logger.info("PayLater: Redirecting order=%s (paylater_id=%s) to %s", self.reference, unique_order_id, payment_url)

        parsed = urlsplit(payment_url)
        base_url_clean = urlunsplit((parsed.scheme, parsed.netloc, parsed.path, '', ''))
        url_params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        return {
            'api_url': base_url_clean,
            'url_params': url_params,
        }

    def _get_tx_from_notification_data(self, provider_code, notification_data):
        """Find the transaction based on the notification data."""
        tx = super()._get_tx_from_notification_data(provider_code, notification_data)
        if provider_code != 'paylater' or len(tx) == 1:
            return tx

        # Browser return URL uses 'ref' (Odoo reference). Webhook uses 'orderId' (provider_reference).
        reference = notification_data.get('ref')
        order_id = notification_data.get('orderId')

        if reference:
            tx = self.search([
                ('reference', '=', reference),
                ('provider_code', '=', 'paylater'),
            ])
        elif order_id:
            tx = self.search([
                ('provider_reference', '=', order_id),
                ('provider_code', '=', 'paylater'),
            ])
        else:
            _logger.error("PayLater: Missing reference and orderId in data: %s", notification_data)
            raise ValidationError("PayLater: " + _("Received data with no identifier."))

        if not tx:
            _logger.error("PayLater: No transaction matching data: %s", notification_data)
            raise ValidationError("PayLater: " + _("No transaction found matching the notification."))

        _logger.info("PayLater: Found tx id=%s for ref=%s orderId=%s", tx.id, tx.reference, tx.provider_reference)
        return tx

    def _process_notification_data(self, notification_data):
        """Update transaction state based on either webhook or browser return data."""
        super()._process_notification_data(notification_data)
        if self.provider_code != 'paylater':
            return

        # Webhook payloads carry a 'signature' field — they're authoritative.
        if 'signature' in notification_data:
            self._paylater_apply_webhook_status(notification_data)
            return

        # Browser return — re-fetch authoritative status from PayLater status API.
        self._paylater_apply_status_from_api()

    # ------------------------------------------------------------------
    # Webhook handling
    # ------------------------------------------------------------------
    def _paylater_apply_webhook_status(self, data):
        """Apply state based on a verified webhook payload."""
        self.ensure_one()
        status = (data.get('status') or '').lower()
        comments = data.get('comments') or ''
        paylater_ref = data.get('paylaterRef')

        _logger.info(
            "PayLater webhook: ref=%s orderId=%s status=%s paylaterRef=%s comments=%s",
            self.reference, self.provider_reference, status, paylater_ref, comments,
        )

        if status in WEBHOOK_STATUS_DONE:
            if self.state != 'done':
                self._set_done()
            # If this transaction has refund children pending, also mark them done.
            refunds = self.child_transaction_ids.filtered(
                lambda t: t.operation in ('refund',) and t.state not in ('done', 'cancel', 'error')
            )
            for r in refunds:
                r._set_done()
        elif status in WEBHOOK_STATUS_PENDING:
            if self.state not in ('done', 'cancel', 'error'):
                self._set_pending()
        elif status in WEBHOOK_STATUS_FAILED:
            if self.operation == 'refund':
                self._set_error(state_message=_("Refund failed on PayLater. %s", comments))
            elif self.state not in ('done',):
                self._set_canceled(state_message=_("Payment failed on PayLater. %s", comments))
        else:
            _logger.warning("PayLater: unknown webhook status=%s for ref=%s", status, self.reference)

    # ------------------------------------------------------------------
    # Status check API (used on browser return)
    # ------------------------------------------------------------------
    def _paylater_apply_status_from_api(self):
        self.ensure_one()
        provider = self.provider_id
        api_base = provider._paylater_get_api_url()
        paylater_order_id = self.provider_reference

        status_url = f'{api_base}/api/paylater/merchant-portal/web-checkout/status'
        headers = {'x-api-key': provider.paylater_api_key or ''}
        params = {
            'orderId': paylater_order_id,
            'merchantId': provider.paylater_merchant_id or '1',
        }

        _logger.info("PayLater: Checking status — ref=%s orderId=%s", self.reference, paylater_order_id)

        try:
            response = requests.get(status_url, params=params, headers=headers, timeout=30)
            _logger.info(
                "PayLater: Status response — ref=%s http_status=%s body=%s",
                self.reference, response.status_code, response.text,
            )
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Status check failed for ref=%s: %s", self.reference, e)
            raise ValidationError(_("Could not verify payment status with PayLater."))

        if 'error' in data:
            _logger.error("PayLater: Status error for ref=%s: %s", self.reference, data['error'])
            raise ValidationError(_("PayLater status error: %s", data['error']))

        status = data.get('status')
        message = data.get('message', '')

        _logger.info("PayLater: ref=%s status=%s message=%s", self.reference, status, message)

        # Status API codes: 1=pending, 2=success, 3=failed
        if status == 2:
            self._set_done()
        elif status == 1:
            self._set_pending()
        elif status == 3:
            self._set_canceled(state_message=_("Payment failed on PayLater."))
        else:
            _logger.error("PayLater: Order %s — UNKNOWN status=%s", self.reference, status)
            self._set_error(state_message=_("Unknown payment status from PayLater: %s", message))

    # ------------------------------------------------------------------
    # Refunds
    # ------------------------------------------------------------------
    def _send_refund_request(self, amount_to_refund=None):
        """Trigger a full or partial refund with PayLater. Status arrives via webhook."""
        refund_tx = super()._send_refund_request(amount_to_refund=amount_to_refund)
        if self.provider_code != 'paylater':
            return refund_tx

        provider = self.provider_id
        api_base = provider._paylater_get_api_url()
        headers = {'x-api-key': provider.paylater_api_key or ''}

        merchant_id = provider.paylater_merchant_id or '1'
        order_ref = self.provider_reference

        # If amount_to_refund == self.amount → full; else partial.
        # refund_tx.amount is negative; compare absolute value.
        is_full = abs(refund_tx.amount) >= abs(self.amount)

        try:
            if is_full:
                url = f'{api_base}/api/paylater/merchant-portal/web-checkout/refund'
                params = {
                    'merchantId': merchant_id,
                    'transactionReference': order_ref,
                    'transactionType': 'DOWN_PAYMENT',
                }
                _logger.info(
                    "PayLater: Full refund — ref=%s orderId=%s",
                    self.reference, order_ref,
                )
                response = requests.get(url, params=params, headers=headers, timeout=30)
            else:
                url = f'{api_base}/api/paylater/merchant-portal/web-checkout/refund/partial'
                params = {
                    'merchantId': merchant_id,
                    'transactionReference': order_ref,
                }
                body = {'amount': abs(refund_tx.amount)}
                _logger.info(
                    "PayLater: Partial refund — ref=%s orderId=%s amount=%s",
                    self.reference, order_ref, abs(refund_tx.amount),
                )
                response = requests.post(url, params=params, json=body, headers=headers, timeout=30)

            _logger.info(
                "PayLater: Refund response — ref=%s http_status=%s body=%s",
                self.reference, response.status_code, response.text,
            )
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.RequestException as e:
            _logger.error("PayLater: Refund request failed for ref=%s: %s", self.reference, e)
            refund_tx._set_error(state_message=_("Could not contact PayLater to refund: %s", e))
            return refund_tx

        if 'error' in data:
            err = data.get('error')
            msg = data.get('message', '')
            _logger.error("PayLater: Refund API error for ref=%s: %s %s", self.reference, err, msg)
            refund_tx._set_error(state_message=_("PayLater refund error: %s %s", err, msg))
            return refund_tx

        # Refund accepted — final state confirmed via webhook.
        refund_tx._set_pending()
        return refund_tx
