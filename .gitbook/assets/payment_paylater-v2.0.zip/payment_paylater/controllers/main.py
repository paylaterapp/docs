import hashlib
import hmac
import logging
import pprint

from werkzeug.exceptions import Forbidden

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class PayLaterController(http.Controller):

    @http.route(
        '/payment/paylater/return',
        type='http', auth='public', methods=['GET'], csrf=False, save_session=False,
    )
    def paylater_return(self, **data):
        """Handle the customer returning from PayLater after payment."""
        _logger.info("PayLater: Customer return — data:\n%s", pprint.pformat(data))

        tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
            'paylater', data
        )
        _logger.info(
            "PayLater: Processing return — tx_id=%s ref=%s",
            tx_sudo.id, tx_sudo.reference,
        )
        tx_sudo._handle_notification_data('paylater', data)

        return request.redirect('/payment/status')

    @http.route(
        '/payment/paylater/callback',
        type='json', auth='public', methods=['POST'], csrf=False, save_session=False,
    )
    def paylater_callback(self):
        """Handle server-to-server webhook callback from PayLater.

        Expected payload:
            merchantId, orderId, paylaterRef, status, timestamp, signature, txHash, comments
        """
        notification_data = request.get_json_data() or {}
        _logger.info("PayLater: Webhook received — data:\n%s", pprint.pformat(notification_data))

        tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_notification_data(
            'paylater', notification_data
        )

        if not self._paylater_verify_webhook(tx_sudo, notification_data):
            _logger.warning(
                "PayLater: Webhook signature verification FAILED for ref=%s",
                tx_sudo.reference,
            )
            raise Forbidden("Invalid webhook signature")

        _logger.info(
            "PayLater: Webhook verified — tx_id=%s ref=%s",
            tx_sudo.id, tx_sudo.reference,
        )
        tx_sudo._handle_notification_data('paylater', notification_data)

        return {'message': 'Webhook received successfully'}

    def _paylater_verify_webhook(self, tx, data):
        """Verify the webhook txHash and HMAC signature.

        1. Reconstruct dataString = (merchantId + orderId + status + timestamp + comments).upper()
        2. Compute MD5(dataString) and compare with txHash
        3. Compute HMAC-SHA256(txHash, webhook_secret) and compare with signature
        """
        secret = tx.provider_id.sudo().paylater_webhook_secret or ''
        if not secret:
            _logger.error("PayLater: No webhook secret configured for provider id=%s", tx.provider_id.id)
            return False

        merchant_id = data.get('merchantId') or ''
        order_id = data.get('orderId') or ''
        status = data.get('status') or ''
        timestamp = data.get('timestamp') or ''
        comments = data.get('comments') or ''
        tx_hash = data.get('txHash') or ''
        signature = data.get('signature') or ''

        if not (tx_hash and signature):
            _logger.warning("PayLater: Webhook missing txHash or signature")
            return False

        data_string = f"{merchant_id}{order_id}{status}{timestamp}{comments}".upper()
        computed_tx_hash = hashlib.md5(data_string.encode('utf-8')).hexdigest()

        # Compare case-insensitively as some implementations return uppercase hex.
        if not hmac.compare_digest(computed_tx_hash.lower(), tx_hash.lower()):
            _logger.warning(
                "PayLater: txHash mismatch — computed=%s received=%s data_string=%s",
                computed_tx_hash, tx_hash, data_string,
            )
            return False

        # PHP reference signs the received txHash string. Use the value PayLater sent
        # (already validated above) so casing differences don't break HMAC.
        computed_signature = hmac.new(
            secret.encode('utf-8'),
            tx_hash.encode('utf-8'),
            hashlib.sha256,
        ).hexdigest()

        if not hmac.compare_digest(computed_signature.lower(), signature.lower()):
            _logger.warning(
                "PayLater: signature mismatch — computed=%s received=%s",
                computed_signature, signature,
            )
            return False

        return True
