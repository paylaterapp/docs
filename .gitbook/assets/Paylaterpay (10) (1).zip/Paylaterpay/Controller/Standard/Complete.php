<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */

namespace PayLater\PayLaterpay\Controller\Standard;

use PayLater\PayLaterpay\Controller\AbstractController\SpotiiPay;

/**
 * Class Complete
 * @package PayLater\PayLaterpay\Controller\Standard
 */
class Complete extends SpotiiPay
{
    /**
     * Complete the transaction
     */
    public function execute()
    {
        try {
            xdebug_break();
            // Create order before redirect to success
            $quote = $this->_checkoutSession->getQuote();

            // First verify the payment status from PayLater
            $payment = $quote->getPayment();
            $reference = $payment->getAdditionalInformation('ppaylater_order_id');
            
            // Verify payment status first
            $spotiiOrderInfo = $this->_spotiipayModel->getSpotiiOrderInfo($reference);

            $this->spotiiHelper->logSpotiiActions("OrderInfo : " . json_encode($spotiiOrderInfo));
            
            /*
                Only proceed if payment is successful
                Status 1 is pending
                Status 2 is successful
                Status 3 is failed
            */

            if (!isset($spotiiOrderInfo['status']) || $spotiiOrderInfo['status'] !== 2) {
                throw new \Magento\Framework\Exception\LocalizedException(
                    __('Payment was not successful. Please try again.')
                );
            }

            $quoteId = $quote->getId();
            $quote->collectTotals()->save();
            
            $this->spotiiHelper->logSpotiiActions("Quote Customer Email: " . $quote->getCustomerEmail());
            $this->spotiiHelper->logSpotiiActions("Is Guest: " . ($quote->getCustomerIsGuest() ? 'Yes' : 'No'));
            $this->spotiiHelper->logSpotiiActions("Customer ID: " . $quote->getCustomerId());

            // For guest users, get email from shipping address
            if (!$this->_customerSession->isLoggedIn()) {
                $this->spotiiHelper->logSpotiiActions("=== Processing Guest User ===");
                
                /* For guest users, ensure email is properly set
                $quote->setCustomerIsGuest(true)
                ->setCustomerGroupId(\Magento\Customer\Api\Data\GroupInterface::NOT_LOGGED_IN_ID);
                */
                $shippingAddress = $quote->getShippingAddress();
                if ($shippingAddress && $shippingAddress->getEmail()) {
                    $addressData = [
                        'name' => $shippingAddress->getName(),
                        'email' => $shippingAddress->getEmail(),
                        'street' => implode(', ', $shippingAddress->getStreet()),
                        'city' => $shippingAddress->getCity(),
                        'postcode' => $shippingAddress->getPostcode(),
                        'country' => $shippingAddress->getCountryId()
                    ];
                    $this->spotiiHelper->logSpotiiActions("Shipping address: " . json_encode($addressData));
                    $quote->setCustomerEmail($shippingAddress->getEmail())
                        ->setCustomerIsGuest(true)
                        ->setCustomerGroupId(\Magento\Customer\Api\Data\GroupInterface::NOT_LOGGED_IN_ID);
                }
            }

            // Submit quote to create order
            try {
                $order = $this->_quoteManagement->submit($quote);
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                if (strpos($e->getMessage(), 'Email has a wrong format') !== false) {
                    // Retry with email validation bypass for guest users
                    $quote->setCustomerEmail($quote->getCustomerEmail());
                    $order = $this->_quoteManagement->submit($quote);
                } else {
                    throw $e;
                }
            }

            $payment = $quote->getPayment();
            $payment->setMethod('ppaylater');
            $payment->save();
            $quote->reserveOrderId();
            $quote->setPayment($payment);
            $quote->save();

            $this->_checkoutSession->replaceQuote($quote);
            $reference = $payment->getAdditionalInformation('ppaylater_order_id');

            $this->_spotiipayModel->createTransaction(
                $order,
                $reference,
                \Magento\Sales\Model\Order\Payment\Transaction::TYPE_ORDER
            );

            $order->save();

            // Set all necessary session data
            $this->_checkoutSession->setLastQuoteId($quoteId);
            $this->_checkoutSession->setLastSuccessQuoteId($quoteId);
            $this->_checkoutSession->setLastOrderId($order->getEntityId());
            $this->_checkoutSession->setLastRealOrderId($order->getIncrementId());

            $this->messageManager->addSuccess("<b>Success! Payment completed!</b><br>Thank you for your payment, your order with PayLater has been placed.");

            // Single redirect to success page
            return $this->_redirect('checkout/onepage/success');

        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->spotiiHelper->logSpotiiActions("Transaction Exception: " . $e->getMessage());
            $this->messageManager->addError($e->getMessage());
            return $this->_redirect('checkout/cart');
        } catch (\Exception $e) {
            $this->spotiiHelper->logSpotiiActions("Transaction Exception: " . $e->getMessage());
            $this->messageManager->addError("An error occurred while processing your payment. Please try again.");
            return $this->_redirect('checkout/cart');
        }
    }
}
