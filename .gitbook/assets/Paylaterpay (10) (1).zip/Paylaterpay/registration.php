<?php
/*
 * @category    PayLater
 * @package     PayLater_PayLaterpay
 * @copyright   Copyright (c) PayLater (https://www.paylaterapp.com/)
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PayLater_PayLaterpay',
    __DIR__
);
