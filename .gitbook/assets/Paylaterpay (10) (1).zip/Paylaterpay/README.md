## Magento 2 extension for PayLater Payment Gateway

Use this extention for seamless integration with PayLater as payment gateway and your Magento 2 store.


1. Sign up for PayLater account at `https://dashboard.paylaterapp.com/signup/`
2. In your Magento 2 `[ROOT]/app/code/` create folder called `PayLater\PayLaterpay`.
3. Download and extract files from this repo to the folder.
4. Open the command line.
5. Enable PayLater by running command below:
`php bin/magento module:enable PayLater_PayLaterpay`
6. Magento setup upgrade:
`php bin/magento setup:upgrade`
7. Magento Dependencies Injection Compile:
`php bin/magento setup:di:compile`
8. Magento Static Content deployment:
`php bin/magento setup:static-content:deploy`
9. Login to Magento Admin and navigate to System/Cache Management
10. Flush the cache storage by selecting Flush Cache Storage

For more information on installation and configuration, please visit our [docs](https://docs.paylaterapp.com/#magento-2). 
